-- phpMyAdmin SQL Dump
-- version 3.2.0.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 23, 2012 at 01:18 PM
-- Server version: 5.1.37
-- PHP Version: 5.2.11

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `intelleo_dl`
--

-- --------------------------------------------------------

--
-- Table structure for table `AcceptRecommendationEvent`
--

CREATE TABLE `AcceptRecommendationEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95b8163419` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AcceptRecommendationEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `AchievementEvent`
--

CREATE TABLE `AchievementEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `achievedBy` tinyblob,
  `achievementResource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9549125ccb` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AchievementEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Activity`
--

CREATE TABLE `Activity` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `dateTimeStart` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `occurring_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKA126572FD7DE8A84` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD32a126572f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity`
--

INSERT INTO `Activity` VALUES(184, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Conceptual Modeling0', 'http://intelleo.org/triplestore/bc_x#Activity/5a443a91-4fdc-487c-880d-3deead74f839', NULL, NULL, NULL, NULL, 183, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(186, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create your own domain model for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#Activity/56a0884d-dd31-4c1c-b871-c9674c0c3535', NULL, NULL, NULL, NULL, 185, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(196, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#Activity/2c7d8a63-e297-43df-8fe7-862923ea70b3', NULL, NULL, NULL, NULL, 195, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(217, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Software engineering0', 'http://intelleo.org/triplestore/bc_x#Activity/b5974c3c-6eb5-4e6b-aeac-32b1dac40af3', NULL, NULL, NULL, NULL, 216, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(219, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop your own application for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#Activity/4760b438-d35c-4f44-addd-cbd60a35f182', NULL, NULL, NULL, NULL, 218, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(252, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#Activity/f1b7e420-6b0e-44d4-95a3-a28308b2fdb4', NULL, NULL, NULL, NULL, 251, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(254, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop design documentation: case study0', 'http://intelleo.org/triplestore/bc_x#Activity/0f0589aa-6bc6-4afd-bd68-8cd9325ee520', NULL, NULL, NULL, NULL, 253, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(296, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software design strategies - introduction0', 'http://intelleo.org/triplestore/bc_x#Activity/9ca01ca7-6ae2-4556-be90-89a167325cf3', NULL, NULL, NULL, NULL, 295, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(298, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop design documentation: practice0', 'http://intelleo.org/triplestore/bc_x#Activity/09af0007-50db-4c86-9a22-52b0252e4957', NULL, NULL, NULL, NULL, 297, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(356, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn the basics of the Semantic Web technologies0', 'http://intelleo.org/triplestore/bc_x#Activity/e5cc09da-5172-4379-bc7e-0654ac6cbb60', NULL, NULL, NULL, NULL, 355, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(367, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Take an OWL tutorial0', 'http://intelleo.org/triplestore/bc_x#Activity/f1439aff-9c82-4601-b0b7-d8f7ba3da876', NULL, NULL, NULL, NULL, 366, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(372, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Practice OWL through examples0', 'http://intelleo.org/triplestore/bc_x#Activity/e1814534-9a21-40bf-ada0-0263f0bc18fb', NULL, NULL, NULL, NULL, 371, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(385, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Familiarize yourself with Linked Data concepts and principles0', 'http://intelleo.org/triplestore/bc_x#Activity/92074889-3299-4b01-bfb3-9780cec93b64', NULL, NULL, NULL, NULL, 384, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(387, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Take an OWL tutorial0', 'http://intelleo.org/triplestore/bc_x#Activity/85516ede-03c2-4c69-afaf-c2660083a6df', NULL, NULL, NULL, NULL, 386, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(393, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn how to make use of the existing ontologies on the Web0', 'http://intelleo.org/triplestore/bc_x#Activity/00e233dd-5fe2-4819-8217-3bafa624e550', NULL, NULL, NULL, NULL, 392, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(401, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Familiarize yourself with Linked Data concepts and principles0', 'http://intelleo.org/triplestore/bc_x#Activity/2f7d934d-d096-463c-ba9c-d49f74edc448', NULL, NULL, NULL, NULL, 400, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(407, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn the basics of OWL language0', 'http://intelleo.org/triplestore/bc_x#Activity/f1b441a4-e344-4dd3-9fe8-cf1a1adc4298', NULL, NULL, NULL, NULL, 406, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(413, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn about ontology engineering methodologies0', 'http://intelleo.org/triplestore/bc_x#Activity/bd656d27-5191-4441-9c3b-f6255968cf09', NULL, NULL, NULL, NULL, 412, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(418, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Check the discussion about OWL at practitioners forums0', 'http://intelleo.org/triplestore/bc_x#Activity/71f13d8a-4a08-4759-80b2-18e19ca78edb', NULL, NULL, NULL, NULL, 417, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(451, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Take a Protege OWL tutorial0', 'http://intelleo.org/triplestore/bc_x#Activity/0396fb73-55d8-4ef2-9542-a1536214fc77', NULL, NULL, NULL, NULL, 450, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(454, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Do some practice through examples0', 'http://intelleo.org/triplestore/bc_x#Activity/4ea4bd52-b353-4e2a-ab41-c5e5cc40380a', NULL, NULL, NULL, NULL, 453, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Activity` VALUES(456, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create in Protege your own OWL ontology for the chosen domain0', 'http://intelleo.org/triplestore/bc_x#Activity/74e36ef2-2754-4be0-88ce-34789eb04567', NULL, NULL, NULL, NULL, 455, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Activity_ContentUnit`
--

CREATE TABLE `Activity_ContentUnit` (
  `Activity_id` bigint(20) NOT NULL,
  `contents_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_ContentUnit`
--

INSERT INTO `Activity_ContentUnit` VALUES(184, 180);
INSERT INTO `Activity_ContentUnit` VALUES(217, 213);
INSERT INTO `Activity_ContentUnit` VALUES(252, 248);
INSERT INTO `Activity_ContentUnit` VALUES(296, 248);
INSERT INTO `Activity_ContentUnit` VALUES(356, 347);
INSERT INTO `Activity_ContentUnit` VALUES(356, 352);
INSERT INTO `Activity_ContentUnit` VALUES(367, 359);
INSERT INTO `Activity_ContentUnit` VALUES(367, 363);
INSERT INTO `Activity_ContentUnit` VALUES(372, 369);
INSERT INTO `Activity_ContentUnit` VALUES(385, 376);
INSERT INTO `Activity_ContentUnit` VALUES(385, 381);
INSERT INTO `Activity_ContentUnit` VALUES(387, 359);
INSERT INTO `Activity_ContentUnit` VALUES(387, 363);
INSERT INTO `Activity_ContentUnit` VALUES(393, 390);
INSERT INTO `Activity_ContentUnit` VALUES(401, 381);
INSERT INTO `Activity_ContentUnit` VALUES(401, 397);
INSERT INTO `Activity_ContentUnit` VALUES(407, 403);
INSERT INTO `Activity_ContentUnit` VALUES(407, 363);
INSERT INTO `Activity_ContentUnit` VALUES(413, 409);
INSERT INTO `Activity_ContentUnit` VALUES(418, 415);
INSERT INTO `Activity_ContentUnit` VALUES(451, 446);
INSERT INTO `Activity_ContentUnit` VALUES(454, 369);

-- --------------------------------------------------------

--
-- Table structure for table `Activity_event_Event`
--

CREATE TABLE `Activity_event_Event` (
  `Activity_id` bigint(20) NOT NULL,
  `events_id` bigint(20) NOT NULL,
  UNIQUE KEY `events_id` (`events_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_event_Event`
--


-- --------------------------------------------------------

--
-- Table structure for table `Activity_followingActivity`
--

CREATE TABLE `Activity_followingActivity` (
  `Activity_id` bigint(20) NOT NULL,
  `followingActivities_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_followingActivity`
--


-- --------------------------------------------------------

--
-- Table structure for table `Activity_parallelActivity`
--

CREATE TABLE `Activity_parallelActivity` (
  `Activity_id` bigint(20) NOT NULL,
  `parallelActivities_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_parallelActivity`
--


-- --------------------------------------------------------

--
-- Table structure for table `Activity_precedingActivity`
--

CREATE TABLE `Activity_precedingActivity` (
  `Activity_id` bigint(20) NOT NULL,
  `precedingActivities_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_precedingActivity`
--


-- --------------------------------------------------------

--
-- Table structure for table `Activity_requireKnowledgeAsset`
--

CREATE TABLE `Activity_requireKnowledgeAsset` (
  `Activity_id` bigint(20) NOT NULL,
  `requiresKA_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_requireKnowledgeAsset`
--

INSERT INTO `Activity_requireKnowledgeAsset` VALUES(184, 182);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(217, 215);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(227, 225);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(252, 250);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(262, 260);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(281, 279);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(296, 250);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(306, 304);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(325, 323);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(356, 349);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(356, 354);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(367, 365);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(372, 370);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(385, 378);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(385, 383);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(387, 361);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(387, 365);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(393, 391);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(401, 383);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(401, 399);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(407, 405);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(407, 365);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(413, 411);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(418, 416);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(451, 448);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(454, 370);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(972, 970);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(1000, 998);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(1027, 1025);
INSERT INTO `Activity_requireKnowledgeAsset` VALUES(1053, 1051);

-- --------------------------------------------------------

--
-- Table structure for table `Activity_workflowPrerequisite`
--

CREATE TABLE `Activity_workflowPrerequisite` (
  `Activity_id` bigint(20) NOT NULL,
  `prerequisites_id` bigint(20) NOT NULL,
  UNIQUE KEY `prerequisites_id` (`prerequisites_id`),
  KEY `FK74134F253EBDFCD5` (`prerequisites_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Activity_workflowPrerequisite`
--


-- --------------------------------------------------------

--
-- Table structure for table `AddAnnotationEvent`
--

CREATE TABLE `AddAnnotationEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `annotationRef_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9531b4f48bba14c1ea` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AddAnnotationEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Agent`
--

CREATE TABLE `Agent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e5` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Agent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Agent_Resource`
--

CREATE TABLE `Agent_Resource` (
  `Agent_id` bigint(20) NOT NULL,
  `emails_id` bigint(20) NOT NULL,
  UNIQUE KEY `emails_id` (`emails_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Agent_Resource`
--

INSERT INTO `Agent_Resource` VALUES(23, 4);
INSERT INTO `Agent_Resource` VALUES(51, 37);
INSERT INTO `Agent_Resource` VALUES(66, 52);
INSERT INTO `Agent_Resource` VALUES(81, 67);
INSERT INTO `Agent_Resource` VALUES(96, 82);
INSERT INTO `Agent_Resource` VALUES(111, 97);
INSERT INTO `Agent_Resource` VALUES(126, 112);
INSERT INTO `Agent_Resource` VALUES(141, 127);
INSERT INTO `Agent_Resource` VALUES(156, 142);
INSERT INTO `Agent_Resource` VALUES(171, 157);
INSERT INTO `Agent_Resource` VALUES(526, 512);
INSERT INTO `Agent_Resource` VALUES(541, 527);
INSERT INTO `Agent_Resource` VALUES(556, 542);
INSERT INTO `Agent_Resource` VALUES(571, 557);
INSERT INTO `Agent_Resource` VALUES(586, 572);
INSERT INTO `Agent_Resource` VALUES(601, 587);
INSERT INTO `Agent_Resource` VALUES(616, 602);
INSERT INTO `Agent_Resource` VALUES(631, 617);
INSERT INTO `Agent_Resource` VALUES(646, 632);
INSERT INTO `Agent_Resource` VALUES(661, 647);
INSERT INTO `Agent_Resource` VALUES(766, 752);
INSERT INTO `Agent_Resource` VALUES(781, 767);
INSERT INTO `Agent_Resource` VALUES(796, 782);
INSERT INTO `Agent_Resource` VALUES(811, 797);
INSERT INTO `Agent_Resource` VALUES(826, 812);
INSERT INTO `Agent_Resource` VALUES(841, 827);
INSERT INTO `Agent_Resource` VALUES(856, 842);
INSERT INTO `Agent_Resource` VALUES(871, 857);
INSERT INTO `Agent_Resource` VALUES(886, 872);
INSERT INTO `Agent_Resource` VALUES(901, 887);

-- --------------------------------------------------------

--
-- Table structure for table `Annotation`
--

CREATE TABLE `Annotation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD10` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Annotation`
--


-- --------------------------------------------------------

--
-- Table structure for table `AnnotationEvent`
--

CREATE TABLE `AnnotationEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `annotationRef_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9531b4f48b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `AnnotationEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `annotation_Like`
--

CREATE TABLE `annotation_Like` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD106e7d96c7` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f6e7d96c7` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `annotation_Like`
--


-- --------------------------------------------------------

--
-- Table structure for table `ArchiveEvent`
--

CREATE TABLE `ArchiveEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95a3fe1f18` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ArchiveEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Bookmark`
--

CREATE TABLE `Bookmark` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `bookmarkURL` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD107b620956` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f7b620956` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Bookmark`
--

INSERT INTO `Bookmark` VALUES(944, NULL, NULL, NULL, 'RDF is a standard model for data interchange on the Web.0', NULL, NULL, NULL, 'RDF - Semantic Web Standards0', 'http://intelleo.org/triplestore/bc_x#Bookmark/2d3a9381-77cf-4d3a-a371-eb8d3b356874', NULL, NULL, NULL, NULL, 943, NULL, 96, 'http://www.w3.org/RDF/0');
INSERT INTO `Bookmark` VALUES(948, NULL, NULL, NULL, 'The Semantic Web is the extension of the World Wide Web that enables people to share content beyond the boundaries of applications and websites.0', NULL, NULL, NULL, 'semanticweb.org0', 'http://intelleo.org/triplestore/bc_x#Bookmark/9b309c6a-69ed-43c5-a736-1100e76feb89', NULL, NULL, NULL, NULL, 947, NULL, 23, 'http://semanticweb.org0');
INSERT INTO `Bookmark` VALUES(951, NULL, NULL, NULL, 'SPARQL By Example - A Tutorial0', NULL, NULL, NULL, 'SPARQL By Example0', 'http://intelleo.org/triplestore/bc_x#Bookmark/aad4a4ab-191a-44df-8a13-7bb70c197be4', NULL, NULL, NULL, NULL, 950, NULL, 23, 'http://www.cambridgesemantics.com/2008/09/sparql-by-example/0');
INSERT INTO `Bookmark` VALUES(954, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Protege;: Using SPARQL in Protege-OWL0', 'http://intelleo.org/triplestore/bc_x#Bookmark/5fa773d5-6721-4bc4-806d-78833fe5c87c', NULL, NULL, NULL, NULL, 953, NULL, 96, 'http://protege.stanford.edu/doc/sparql/0');
INSERT INTO `Bookmark` VALUES(957, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'W3C Semantic Web Activitys0', 'http://intelleo.org/triplestore/bc_x#Bookmark/c3267122-fabf-4a32-894c-399ac06ed7ed', NULL, NULL, NULL, NULL, 956, NULL, 96, 'http://www.w3.org/2001/sw/0');
INSERT INTO `Bookmark` VALUES(960, NULL, NULL, NULL, 'In a nutshell, we strive to help our clients remove complexity from existing systems. We do this by first understanding and documenting that complexity.0', NULL, NULL, NULL, 'Semantic Arts - Semantic and Service Oriented Architects0', 'http://intelleo.org/triplestore/bc_x#Bookmark/621fa52e-2a5a-4c21-9599-f769535fa5b8', NULL, NULL, NULL, NULL, 959, NULL, 96, 'http://semanticarts.com/0');
INSERT INTO `Bookmark` VALUES(963, NULL, NULL, NULL, '4store includes a SPARQL HTTP protocol server, which can answer SPARQL queries using the standard SPARQL HTTP query protocol among other features.0', NULL, NULL, NULL, 'SparqlServer 4store0', 'http://intelleo.org/triplestore/bc_x#Bookmark/f6439ae0-8e2b-4c8d-833f-661016891811', NULL, NULL, NULL, NULL, 962, NULL, 23, 'http://4store.org/trac/wiki/SparqlServer0');

-- --------------------------------------------------------

--
-- Table structure for table `BookmarkEvent`
--

CREATE TABLE `BookmarkEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `annotationRef_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9531b4f48b443fdee4` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `BookmarkEvent`
--

INSERT INTO `BookmarkEvent` VALUES(946, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/e77210d3-cf2b-413d-94c7-9464ea83b4ea', NULL, NULL, NULL, NULL, 945, NULL, '2012-03-23 13:07:35', 23, NULL, 944);
INSERT INTO `BookmarkEvent` VALUES(949, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/77062e21-0090-4158-9be3-36266be313a4', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 23, NULL, 948);
INSERT INTO `BookmarkEvent` VALUES(952, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/6fa25c81-13f2-45b6-ba82-12909d79196f', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 23, NULL, 951);
INSERT INTO `BookmarkEvent` VALUES(955, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/9eeb3958-0116-4318-820f-a27cd817746f', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 96, NULL, 954);
INSERT INTO `BookmarkEvent` VALUES(958, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/4020065f-9df1-4a0f-ac37-0fd05dfaaa2b', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 96, NULL, 957);
INSERT INTO `BookmarkEvent` VALUES(961, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/a6dee50d-9416-471b-b7c6-77b766737d00', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 96, NULL, 960);
INSERT INTO `BookmarkEvent` VALUES(964, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#BookmarkEvent/cb0439a3-57ad-44ef-b3b5-3fae2552cb37', NULL, NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 23, NULL, 963);

-- --------------------------------------------------------

--
-- Table structure for table `ChangeProgressEvent`
--

CREATE TABLE `ChangeProgressEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `newProgressValue` double DEFAULT NULL,
  `progressScaleUsed_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKCC6F767DBD6685B` (`progressScaleUsed_id`),
  KEY `FKEF86282E5F3CFD3218487c95cc6f767d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ChangeProgressEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Channel`
--

CREATE TABLE `Channel` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `collaborationMode` tinyblob,
  `os` varchar(255) DEFAULT NULL,
  `screenHeight` varchar(255) DEFAULT NULL,
  `screenWidth` varchar(255) DEFAULT NULL,
  `viewportHeight` varchar(255) DEFAULT NULL,
  `viewportWidth` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD325e4ad9f38f4414e3` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Channel`
--


-- --------------------------------------------------------

--
-- Table structure for table `Comment`
--

CREATE TABLE `Comment` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD109bde863f` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f9bde863f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Comment`
--

INSERT INTO `Comment` VALUES(345, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/fa63d484-8ee5-44a1-b86b-54cda0a8405f', NULL, 51, NULL, NULL, NULL, NULL, 51, 'very useful for getting an overall understanding of the SemWeb technology');
INSERT INTO `Comment` VALUES(350, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/ed6be61f-01da-4647-b6a0-3fcba2c55dd0', NULL, 66, NULL, NULL, NULL, NULL, 66, 'not very useful; hard to follow');
INSERT INTO `Comment` VALUES(357, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/00f478d9-e0d0-4acf-b180-e6ba9602f9ef', NULL, 126, NULL, NULL, NULL, NULL, 126, 'very interesting and useful - recommend');
INSERT INTO `Comment` VALUES(379, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/89fe9263-35ed-406b-8ee3-ce6cc990958f', NULL, 81, NULL, NULL, NULL, NULL, 81, 'Good set of slides - amusing and useful');
INSERT INTO `Comment` VALUES(388, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/22655c4c-ba4a-4133-853c-6f6e2f93a13b', NULL, 96, NULL, NULL, NULL, NULL, 96, 'difficult to follow, requires good understanding of owl and ontology development in general');
INSERT INTO `Comment` VALUES(449, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/e1e559a6-d5a6-4aa8-8d60-0084eb9424b3', NULL, 126, NULL, NULL, NULL, NULL, 126, 'Very useful tutorial both for OWL and Protege');
INSERT INTO `Comment` VALUES(452, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Comment/e388962d-7539-4b80-8bd4-296027836ef2', NULL, 23, NULL, NULL, NULL, NULL, 23, 'It was not easy to accomplish');

-- --------------------------------------------------------

--
-- Table structure for table `Competence`
--

CREATE TABLE `Competence` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `competencedescription` varchar(255) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324b6a73e9` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence`
--

INSERT INTO `Competence` VALUES(175, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#Competence/73af7e05-12fc-476d-ba29-4addeeeae15f', NULL, 25, NULL, NULL, 174, NULL, NULL);
INSERT INTO `Competence` VALUES(190, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#Competence/6b3034d7-e14e-47b0-a227-03a2ed458e35', NULL, 25, NULL, NULL, 189, NULL, NULL);
INSERT INTO `Competence` VALUES(242, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#Competence/5d59d569-d9d8-4014-b51a-97085432ddb2', NULL, 25, NULL, NULL, 241, NULL, NULL);
INSERT INTO `Competence` VALUES(340, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to formalize domain model using OWL ontology language0', 'http://intelleo.org/triplestore/bc_x#Competence/7cbd13d3-071a-42b2-9229-1a414cb25116', NULL, 26, NULL, NULL, 339, NULL, NULL);
INSERT INTO `Competence` VALUES(440, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to use the Protege ontology editor for ontology development0', 'http://intelleo.org/triplestore/bc_x#Competence/3b5c1278-6845-46de-a57d-0b9d0f448b44', NULL, NULL, NULL, NULL, 439, NULL, NULL);
INSERT INTO `Competence` VALUES(991, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Competence` VALUES(1019, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Competence` VALUES(1045, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Competence` VALUES(1071, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Competence` VALUES(1073, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Competence` VALUES(1076, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', '', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `CompetenceAssociationAnnotation`
--

CREATE TABLE `CompetenceAssociationAnnotation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `competence` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD1096094e27` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f96094e27` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CompetenceAssociationAnnotation`
--


-- --------------------------------------------------------

--
-- Table structure for table `CompetenceLevel`
--

CREATE TABLE `CompetenceLevel` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `levelValue` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32161d411b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CompetenceLevel`
--

INSERT INTO `CompetenceLevel` VALUES(176, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/competences/ns/Advanced', NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `CompetenceLevel` VALUES(209, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/competences/ns/Beginner', NULL, NULL, NULL, NULL, NULL, 0);
INSERT INTO `CompetenceLevel` VALUES(433, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/competences/ns/Intermediate', NULL, NULL, NULL, NULL, NULL, 0);

-- --------------------------------------------------------

--
-- Table structure for table `CompetenceRecord`
--

CREATE TABLE `CompetenceRecord` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `recordedDate` datetime DEFAULT NULL,
  `competence_id` bigint(20) DEFAULT NULL,
  `recordedLevel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKB7BF799A658D5730` (`recordedLevel_id`),
  KEY `FKEF86282E5F3CFD32b7bf799a` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `CompetenceRecord`
--

INSERT INTO `CompetenceRecord` VALUES(435, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetenceRecord/e7323122-0a78-4f85-be63-b16c27b673de', NULL, NULL, NULL, NULL, 434, '2012-03-22 13:06:45', 340, 433);
INSERT INTO `CompetenceRecord` VALUES(966, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetenceRecord/7a80c963-0dc5-4f7c-aa59-0f724e540851', NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:35', 175, 433);
INSERT INTO `CompetenceRecord` VALUES(994, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetenceRecord/439dc5f0-f31d-4911-8206-b21ae5ea8a72', NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:07:43', 175, 209);
INSERT INTO `CompetenceRecord` VALUES(1021, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetenceRecord/b9fbc570-3dd3-454c-a9dd-055913b99449', NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:08:52', 175, 209);
INSERT INTO `CompetenceRecord` VALUES(1047, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetenceRecord/4cc8cca2-8f90-43b3-bef6-8682c6adc1ef', NULL, NULL, NULL, NULL, NULL, '2012-03-23 13:11:03', 175, 176);

-- --------------------------------------------------------

--
-- Table structure for table `Competence_Competence`
--

CREATE TABLE `Competence_Competence` (
  `Competence_id` bigint(20) NOT NULL,
  `children_id` bigint(20) NOT NULL,
  UNIQUE KEY `children_id` (`children_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence_Competence`
--


-- --------------------------------------------------------

--
-- Table structure for table `Competence_domainTopics_Concept`
--

CREATE TABLE `Competence_domainTopics_Concept` (
  `Competence_id` bigint(20) NOT NULL,
  `domainTopics_id` bigint(20) NOT NULL,
  KEY `FK488B8AA74157E4F5` (`domainTopics_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence_domainTopics_Concept`
--


-- --------------------------------------------------------

--
-- Table structure for table `Competence_prerequisiteForCompetences_Competence`
--

CREATE TABLE `Competence_prerequisiteForCompetences_Competence` (
  `Competence_id` bigint(20) NOT NULL,
  `prerequisiteForCompetences_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence_prerequisiteForCompetences_Competence`
--


-- --------------------------------------------------------

--
-- Table structure for table `Competence_requiredCompetences_Competence`
--

CREATE TABLE `Competence_requiredCompetences_Competence` (
  `Competence_id` bigint(20) NOT NULL,
  `requiredCompetences_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence_requiredCompetences_Competence`
--

INSERT INTO `Competence_requiredCompetences_Competence` VALUES(440, 340);

-- --------------------------------------------------------

--
-- Table structure for table `Competence_skills_Concept`
--

CREATE TABLE `Competence_skills_Concept` (
  `Competence_id` bigint(20) NOT NULL,
  `skills_id` bigint(20) NOT NULL,
  KEY `FK521F6261168B395B` (`skills_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Competence_skills_Concept`
--


-- --------------------------------------------------------

--
-- Table structure for table `Concept`
--

CREATE TABLE `Concept` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `conceptScheme` tinyblob,
  `topConceptInScheme` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD329be81248` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Concept`
--


-- --------------------------------------------------------

--
-- Table structure for table `Concept_broader_concept`
--

CREATE TABLE `Concept_broader_concept` (
  `Concept_id` bigint(20) NOT NULL,
  `broaderConcepts_id` bigint(20) NOT NULL,
  KEY `FKC855CCE12C654575` (`Concept_id`),
  KEY `FKC855CCE16D6FDFE3` (`broaderConcepts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Concept_broader_concept`
--


-- --------------------------------------------------------

--
-- Table structure for table `Concept_narrower_concept`
--

CREATE TABLE `Concept_narrower_concept` (
  `Concept_id` bigint(20) NOT NULL,
  `narrowerConcepts_id` bigint(20) NOT NULL,
  KEY `FKA8046C882C654575` (`Concept_id`),
  KEY `FKA8046C885A3F5EAA` (`narrowerConcepts_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Concept_narrower_concept`
--


-- --------------------------------------------------------

--
-- Table structure for table `ContentUnit`
--

CREATE TABLE `ContentUnit` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `follows` tinyblob,
  `href` tinyblob,
  `isPartOf` tinyblob,
  `precedes` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324c38457d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContentUnit`
--

INSERT INTO `ContentUnit` VALUES(180, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/2be8373f-b6f3-4ed3-8b00-2236211a848b', NULL, NULL, NULL, NULL, 179, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740047687474703a2f2f7777772e736c69646573686172652e6e65742f7369676e65722f696e74726f64756374696f6e2d616e642d636f6e6365707475616c2d6d6f64656c6c696e673078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(213, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software engineering for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/89b5fd62-a1a8-4d32-ad62-c74f61eefbe6', NULL, NULL, NULL, NULL, 212, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740047687474703a2f2f7777772e736c69646573686172652e6e65742f7369676e65722f696e74726f64756374696f6e2d616e642d636f6e6365707475616c2d6d6f64656c6c696e673078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(248, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software high-level design0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/4bef0237-b8d4-4cb8-8aa2-08e53351018e', NULL, NULL, NULL, NULL, 247, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740047687474703a2f2f7777772e736c69646573686172652e6e65742f7369676e65722f696e74726f64756374696f6e2d616e642d636f6e6365707475616c2d6d6f64656c6c696e673078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(347, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: A short Tutorial on Semantic Web0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/61dce80c-593a-4aae-9dff-be0fdcd52616', NULL, NULL, NULL, NULL, 346, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002f687474703a2f2f766964656f6c656374757265732e6e65742f747261696e696e6730365f737572655f737473772f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(352, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Semantic Web - Introduction and Overview0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/aeae2468-5d0f-4f5f-b3ee-da23933d00a2', NULL, NULL, NULL, NULL, 351, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740037687474703a2f2f647265742e6e65742f6e6574647265742f646f63732f77696c64652d65696e69726173323030352d73656d7765622f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(359, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: An Introduction to OWL0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/87bd6fd4-3ece-4b4b-a910-9d59f438ad88', NULL, NULL, NULL, NULL, 358, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002f687474703a2f2f766964656f6c656374757265732e6e65742f747261696e696e6730365f737572655f737473772f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(363, NULL, NULL, NULL, 'the official, W3C OWL tutorial0', NULL, NULL, NULL, 'W3C OWL Primer0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/73bfb5b7-d084-4778-b286-411ef11cd787', NULL, NULL, NULL, NULL, 362, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740022687474703a2f2f7777772e77332e6f72672f54522f6f776c322d7072696d65722f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(369, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OWL Reasoning Examples and Hands-On Session0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/a19f9431-c3d1-4fba-aec6-952aa846f467', NULL, NULL, NULL, NULL, 368, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002d687474703a2f2f6f776c2e63732e6d616e636865737465722e61632e756b2f323030392f30372f737373772f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(376, NULL, NULL, NULL, 'This talk will cover the basic concepts and techniques of publishing and using Linked Data, assuming some familiarity with programming and the Web. No prior knowledge of Semantic Web technologies is required.0', NULL, NULL, NULL, 'Video: An Introduction to Linked Data0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/de608b52-743b-4e97-9432-234abed25271', NULL, NULL, NULL, NULL, 375, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074001a687474703a2f2f76696d656f2e636f6d2f31323434343236303078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(381, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Slides: Hello Open Data World0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/cfd8f137-a0aa-45f7-bb56-0e7096aa59eb', NULL, NULL, NULL, NULL, 380, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740041687474703a2f2f7777772e736c69646573686172652e6e65742f74657272616365732f68656c6c6f2d6f70656e2d776f726c642d73656d746563682d323030393078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(390, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: Learning from the Masters: Understanding Ontologies found on the Web 0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/d8e93cf2-110f-454f-9494-26bbec088ecb', NULL, NULL, NULL, NULL, 389, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002d687474703a2f2f766964656f6c656374757265732e6e65742f6973776330365f7061727369615f756f66772f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(397, NULL, NULL, NULL, 'Tim Berners Lee illustrates Linked Data through an analogy with a bag of potato chips0', NULL, NULL, NULL, 'Linked Data in Plain English0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/1503d042-6181-4956-97e1-704a49219488', NULL, NULL, NULL, NULL, 396, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740041687474703a2f2f7777772e77332e6f72672f51412f323031302f30352f6c696e6b65645f646174615f6974735f69735f6e6f745f6c696b655f74682e68746d6c3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(403, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: OWL0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/d2515673-af99-41bb-83de-c1b759704fe9', NULL, NULL, NULL, NULL, 402, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002c687474703a2f2f766964656f6c656374757265732e6e65742f6b6f6d6c30345f6861726d656c656e5f6f2f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(409, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: Ontology Engineering Methodologies0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/bf21db6c-3e3d-4238-98f5-2ec36b1376d0', NULL, NULL, NULL, NULL, 408, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074002b687474703a2f2f766964656f6c656374757265732e6e65742f6973776330375f706572657a5f6f656d2f3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(415, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OWL-related discussions on semanticoveflow.com 0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/1b3047f3-34c7-4304-8f95-fee38e884c1c', NULL, NULL, NULL, NULL, 414, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b7870740035687474703a2f2f7777772e73656d616e7469636f766572666c6f772e636f6d2f7175657374696f6e732f7461676765642f6f776c3078, NULL, NULL);
INSERT INTO `ContentUnit` VALUES(446, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Protege OWL tutorial0', 'http://intelleo.org/triplestore/bc_x#ContentUnit/49b6ce76-3a51-4e02-a845-9a1ff785e648', NULL, NULL, NULL, NULL, 445, NULL, 0xaced00057372000c6a6176612e6e65742e555249ac01782e439e49ab0300014c0006737472696e677400124c6a6176612f6c616e672f537472696e673b787074003d687474703a2f2f6f776c2e63732e6d616e636865737465722e61632e756b2f7475746f7269616c732f70726f746567656f776c7475746f7269616c2f3078, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ContentUnit_authors`
--

CREATE TABLE `ContentUnit_authors` (
  `ContentUnit_id` bigint(20) NOT NULL,
  `authors` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ContentUnit_authors`
--


-- --------------------------------------------------------

--
-- Table structure for table `DetachEvent`
--

CREATE TABLE `DetachEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `detachedFrom_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95a391d6a7` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DetachEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Document`
--

CREATE TABLE `Document` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `documentidentifier` tinyblob,
  `maker` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK3737353BC86FA505` (`maker`),
  KEY `FKEF86282E5F3CFD323737353b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Document`
--


-- --------------------------------------------------------

--
-- Table structure for table `Document_domainTopic_Resource`
--

CREATE TABLE `Document_domainTopic_Resource` (
  `Document_id` bigint(20) NOT NULL,
  `domainTopics_id` bigint(20) NOT NULL,
  KEY `FKE7CF3A6442D9E4D` (`Document_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Document_domainTopic_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Document_primaryTopics_Resource`
--

CREATE TABLE `Document_primaryTopics_Resource` (
  `Document_id` bigint(20) NOT NULL,
  `primaryTopics_id` bigint(20) NOT NULL,
  KEY `FKCB5D260B442D9E4D` (`Document_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Document_primaryTopics_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Duty_assignedToPositions_OrganizationalPosition`
--

CREATE TABLE `Duty_assignedToPositions_OrganizationalPosition` (
  `org_Duty_id` bigint(20) NOT NULL,
  `assignedToPositions_id` bigint(20) NOT NULL,
  KEY `FK625896EAF98092D` (`org_Duty_id`),
  KEY `FK625896E4FC3DE4E` (`assignedToPositions_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Duty_assignedToPositions_OrganizationalPosition`
--


-- --------------------------------------------------------

--
-- Table structure for table `Duty_requiredCompetences_CompetenceRequirement`
--

CREATE TABLE `Duty_requiredCompetences_CompetenceRequirement` (
  `org_Duty_id` bigint(20) NOT NULL,
  `requiredCompetences_id` bigint(20) NOT NULL,
  KEY `FK3A4A59FDAF98092D` (`org_Duty_id`),
  KEY `FK3A4A59FD341C41FB` (`requiredCompetences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Duty_requiredCompetences_CompetenceRequirement`
--

INSERT INTO `Duty_requiredCompetences_CompetenceRequirement` VALUES(460, 178);
INSERT INTO `Duty_requiredCompetences_CompetenceRequirement` VALUES(460, 342);
INSERT INTO `Duty_requiredCompetences_CompetenceRequirement` VALUES(460, 442);
INSERT INTO `Duty_requiredCompetences_CompetenceRequirement` VALUES(461, 192);
INSERT INTO `Duty_requiredCompetences_CompetenceRequirement` VALUES(461, 244);

-- --------------------------------------------------------

--
-- Table structure for table `Edit`
--

CREATE TABLE `Edit` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9520e22a` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Edit`
--


-- --------------------------------------------------------

--
-- Table structure for table `EmailPreferences_notificationFrequency_TimeFrame`
--

CREATE TABLE `EmailPreferences_notificationFrequency_TimeFrame` (
  `user_EmailPreferences_id` bigint(20) NOT NULL,
  `notificationFrequency_id` bigint(20) NOT NULL,
  KEY `FK4026E0F78E66B3` (`notificationFrequency_id`),
  KEY `FK4026E0F27B0619C` (`user_EmailPreferences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `EmailPreferences_notificationFrequency_TimeFrame`
--

INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(466, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(470, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(474, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(478, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(482, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(486, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(490, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(494, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(498, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(502, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(675, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(679, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(683, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(687, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(691, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(695, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(699, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(703, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(707, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(711, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(715, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(719, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(723, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(727, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(731, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(735, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(739, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(743, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(747, 465);
INSERT INTO `EmailPreferences_notificationFrequency_TimeFrame` VALUES(751, 465);

-- --------------------------------------------------------

--
-- Table structure for table `Environment`
--

CREATE TABLE `Environment` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `collaborationMode` tinyblob,
  `os` varchar(255) DEFAULT NULL,
  `screenHeight` varchar(255) DEFAULT NULL,
  `screenWidth` varchar(255) DEFAULT NULL,
  `viewportHeight` varchar(255) DEFAULT NULL,
  `viewportWidth` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD325e4ad9f3` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Environment`
--


-- --------------------------------------------------------

--
-- Table structure for table `events_Add`
--

CREATE TABLE `events_Add` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `addedToResource` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c953bbbdc5b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `events_Add`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_Create`
--

CREATE TABLE `event_Create` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95ed24d661` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_Create`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_Delete`
--

CREATE TABLE `event_Delete` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `oldParent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95ee25bb10` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_Delete`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_Event`
--

CREATE TABLE `event_Event` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_Event`
--


-- --------------------------------------------------------

--
-- Table structure for table `event_LikeEvent`
--

CREATE TABLE `event_LikeEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9582f88dbe` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `event_LikeEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Feedback`
--

CREATE TABLE `Feedback` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `difficulty` int(11) NOT NULL,
  `interest` int(11) NOT NULL,
  `quality` int(11) NOT NULL,
  `usefulness` int(11) NOT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKF8704FA597B83A1D` (`user_id`),
  KEY `FKF8704FA5A448F0FD` (`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `Feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `FoafGroup_members_Agent`
--

CREATE TABLE `FoafGroup_members_Agent` (
  `foaf_Group_id` bigint(20) NOT NULL,
  `members_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FoafGroup_members_Agent`
--


-- --------------------------------------------------------

--
-- Table structure for table `FoafGroup_roles_Role`
--

CREATE TABLE `FoafGroup_roles_Role` (
  `foaf_Group_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  KEY `FKD2B6DD861DE42BCD` (`roles_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FoafGroup_roles_Role`
--


-- --------------------------------------------------------

--
-- Table structure for table `FoafOrganization`
--

CREATE TABLE `FoafOrganization` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e59153fb21` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FoafOrganization`
--


-- --------------------------------------------------------

--
-- Table structure for table `FoafOrganization_Role`
--

CREATE TABLE `FoafOrganization_Role` (
  `FoafOrganization_id` bigint(20) NOT NULL,
  `roles_id` bigint(20) NOT NULL,
  KEY `FKD8A27EF41DE42BCD` (`roles_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FoafOrganization_Role`
--


-- --------------------------------------------------------

--
-- Table structure for table `FoafProject`
--

CREATE TABLE `FoafProject` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `projectidentifier` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3284cfc06b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FoafProject`
--


-- --------------------------------------------------------

--
-- Table structure for table `foaf_Group`
--

CREATE TABLE `foaf_Group` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e5b537398e` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `foaf_Group`
--


-- --------------------------------------------------------

--
-- Table structure for table `FollowEvent`
--

CREATE TABLE `FollowEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `followedResource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95c1269549` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `FollowEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `HelpRequest`
--

CREATE TABLE `HelpRequest` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `collaborationMode` tinyblob,
  `os` varchar(255) DEFAULT NULL,
  `screenHeight` varchar(255) DEFAULT NULL,
  `screenWidth` varchar(255) DEFAULT NULL,
  `viewportHeight` varchar(255) DEFAULT NULL,
  `viewportWidth` varchar(255) DEFAULT NULL,
  `active` tinyint(1) DEFAULT NULL,
  `requestText` varchar(255) DEFAULT NULL,
  `relatedToGoal_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `submittedBy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKE535E7EE94685AA9` (`submittedBy_id`),
  KEY `FKE535E7EE27592D68` (`relatedToGoal_id`),
  KEY `FKEF86282E5F3CFD325e4ad9f3e535e7ee` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpRequest`
--


-- --------------------------------------------------------

--
-- Table structure for table `HelpRequestEvent`
--

CREATE TABLE `HelpRequestEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `helpRequest` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95dd875f4c` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpRequestEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `HelpResponse`
--

CREATE TABLE `HelpResponse` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `collaborationMode` tinyblob,
  `os` varchar(255) DEFAULT NULL,
  `screenHeight` varchar(255) DEFAULT NULL,
  `screenWidth` varchar(255) DEFAULT NULL,
  `viewportHeight` varchar(255) DEFAULT NULL,
  `viewportWidth` varchar(255) DEFAULT NULL,
  `submittedBy` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD325e4ad9f3c4aecac2` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `HelpResponse`
--


-- --------------------------------------------------------

--
-- Table structure for table `hibernate_sequences`
--

CREATE TABLE `hibernate_sequences` (
  `sequence_name` varchar(255) DEFAULT NULL,
  `sequence_next_hi_value` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hibernate_sequences`
--

INSERT INTO `hibernate_sequences` VALUES('Resource', 1);

-- --------------------------------------------------------

--
-- Table structure for table `IgnoreRecommendationEvent`
--

CREATE TABLE `IgnoreRecommendationEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95c1b0130f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `IgnoreRecommendationEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Item_about_Resource`
--

CREATE TABLE `Item_about_Resource` (
  `sioc_Item_id` bigint(20) NOT NULL,
  `aboutResources_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item_about_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Item_addresed_to_Resource`
--

CREATE TABLE `Item_addresed_to_Resource` (
  `sioc_Item_id` bigint(20) NOT NULL,
  `addressedTo_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Item_addresed_to_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `JoinGroupEvent`
--

CREATE TABLE `JoinGroupEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `joinedGroup` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9598e35c45` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `JoinGroupEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `KnowledgeAsset_followingKnowledgeAsset_KnowledgeAsset`
--

CREATE TABLE `KnowledgeAsset_followingKnowledgeAsset_KnowledgeAsset` (
  `workflow_KnowledgeAsset_id` bigint(20) NOT NULL,
  `followingKnowledgeAssets_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `KnowledgeAsset_followingKnowledgeAsset_KnowledgeAsset`
--


-- --------------------------------------------------------

--
-- Table structure for table `KnowledgeAsset_precedingKnowledgeAsset_KnowledgeAsset`
--

CREATE TABLE `KnowledgeAsset_precedingKnowledgeAsset_KnowledgeAsset` (
  `workflow_KnowledgeAsset_id` bigint(20) NOT NULL,
  `precedingKnowledgeAssets_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `KnowledgeAsset_precedingKnowledgeAsset_KnowledgeAsset`
--


-- --------------------------------------------------------

--
-- Table structure for table `LearningGoalAssociation`
--

CREATE TABLE `LearningGoalAssociation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `learningGoal` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD10470aa850` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f470aa850` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LearningGoalAssociation`
--


-- --------------------------------------------------------

--
-- Table structure for table `LearningGoal_recommendedBy_User`
--

CREATE TABLE `LearningGoal_recommendedBy_User` (
  `user_LearningGoal_id` bigint(20) NOT NULL,
  `recommendedBy_id` bigint(20) NOT NULL,
  KEY `FKEB1C238651CE4149` (`recommendedBy_id`),
  KEY `FKEB1C2386A49B42BC` (`user_LearningGoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LearningGoal_recommendedBy_User`
--


-- --------------------------------------------------------

--
-- Table structure for table `LearningTask_Activity`
--

CREATE TABLE `LearningTask_Activity` (
  `workflow_LearningTask_id` bigint(20) NOT NULL,
  `learningActivities_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LearningTask_Activity`
--

INSERT INTO `LearningTask_Activity` VALUES(188, 184);
INSERT INTO `LearningTask_Activity` VALUES(188, 186);
INSERT INTO `LearningTask_Activity` VALUES(198, 196);
INSERT INTO `LearningTask_Activity` VALUES(206, 203);
INSERT INTO `LearningTask_Activity` VALUES(221, 217);
INSERT INTO `LearningTask_Activity` VALUES(221, 219);
INSERT INTO `LearningTask_Activity` VALUES(234, 227);
INSERT INTO `LearningTask_Activity` VALUES(234, 231);
INSERT INTO `LearningTask_Activity` VALUES(256, 252);
INSERT INTO `LearningTask_Activity` VALUES(256, 254);
INSERT INTO `LearningTask_Activity` VALUES(269, 262);
INSERT INTO `LearningTask_Activity` VALUES(269, 266);
INSERT INTO `LearningTask_Activity` VALUES(288, 281);
INSERT INTO `LearningTask_Activity` VALUES(288, 285);
INSERT INTO `LearningTask_Activity` VALUES(300, 296);
INSERT INTO `LearningTask_Activity` VALUES(300, 298);
INSERT INTO `LearningTask_Activity` VALUES(313, 306);
INSERT INTO `LearningTask_Activity` VALUES(313, 310);
INSERT INTO `LearningTask_Activity` VALUES(332, 325);
INSERT INTO `LearningTask_Activity` VALUES(332, 329);
INSERT INTO `LearningTask_Activity` VALUES(374, 356);
INSERT INTO `LearningTask_Activity` VALUES(374, 367);
INSERT INTO `LearningTask_Activity` VALUES(374, 372);
INSERT INTO `LearningTask_Activity` VALUES(395, 385);
INSERT INTO `LearningTask_Activity` VALUES(395, 387);
INSERT INTO `LearningTask_Activity` VALUES(395, 393);
INSERT INTO `LearningTask_Activity` VALUES(420, 401);
INSERT INTO `LearningTask_Activity` VALUES(420, 407);
INSERT INTO `LearningTask_Activity` VALUES(420, 413);
INSERT INTO `LearningTask_Activity` VALUES(420, 418);
INSERT INTO `LearningTask_Activity` VALUES(428, 425);
INSERT INTO `LearningTask_Activity` VALUES(458, 451);
INSERT INTO `LearningTask_Activity` VALUES(458, 454);
INSERT INTO `LearningTask_Activity` VALUES(458, 456);
INSERT INTO `LearningTask_Activity` VALUES(979, 972);
INSERT INTO `LearningTask_Activity` VALUES(979, 976);
INSERT INTO `LearningTask_Activity` VALUES(1007, 1000);
INSERT INTO `LearningTask_Activity` VALUES(1007, 1004);
INSERT INTO `LearningTask_Activity` VALUES(1034, 1027);
INSERT INTO `LearningTask_Activity` VALUES(1034, 1031);
INSERT INTO `LearningTask_Activity` VALUES(1060, 1053);
INSERT INTO `LearningTask_Activity` VALUES(1060, 1057);

-- --------------------------------------------------------

--
-- Table structure for table `LeaveGroupEvent`
--

CREATE TABLE `LeaveGroupEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `leftGroup` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95353bed52` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LeaveGroupEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_Event`
--

CREATE TABLE `logging_Event` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `datetime` datetime DEFAULT NULL,
  `eventtype_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `usersession_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK88726D9A6ED374FD` (`usersession_id`),
  KEY `FK88726D9A4E1409DD` (`eventtype_id`),
  KEY `FK88726D9AA448F0FD` (`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_Event`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_eventtype`
--

CREATE TABLE `logging_eventtype` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `eventtype` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `eventtype` (`eventtype`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_eventtype`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_Property`
--

CREATE TABLE `logging_Property` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `propkey` varchar(255) NOT NULL,
  `propvalue` varchar(255) NOT NULL,
  `event_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK305C02D5DECAE37D` (`event_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_Property`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_resource`
--

CREATE TABLE `logging_resource` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` longtext,
  `resourcetype` longtext NOT NULL,
  `uri` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `uri` (`uri`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_User`
--

CREATE TABLE `logging_User` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `evalUserNo` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `uri` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  UNIQUE KEY `uri` (`uri`),
  UNIQUE KEY `evalUserNo` (`evalUserNo`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_User`
--


-- --------------------------------------------------------

--
-- Table structure for table `logging_UserSession`
--

CREATE TABLE `logging_UserSession` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `sessionId` varchar(255) DEFAULT NULL,
  `sessionstarted` datetime DEFAULT NULL,
  `userEntity_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKB6D61F4B71F7539A` (`userEntity_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `logging_UserSession`
--


-- --------------------------------------------------------

--
-- Table structure for table `LoginEvent`
--

CREATE TABLE `LoginEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95d39a8d1` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LoginEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `LogoutEvent`
--

CREATE TABLE `LogoutEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95c916fb10` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `LogoutEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `MarkAsFavourite`
--

CREATE TABLE `MarkAsFavourite` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95a1e8536a` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MarkAsFavourite`
--


-- --------------------------------------------------------

--
-- Table structure for table `Message`
--

CREATE TABLE `Message` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `follows` tinyblob,
  `href` tinyblob,
  `isPartOf` tinyblob,
  `precedes` tinyblob,
  `attachment` tinyblob,
  `channel` tinyblob,
  `content` varchar(255) DEFAULT NULL,
  `dateTimeSent` datetime DEFAULT NULL,
  `replyOf` tinyblob,
  `sender` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324c38457d9c2397e7` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Message`
--


-- --------------------------------------------------------

--
-- Table structure for table `Microblog`
--

CREATE TABLE `Microblog` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `collaborationMode` tinyblob,
  `os` varchar(255) DEFAULT NULL,
  `screenHeight` varchar(255) DEFAULT NULL,
  `screenWidth` varchar(255) DEFAULT NULL,
  `viewportHeight` varchar(255) DEFAULT NULL,
  `viewportWidth` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD325e4ad9f38f4414e371cc8c46` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Microblog`
--


-- --------------------------------------------------------

--
-- Table structure for table `MicroblogPost`
--

CREATE TABLE `MicroblogPost` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `follows` tinyblob,
  `href` tinyblob,
  `isPartOf` tinyblob,
  `precedes` tinyblob,
  `attachment` tinyblob,
  `channel` tinyblob,
  `content` varchar(255) DEFAULT NULL,
  `dateTimeSent` datetime DEFAULT NULL,
  `replyOf` tinyblob,
  `sender` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324c38457d9c2397e764a70606` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `MicroblogPost`
--


-- --------------------------------------------------------

--
-- Table structure for table `NumericRating`
--

CREATE TABLE `NumericRating` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `scale` tinyblob,
  `ratingValue` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD10d2f821689eceaaea` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74fd2f821689eceaaea` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NumericRating`
--


-- --------------------------------------------------------

--
-- Table structure for table `NumericScale`
--

CREATE TABLE `NumericScale` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `maxValue` double NOT NULL,
  `minValue` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324c0192a894f325d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `NumericScale`
--

INSERT INTO `NumericScale` VALUES(6, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/annotations/ns/NumericScale1To5', NULL, NULL, NULL, NULL, NULL, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `OpenTabEvent`
--

CREATE TABLE `OpenTabEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `node` tinyblob,
  `serviceName` int(11) DEFAULT NULL,
  `tabName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95669f2c8f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `OpenTabEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `OrganizationalPosition_requiredCompetences_CompetenceRequirement`
--

CREATE TABLE `OrganizationalPosition_requiredCompetences_CompetenceRequirement` (
  `org_OrganizationalPosition_id` bigint(20) NOT NULL,
  `requiredCompetences_id` bigint(20) NOT NULL,
  KEY `FK867869CE7FECB4ED` (`org_OrganizationalPosition_id`),
  KEY `FK867869CE341C41FB` (`requiredCompetences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `OrganizationalPosition_requiredCompetences_CompetenceRequirement`
--


-- --------------------------------------------------------

--
-- Table structure for table `OrgDefinedCompetence`
--

CREATE TABLE `OrgDefinedCompetence` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `competencedescription` varchar(255) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324b6a73e9feb5844e` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `OrgDefinedCompetence`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_CompetenceRequirement`
--

CREATE TABLE `org_CompetenceRequirement` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `competence_id` bigint(20) DEFAULT NULL,
  `competenceLevel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKE499A17F5D191D49` (`competenceLevel_id`),
  KEY `FKEF86282E5F3CFD32e499a17f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_CompetenceRequirement`
--

INSERT INTO `org_CompetenceRequirement` VALUES(178, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#CompetenceRequirement/7c1d39df-c08e-4383-8dc0-3fb74321d3a7', NULL, 25, NULL, NULL, 177, 175, 176);
INSERT INTO `org_CompetenceRequirement` VALUES(192, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#CompetenceRequirement/d2007eb8-c082-4516-824b-9972e9acc5a6', NULL, 25, NULL, NULL, 191, 190, 176);
INSERT INTO `org_CompetenceRequirement` VALUES(244, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#CompetenceRequirement/66689c2d-a55c-4407-9070-93f0b06cf972', NULL, 25, NULL, NULL, 243, 242, 176);
INSERT INTO `org_CompetenceRequirement` VALUES(342, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to formalize domain model using OWL ontology language0', 'http://intelleo.org/triplestore/bc_x#CompetenceRequirement/9c115661-7876-4309-a6fe-a6a7edc38fbd', NULL, 26, NULL, NULL, 341, 340, 176);
INSERT INTO `org_CompetenceRequirement` VALUES(442, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to use the Protege ontology editor for ontology development0', 'http://intelleo.org/triplestore/bc_x#CompetenceRequirement/aab8d09d-c704-4f3c-8ab1-041ec04877ef', NULL, NULL, NULL, NULL, 441, 440, 176);

-- --------------------------------------------------------

--
-- Table structure for table `org_Duty`
--

CREATE TABLE `org_Duty` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324e476771` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Duty`
--

INSERT INTO `org_Duty` VALUES(460, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ontology Development0', 'http://intelleo.org/triplestore/bc_x#Duty/b2a91cf7-cb5f-4c21-ac76-289093aad375', NULL, NULL, NULL, NULL, 459);
INSERT INTO `org_Duty` VALUES(461, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software Systems Development0', 'http://intelleo.org/triplestore/bc_x#Duty/d9cbbca8-2101-46ac-afaf-5e9987aaa8be', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `org_IntelLEO`
--

CREATE TABLE `org_IntelLEO` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218a6f07b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_IntelLEO`
--

INSERT INTO `org_IntelLEO` VALUES(28, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#IntelLEO/ddee2fb1-e9cc-49c4-8813-afca72c16e29', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `org_IntelLEO_org_Organization`
--

CREATE TABLE `org_IntelLEO_org_Organization` (
  `org_IntelLEO_id` bigint(20) NOT NULL,
  `organizations_id` bigint(20) NOT NULL,
  UNIQUE KEY `organizations_id` (`organizations_id`),
  KEY `FK32186612CDD9B0DB` (`organizations_id`),
  KEY `FK32186612B07C34D` (`org_IntelLEO_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_IntelLEO_org_Organization`
--

INSERT INTO `org_IntelLEO_org_Organization` VALUES(28, 25);
INSERT INTO `org_IntelLEO_org_Organization` VALUES(28, 26);
INSERT INTO `org_IntelLEO_org_Organization` VALUES(28, 27);

-- --------------------------------------------------------

--
-- Table structure for table `org_Organization`
--

CREATE TABLE `org_Organization` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e59153fb2184e04ece` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Organization`
--

INSERT INTO `org_Organization` VALUES(1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FOS', 'http://intelleo.org/triplestore/bc_x#Organization/6dc75fb2-db8a-43c5-a77c-30b33adf469f', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Organization` VALUES(25, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'INI0', 'http://intelleo.org/triplestore/bc_x#Organization/e131f0be-5489-4f65-89eb-41bb545af8f0', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Organization` VALUES(26, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FOS0', 'http://intelleo.org/triplestore/bc_x#Organization/76bd544f-95ed-4808-a434-9c39aee63899', NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Organization` VALUES(27, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NetBeans User Group0', 'http://intelleo.org/triplestore/bc_x#Organization/216e83ef-9298-4a75-b8c2-2dd3aff8bae1', NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `org_OrganizationalPosition`
--

CREATE TABLE `org_OrganizationalPosition` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `allocatedToOrgUnit_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKB87E53C2AF5AADA4` (`allocatedToOrgUnit_id`),
  KEY `FKEF86282E5F3CFD32b87e53c2` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_OrganizationalPosition`
--

INSERT INTO `org_OrganizationalPosition` VALUES(3, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Senior Programmer', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/b87cb816-cab9-452b-8224-8470095717ed', NULL, NULL, NULL, NULL, NULL, 2);
INSERT INTO `org_OrganizationalPosition` VALUES(32, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Senior Programmer0', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/0b58edc9-fcdd-4313-8a2a-8c7122cec284', NULL, NULL, NULL, NULL, NULL, 29);
INSERT INTO `org_OrganizationalPosition` VALUES(33, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Junior Developer0', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/aa9dee63-49db-4f8a-93cf-0856776e6f31', NULL, NULL, NULL, NULL, NULL, 30);
INSERT INTO `org_OrganizationalPosition` VALUES(34, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Senior Programmer0', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/75e4c5a1-6f2a-44c6-bb7f-002633251a4f', NULL, NULL, NULL, NULL, NULL, 31);
INSERT INTO `org_OrganizationalPosition` VALUES(35, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Assistant Professor0', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/adf723af-7579-4cd1-be90-683aab57ac77', NULL, NULL, NULL, NULL, NULL, 31);
INSERT INTO `org_OrganizationalPosition` VALUES(36, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Teaching Assistant0', 'http://intelleo.org/triplestore/bc_x#OrganizationalPosition/a8323778-22b0-4b72-91a8-96d001e0dfd9', NULL, NULL, NULL, NULL, NULL, 31);

-- --------------------------------------------------------

--
-- Table structure for table `org_OrganizationalPosition_org_Duty`
--

CREATE TABLE `org_OrganizationalPosition_org_Duty` (
  `org_OrganizationalPosition_id` bigint(20) NOT NULL,
  `assignedDuties_id` bigint(20) NOT NULL,
  KEY `FK38435F4E7FECB4ED` (`org_OrganizationalPosition_id`),
  KEY `FK38435F4E17BDC19C` (`assignedDuties_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_OrganizationalPosition_org_Duty`
--

INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(32, 460);
INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(34, 460);
INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(36, 460);
INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(32, 461);
INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(34, 461);
INSERT INTO `org_OrganizationalPosition_org_Duty` VALUES(36, 461);

-- --------------------------------------------------------

--
-- Table structure for table `org_OrganizationalPosition_user_User`
--

CREATE TABLE `org_OrganizationalPosition_user_User` (
  `org_OrganizationalPosition_id` bigint(20) NOT NULL,
  `positionOccupants_id` bigint(20) NOT NULL,
  UNIQUE KEY `positionOccupants_id` (`positionOccupants_id`),
  KEY `FK69B1D7A27FECB4ED` (`org_OrganizationalPosition_id`),
  KEY `FK69B1D7A28BE5E80E` (`positionOccupants_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_OrganizationalPosition_user_User`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_OrganizationalUnit`
--

CREATE TABLE `org_OrganizationalUnit` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `parentUnit_id` bigint(20) DEFAULT NULL,
  `orgUnit_user_organisation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKBFD1C89D793C921C` (`parentUnit_id`),
  KEY `FKBFD1C89D5C73E864` (`orgUnit_user_organisation_id`),
  KEY `FKEF86282E5F3CFD32bfd1c89d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_OrganizationalUnit`
--

INSERT INTO `org_OrganizationalUnit` VALUES(2, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FOS GOOD OLD AI', 'http://intelleo.org/triplestore/bc_x#OrganizationalUnit/010f313e-918a-4375-8975-cbc812599c0a', NULL, NULL, NULL, 1, NULL, NULL, 1);
INSERT INTO `org_OrganizationalUnit` VALUES(29, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Key to Metals0', 'http://intelleo.org/triplestore/bc_x#OrganizationalUnit/c6776e2b-7e0e-4995-b98d-8844ea03f8ca', NULL, NULL, NULL, 25, NULL, NULL, 25);
INSERT INTO `org_OrganizationalUnit` VALUES(30, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'NetBeans Platform Development Unit0', 'http://intelleo.org/triplestore/bc_x#OrganizationalUnit/dc6d84ea-55cc-41f4-a6ae-665ffd8dc61b', NULL, NULL, NULL, 27, NULL, NULL, 27);
INSERT INTO `org_OrganizationalUnit` VALUES(31, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'FOS GOOD OLD AI0', 'http://intelleo.org/triplestore/bc_x#OrganizationalUnit/41215af9-f59f-49da-a401-0ccaad7937b1', NULL, NULL, NULL, 26, NULL, NULL, 26);

-- --------------------------------------------------------

--
-- Table structure for table `org_OrganizationalUnit_org_OrganizationalUnit`
--

CREATE TABLE `org_OrganizationalUnit_org_OrganizationalUnit` (
  `org_OrganizationalUnit_id` bigint(20) NOT NULL,
  `subUnits_id` bigint(20) NOT NULL,
  UNIQUE KEY `subUnits_id` (`subUnits_id`),
  KEY `FK11DB7E7F3E14F48D` (`org_OrganizationalUnit_id`),
  KEY `FK11DB7E7F988827B` (`subUnits_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_OrganizationalUnit_org_OrganizationalUnit`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_Organization_org_OrganizationalUnit`
--

CREATE TABLE `org_Organization_org_OrganizationalUnit` (
  `org_Organization_id` bigint(20) NOT NULL,
  `orgUnits_id` bigint(20) NOT NULL,
  UNIQUE KEY `orgUnits_id` (`orgUnits_id`),
  KEY `FK8A22912EBE6F8F1F` (`orgUnits_id`),
  KEY `FK8A22912E69302D0D` (`org_Organization_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Organization_org_OrganizationalUnit`
--

INSERT INTO `org_Organization_org_OrganizationalUnit` VALUES(1, 2);
INSERT INTO `org_Organization_org_OrganizationalUnit` VALUES(25, 29);
INSERT INTO `org_Organization_org_OrganizationalUnit` VALUES(27, 30);
INSERT INTO `org_Organization_org_OrganizationalUnit` VALUES(26, 31);

-- --------------------------------------------------------

--
-- Table structure for table `org_Private`
--

CREATE TABLE `org_Private` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6ddc6fef08` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Private`
--

INSERT INTO `org_Private` VALUES(200, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/571c533b-c107-41a6-8256-c34e64a71060', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(205, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/25dfeb4d-5201-4f31-b0ca-35c9e6dc20cb', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(223, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/ee55adea-57fb-463a-aa86-cb1426d02647', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(228, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/94f450e0-21d2-4e32-8d0b-5f9a9d7a8848', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(233, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/996c10b8-b8bc-4d05-ba85-04b4c7a4bbad', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(258, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/ba1e9f87-1827-464c-80a9-a05802d93897', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(263, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/ecd73637-fbad-4e62-9292-6b75a7c5830e', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(268, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/3f121755-48ae-4408-adfe-f7fccb314db6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(277, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/fd90b7ce-f5c1-4a48-a3be-5da8eeb82225', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(282, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/0b76846f-f00d-45df-bdfb-09e000b3c68c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(287, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/88d92e79-51ac-4f7e-9681-8dd22e5b46bc', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(302, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/6b16f303-288f-455c-8991-94dff0d2a054', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(307, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/4768a209-1585-4c8b-806c-c44f65308a8c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(312, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/07e4d23c-3f72-43c5-8b33-14d693562cb2', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(321, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/bc20bb35-b222-4d48-97ae-9d71c2ec071c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(326, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/f6cd512a-2ca0-4e0e-a325-6a9e04c6c406', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(331, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/29e5b5e2-c6d2-4a04-8c5d-137e23c2362f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(422, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/15924504-7f42-4a4b-a914-f3bab348f26f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(427, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/f0c64ece-02a5-4b06-b6cd-d4f1e4c82ed3', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(968, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/b33b757f-1be9-489e-a036-64408edf108a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(973, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/68b5e1ff-a3f6-435e-b93d-18ab45737a56', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(978, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/6214f247-304f-4f09-9cdd-181df31fa003', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(996, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/5ef7a832-cb44-4ace-acd7-7884fee0c177', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1001, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/069755a8-205a-44f4-825d-df35ad663585', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1006, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/0d9e8207-b919-4944-9b87-c33065aa2300', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1023, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/a0b83f02-e7b7-4c32-a391-0f237aad5565', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1028, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/6f696a8b-8871-4c84-a91f-fba304e759e4', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1033, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/2f800dd6-a296-4463-bb8b-d88dd2c35cd6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1049, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/23c59495-8b42-4d58-ac63-5c90073df732', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1054, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/24ab3bfa-e843-4205-97f8-3008321f2a9f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Private` VALUES(1059, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Private/d5b1ffb3-723e-49c7-b458-ed46ed0500c5', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `org_Public`
--

CREATE TABLE `org_Public` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6dee7d2444` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Public`
--

INSERT INTO `org_Public` VALUES(174, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/f1724224-193c-4b0b-9dcc-37477204e497', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(177, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/3c3f0b8d-cb18-4839-becf-4d24821b50e1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(179, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d749762e-6497-4013-86aa-fc457d136984', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(181, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6d76cb6c-fbd6-42b7-82e8-6fc2c0983a3d', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(183, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/1c9cd273-4cf8-40e8-acd4-2f972ffab32a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(185, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e02ba01d-b568-42aa-ad07-fda53154ac34', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(187, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/4e1ddcf2-b5d5-437c-811d-58e9cdca57ab', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(189, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/3d9e55c2-b2e4-4248-8f25-6784420a3c71', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(191, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a8356564-bece-41b1-8143-98c5cd306431', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(193, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7282dc31-112c-4f1f-9ba2-0709d95bfe0e', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(195, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7978421e-2b9b-450c-8da5-20b49c930fa0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(197, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/f097676d-b064-4260-910e-7e2a82eb707c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(207, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/996013b8-ee1e-47ec-a80a-5f0df1aeb707', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(208, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/3b5d9196-a27e-476a-87fc-2d514d595a06', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(210, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d8c1d051-70ef-4635-9a9c-f59f694c05cf', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(212, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9a25a971-1036-46a1-8e4c-1a4211d8f6b7', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(214, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/811de62a-336d-4461-b6e8-f9793a38506b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(216, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/967e3f85-27b9-4a1d-92c6-ce29376787e9', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(218, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9abe458f-e93b-43ef-87ba-2d33b16c8a7f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(220, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/5180b1f5-c931-41b6-958a-27a92f24221c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(235, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c6b6a050-03ff-446c-ab1f-26cb55fa20b0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(236, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/2c3df2b8-49fe-4d81-935e-041394e77550', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(237, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/569cafc3-9635-4cb5-a628-0e84f0c4ddc1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(238, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/ebefb9bf-14d5-4d96-8571-8a58325c2bf6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(239, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/578a52c1-cabd-463d-93c0-f058f8540333', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(241, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/586f1cfa-93f2-40bf-8702-e31f409db22b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(243, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6115403f-9118-4a93-8002-240f412bed2c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(245, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/ab06ccf3-d4e3-41da-aa63-fc2869be91eb', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(247, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e52d288a-4668-4bf1-b040-4959607ecd34', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(249, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c6e4ae68-0f5b-4a0e-92f7-9b61348be562', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(251, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c7ceda92-5321-493d-a99f-4a84ced42971', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(253, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/fc08ba8e-d870-4a29-9174-3bf08e3644b8', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(255, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d4eed684-1648-496e-9e77-510d833bf45f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(270, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/281fccf5-7a2a-4260-a4ce-871603fbae2f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(271, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b7b84ed9-75be-42a2-b8f8-b736a62b72cc', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(272, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/816685a1-becd-46e2-89b4-eb2e4d6bc374', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(273, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/0d03c659-063f-47b7-8328-ac9b42f618ed', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(274, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/2b30ffc4-805b-4bce-9171-2daaa8e5575f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(289, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7e605b47-e618-448f-8cb3-475c2f6995c3', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(290, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/34abb732-420f-40a4-bd11-b1e68a8a1f41', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(291, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9c0bbed9-b1d0-4100-a245-b168fe819c4c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(292, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b0d1cd38-7707-43bf-907b-808c07c6f225', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(293, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6f4ccf49-e392-4cc0-ada0-01e76ce9cf58', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(295, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/04a67644-8374-4185-be34-e9824323f67c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(297, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6e4ec4c5-4c44-444f-bf5e-4034b16fdf9d', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(299, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e13a4e89-6a5f-48f3-91c7-fb505c0e5469', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(314, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b4d86073-a211-4b62-a06c-f291f1816f1b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(315, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/044554aa-100c-4608-9cd7-6ad28a17f8f9', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(316, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a98c5fd8-9ea2-41bb-aa60-58724738985b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(317, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/14c5813f-89a6-4743-8835-8c9d7f3fb263', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(318, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a26a9804-9341-4d76-a458-5c545aad79ff', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(333, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/194f53ce-e73c-40e3-a726-9964240320e5', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(334, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6105bf41-8383-4c29-9f99-fb8dbf5b376c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(335, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/06a7506b-7aea-4841-9019-0a6ce05968ab', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(336, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/08b6fe34-562d-474a-85b2-6168d4acad54', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(337, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/46202b21-53cb-4a9f-b3c5-b5389bd6e97d', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(339, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/23ec57fb-907f-44a9-bbb6-24d880e8d3e6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(341, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/78fb7db5-1817-4f80-af73-011f1be5471c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(343, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/4e05a8d4-92a6-43fd-8406-f82ce0ab40b8', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(346, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9ead4fbb-3bec-4c3e-bc4e-ee7e4be5feed', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(348, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a0d3d871-a460-48ac-8066-4636c724cb73', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(351, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a3684718-c5de-440f-b1ef-aaecba6bb61e', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(353, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/efec9899-562f-4898-99f7-50d12bf1fd83', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(355, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9132e3c1-e379-4315-a568-25e8df844265', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(358, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d4320d02-73b1-44c8-8f57-bcb2247e73cc', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(360, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/daacd489-e085-4fa9-80ce-3e176edd45de', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(362, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9f4eab20-68b4-43c4-9d4b-a33f280c93db', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(364, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/768184ab-c5ff-4fff-99bb-227dcba1fa55', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(366, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/85accf35-d4b5-4840-9708-514b9b0711de', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(368, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/0c671820-9781-4d48-b7d5-2ccde1b6961f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(371, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/da8de585-9864-4cf0-b14f-9828a6620bb4', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(373, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6ceb3617-1e3f-41e2-ad08-cd1cec76ff3a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(375, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/f2f3487d-3110-4d06-adac-35632f941baf', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(377, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d8cd2ac2-e07e-4e33-9b99-1be8afdf156a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(380, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/59025478-24f0-498e-aa2d-2a7ca8ab11c1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(382, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d9eac1e2-1878-4f66-9996-6aafd49d927d', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(384, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/969948e9-745c-4881-b4c5-ce76bb209e8f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(386, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/f94285a0-3cf0-477f-9877-731322627a80', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(389, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/38934500-ade6-4cd7-9164-52672c268423', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(392, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7ecae83f-46ca-4397-bcca-ba69f77d0a01', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(394, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e1eed6d0-2638-4497-96fa-4b5181429448', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(396, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/4978d010-a54c-4729-8a66-ec2627adca7b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(398, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/5070d30f-b8ff-40b8-bb17-5b3fcc31b522', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(400, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/10f1e367-3af0-447f-a061-a1b0c9aa170f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(402, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/3203bff3-e448-454f-a57d-134caf63f223', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(404, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a9c0fb96-77e5-49e1-b893-811f279531b2', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(406, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/eb42b60e-28a4-406a-b665-45ab3ae1f85b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(408, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/fcaf9554-31f9-4a1d-9680-96377a16ead5', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(410, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c2a35d3a-87a3-441f-8cde-a8c2a9d9973e', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(412, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/ddb3c4c0-1b20-477e-84d2-70b82e1da079', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(414, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e35cc30b-09ad-49e8-a10b-d2a67320c227', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(417, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/81a0dfcd-9b3a-42d0-bc86-20bd9eea0261', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(419, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9d0238b8-d997-43e7-82b5-db5a29943bc6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(429, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/cb777d35-8551-46d7-83ab-5d3ade8bcd41', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(430, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b7151463-2eef-46cd-8d74-1d1fe2efa655', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(431, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/204dc9f8-4373-4ed9-b2c8-82256c44c56b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(434, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b66036d3-7a7a-44fe-89b1-7eda8bd90374', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(437, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c8bfe2a2-4eb6-4ae7-a39d-e24f51dfaa07', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(439, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/2f8dc64d-8059-4493-a47b-9a8ae2f410e6', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(441, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/83a5dfee-2216-4860-95e2-df5a92b281c0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(443, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7b8802a6-6052-4036-a7a4-4453be75d4be', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(445, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/78632881-501a-450c-b05f-2448489ed084', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(447, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/098ec459-64a0-4e5d-b174-d1b5de763bd9', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(450, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/55671d1a-25ab-4b3a-8293-13ba28f6442c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(453, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/202fc02e-f044-4b0f-91cb-4c7eff8d8fed', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(455, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/1f314c31-0cc3-4ca7-ad98-82ca31bee177', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(457, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e254cc86-3a7c-46d2-b59d-6160527acbed', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(459, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9962462b-306e-4678-94f0-b33632b6e0c4', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(943, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/935c22ed-3794-44b0-a93e-e4e64192e870', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(945, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/ec469615-d7fd-4498-97d7-718acc733a2a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(947, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/fe936f04-ecb5-428c-9f0b-fd7f514cfe23', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(950, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b83335ed-4ec5-4ab4-8c0e-ce1dc5567d79', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(953, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c6b4f716-29b2-4d6d-86ab-bc049d5ed1fc', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(956, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/10eed68d-5d6a-40ac-95a9-1fca473d2ca4', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(959, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c5f856d6-e8f3-4057-830c-251bebb7f9c0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(962, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e23b2906-7cf1-45ef-85fb-e0c754bb6e30', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(980, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/d12c5135-3fd8-493b-91bd-ad173e49f64c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(981, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/6a681674-5251-427f-8dfc-696af258ee84', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(982, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7c24cd7d-2bf1-4c8e-ac3c-b1b7320a1a50', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(983, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/8e8a2943-d738-4f2b-9ae1-b6f88f3356c8', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(984, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a3e99fc2-bf1c-4256-a554-08d4f356eb55', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(988, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/a493b0e2-1b56-4c00-9cde-314080cf86d1', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1008, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/8a59887a-811c-474e-9352-22e6937da9e0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1009, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e511d653-394d-4bec-bf70-0c200f299914', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1010, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c69215ce-e681-4b9a-bcf7-16b885299f42', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1011, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/fb74f6b1-55ed-49ba-a6ba-b0a4a6c45155', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1012, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/7d85c227-26eb-4ba8-9cf6-dbaef57919d7', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1016, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/4511cc42-c8c9-48c9-9e5d-22b42d8bec52', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1035, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/b41304ff-8b39-48ad-98a5-33910159d179', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1036, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/5f0fd5e3-9f02-4d1d-8e38-c48dab224632', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1037, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/3234bb78-5140-46e7-bffd-e9f36ef02b43', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1038, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/9a21f89e-d96b-4c87-a896-a85c9b35d060', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1039, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/0ecad5f4-41a9-4b28-bc52-68c6cea05e04', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1042, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/5cbc9b0e-4957-409d-ac4c-158e55a4ffff', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1061, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c3d34838-c71a-49e4-be0b-6863cf7bad3a', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1062, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/62bd7ad9-1a6c-4a5e-9835-7a83b3f0f28f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1063, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/12bd5aef-95fc-4add-8b89-f156785e0b07', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1064, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/c7adb5b8-2aa9-4df4-b54b-e3f574843860', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1065, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/e1c684bb-2d56-402c-ad9b-78b81e2158a0', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `org_Public` VALUES(1068, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#Public/660d4214-a263-4b66-b47a-2ea600980c8a', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `org_Visibility`
--

CREATE TABLE `org_Visibility` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_Visibility`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_VisibleToIntelLEO`
--

CREATE TABLE `org_VisibleToIntelLEO` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  `intelleo` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6dd0721e52` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_VisibleToIntelLEO`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_VisibleToOrganization`
--

CREATE TABLE `org_VisibleToOrganization` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  `visToOrg_user_organisation_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKE522B925BD8F0303` (`visToOrg_user_organisation_id`),
  KEY `FKEF86282E5F3CFD3269636f6de522b925` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_VisibleToOrganization`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_VisibleToProject`
--

CREATE TABLE `org_VisibleToProject` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  `project` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6d1c7b4fe7` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_VisibleToProject`
--


-- --------------------------------------------------------

--
-- Table structure for table `org_VisibleToTeam`
--

CREATE TABLE `org_VisibleToTeam` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `associatedAccessRights` tinyblob,
  `team` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3269636f6dcb90204f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `org_VisibleToTeam`
--


-- --------------------------------------------------------

--
-- Table structure for table `Person`
--

CREATE TABLE `Person` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e58e488775` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Person`
--


-- --------------------------------------------------------

--
-- Table structure for table `Project`
--

CREATE TABLE `Project` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `projectidentifier` varchar(255) DEFAULT NULL,
  `dateFinished` datetime DEFAULT NULL,
  `dateStarted` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `projectLeader_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK50C8E2F9BA5D31D9` (`projectLeader_id`),
  KEY `FKEF86282E5F3CFD3284cfc06b50c8e2f9` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Project`
--

INSERT INTO `Project` VALUES(942, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OP4L project0', 'http://intelleo.org/triplestore/bc_x#Project/b464fb2d-e5c9-423b-9f90-d26e412ad5d3', NULL, NULL, NULL, 26, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `ProjectAssociation`
--

CREATE TABLE `ProjectAssociation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `associatedProject` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD1090323bc8` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f90323bc8` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `ProjectAssociation`
--


-- --------------------------------------------------------

--
-- Table structure for table `Project_projectParticipants_User`
--

CREATE TABLE `Project_projectParticipants_User` (
  `Project_id` bigint(20) NOT NULL,
  `projectParticipants_id` bigint(20) NOT NULL,
  KEY `FK85671997F823C2A2` (`projectParticipants_id`),
  KEY `FK8567199785C36BD8` (`Project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Project_projectParticipants_User`
--


-- --------------------------------------------------------

--
-- Table structure for table `Project_Resource`
--

CREATE TABLE `Project_Resource` (
  `Project_id` bigint(20) NOT NULL,
  `results_id` bigint(20) NOT NULL,
  UNIQUE KEY `results_id` (`results_id`),
  KEY `FK766FBEB485C36BD8` (`Project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Project_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Project_workflow_Task`
--

CREATE TABLE `Project_workflow_Task` (
  `Project_id` bigint(20) NOT NULL,
  `tasks_id` bigint(20) NOT NULL,
  UNIQUE KEY `tasks_id` (`tasks_id`),
  KEY `FK8250175F85C36BD8` (`Project_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Project_workflow_Task`
--


-- --------------------------------------------------------

--
-- Table structure for table `RecognitionEvent`
--

CREATE TABLE `RecognitionEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9536a68143` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RecognitionEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Recognition_User`
--

CREATE TABLE `Recognition_User` (
  `user_Recognition_id` bigint(20) NOT NULL,
  `givenToUsers_id` bigint(20) NOT NULL,
  KEY `FK3806179346737398` (`user_Recognition_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Recognition_User`
--


-- --------------------------------------------------------

--
-- Table structure for table `Recommendation`
--

CREATE TABLE `Recommendation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `recommendedBy` tinyblob,
  `recommendedResource` tinyblob,
  `recommendedTo` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3286f70bd9` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Recommendation`
--


-- --------------------------------------------------------

--
-- Table structure for table `RecommendationEvent`
--

CREATE TABLE `RecommendationEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c957706f641` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `RecommendationEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Resource`
--

CREATE TABLE `Resource` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource`
--

INSERT INTO `Resource` VALUES(4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:zoran.jeremic@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(37, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:tomic.bojan@fon.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(52, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:sevarac.zoran@fon.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(67, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:djuric.dragan@fon.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(82, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:nikola.milikic@gmail.com0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(97, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:devedzic.vladan@fon.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(112, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jovanovic.jelena@fon.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(127, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:sonjafon@gmail.com0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(142, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:tanja.milic@fon.b.ac.rs0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(157, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:sreckojoksimovic@gmail.com0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(512, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:nikola.damjanovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(527, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jelena.jovanovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(542, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:viktor.pocajt@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(557, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jelena.djerkovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(572, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:mirjana.stankovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(587, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jelena.jankovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(602, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:radmila.damjanovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(617, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:aleksandra.petkovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(632, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:zeljka.vragolovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(647, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:vladimir.markovic@ini.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(752, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:djordjegligorijevic90@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(767, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jelena.djordjevic@fonis.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(782, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:jelena.stojanovic.1989@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(797, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:marjan.hrzic@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(812, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:gajicvedrana@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(827, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:misalazovic@open.telekom.rs', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(842, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:ivan0089@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(857, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:dusanmilicevic@ovi.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(872, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:maksapn@gmail.com', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `Resource` VALUES(887, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'mailto:brcic.nina@gmail.com', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `Resource_Annotation`
--

CREATE TABLE `Resource_Annotation` (
  `annotatedResources_id` bigint(20) NOT NULL,
  `annotations_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource_Annotation`
--

INSERT INTO `Resource_Annotation` VALUES(347, 345);
INSERT INTO `Resource_Annotation` VALUES(352, 350);
INSERT INTO `Resource_Annotation` VALUES(359, 357);
INSERT INTO `Resource_Annotation` VALUES(381, 379);
INSERT INTO `Resource_Annotation` VALUES(390, 388);
INSERT INTO `Resource_Annotation` VALUES(451, 449);
INSERT INTO `Resource_Annotation` VALUES(454, 452);

-- --------------------------------------------------------

--
-- Table structure for table `Resource_Resource`
--

CREATE TABLE `Resource_Resource` (
  `Resource_id` bigint(20) NOT NULL,
  `relatedResources_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `Resource_Tag`
--

CREATE TABLE `Resource_Tag` (
  `Resource_id` bigint(20) NOT NULL,
  `tags_id` bigint(20) NOT NULL,
  KEY `FKF2E6D7E9579AD289` (`tags_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource_Tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `Resource_Topic`
--

CREATE TABLE `Resource_Topic` (
  `Resource_id` bigint(20) NOT NULL,
  `topics_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource_Topic`
--


-- --------------------------------------------------------

--
-- Table structure for table `Resource_UserRating`
--

CREATE TABLE `Resource_UserRating` (
  `Resource_id` bigint(20) NOT NULL,
  `userRatings_id` bigint(20) NOT NULL,
  UNIQUE KEY `userRatings_id` (`userRatings_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Resource_UserRating`
--


-- --------------------------------------------------------

--
-- Table structure for table `Role`
--

CREATE TABLE `Role` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `roleAt_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3226f496` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Role`
--


-- --------------------------------------------------------

--
-- Table structure for table `Scale`
--

CREATE TABLE `Scale` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324c0192a` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Scale`
--


-- --------------------------------------------------------

--
-- Table structure for table `Scale_possibleValues`
--

CREATE TABLE `Scale_possibleValues` (
  `Scale_id` bigint(20) NOT NULL,
  `possibleValues` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Scale_possibleValues`
--


-- --------------------------------------------------------

--
-- Table structure for table `Search`
--

CREATE TABLE `Search` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `query` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95935f51c8` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Search`
--


-- --------------------------------------------------------

--
-- Table structure for table `SelectNodeEvent`
--

CREATE TABLE `SelectNodeEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `selectedNode` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95be81c3fc` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SelectNodeEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `SetVisibilityEvent`
--

CREATE TABLE `SetVisibilityEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `annotationRef_id` bigint(20) DEFAULT NULL,
  `visibility` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9531b4f48b9866206` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SetVisibilityEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `SharingEvent`
--

CREATE TABLE `SharingEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `sharedResource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c959bde0f3e` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SharingEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `SharingEvent_Resource`
--

CREATE TABLE `SharingEvent_Resource` (
  `SharingEvent_id` bigint(20) NOT NULL,
  `sharedWith_id` bigint(20) NOT NULL,
  UNIQUE KEY `sharedWith_id` (`sharedWith_id`),
  KEY `FK4A37900F4C56D97B` (`SharingEvent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SharingEvent_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `similarity_tf`
--

CREATE TABLE `similarity_tf` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `value` double DEFAULT NULL,
  `concept_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK15B76D4EE74A6463` (`concept_id`),
  KEY `FK15B76D4EA448F0FD` (`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `similarity_tf`
--


-- --------------------------------------------------------

--
-- Table structure for table `similarity_tf_idf`
--

CREATE TABLE `similarity_tf_idf` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `value` double DEFAULT NULL,
  `concept_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK66B0DC3AE74A6463` (`concept_id`),
  KEY `FK66B0DC3AA448F0FD` (`resource_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `similarity_tf_idf`
--


-- --------------------------------------------------------

--
-- Table structure for table `sioc_Item`
--

CREATE TABLE `sioc_Item` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `replyOf` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32d43a63a8` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sioc_Item`
--


-- --------------------------------------------------------

--
-- Table structure for table `sioc_Post`
--

CREATE TABLE `sioc_Post` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `replyOf` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32d43a63a8d43d8135` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sioc_Post`
--


-- --------------------------------------------------------

--
-- Table structure for table `sioc_UserAccount`
--

CREATE TABLE `sioc_UserAccount` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `accountHolder_id` bigint(20) DEFAULT NULL,
  `accountServiceHomepage_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324186a1ad` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sioc_UserAccount`
--


-- --------------------------------------------------------

--
-- Table structure for table `SocialEvent_eventRelatedResource_Resource`
--

CREATE TABLE `SocialEvent_eventRelatedResource_Resource` (
  `user_SocialEvent_id` bigint(20) NOT NULL,
  `eventRelatedResources_id` bigint(20) NOT NULL,
  KEY `FKC803975C4AED53B8` (`user_SocialEvent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `SocialEvent_eventRelatedResource_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `StatusUpdateEvent`
--

CREATE TABLE `StatusUpdateEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `urls` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c95784b6bdf` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `StatusUpdateEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Tag`
--

CREATE TABLE `Tag` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `label` varchar(255) DEFAULT NULL,
  `meaning` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD101477a` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f1477a` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `TaggingEvent`
--

CREATE TABLE `TaggingEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `annotationRef_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9531b4f48bec16b305` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TaggingEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Task_Activity`
--

CREATE TABLE `Task_Activity` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `activities_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Task_Activity`
--


-- --------------------------------------------------------

--
-- Table structure for table `Task_parallelTask_Task`
--

CREATE TABLE `Task_parallelTask_Task` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `parallelTasks_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Task_parallelTask_Task`
--


-- --------------------------------------------------------

--
-- Table structure for table `Task_precedingTask_Task`
--

CREATE TABLE `Task_precedingTask_Task` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `precedingTasks_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Task_precedingTask_Task`
--


-- --------------------------------------------------------

--
-- Table structure for table `TeamAssociation`
--

CREATE TABLE `TeamAssociation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `associatedTeam` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD109cfacdc4` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74f9cfacdc4` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TeamAssociation`
--


-- --------------------------------------------------------

--
-- Table structure for table `Team_hasLearningGoal_LearningGoal`
--

CREATE TABLE `Team_hasLearningGoal_LearningGoal` (
  `user_Team_id` bigint(20) NOT NULL,
  `learningGoals_id` bigint(20) NOT NULL,
  KEY `FK3B699AA779CA3D5F` (`learningGoals_id`),
  KEY `FK3B699AA7C767111C` (`user_Team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Team_hasLearningGoal_LearningGoal`
--


-- --------------------------------------------------------

--
-- Table structure for table `Team_selectionCriteria_Resource`
--

CREATE TABLE `Team_selectionCriteria_Resource` (
  `user_Team_id` bigint(20) NOT NULL,
  `membersSelectionCriteria_id` bigint(20) NOT NULL,
  KEY `FK67FD47E4C767111C` (`user_Team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Team_selectionCriteria_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `TopicPreference_preferredKeyword_Tag`
--

CREATE TABLE `TopicPreference_preferredKeyword_Tag` (
  `user_TopicPreference_id` bigint(20) NOT NULL,
  `preferredKeywords_id` bigint(20) NOT NULL,
  KEY `FK8E73A6B84BE773D8` (`user_TopicPreference_id`),
  KEY `FK8E73A6B8B68E3A37` (`preferredKeywords_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TopicPreference_preferredKeyword_Tag`
--


-- --------------------------------------------------------

--
-- Table structure for table `UnFollowEvent`
--

CREATE TABLE `UnFollowEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  `unfollowedResource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c9540fcccf0` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UnFollowEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `Upload`
--

CREATE TABLE `Upload` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `sessionId` varchar(255) DEFAULT NULL,
  `timeStamp` datetime DEFAULT NULL,
  `performedBy_id` bigint(20) DEFAULT NULL,
  `resource_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3218487c959768fa21` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `Upload`
--


-- --------------------------------------------------------

--
-- Table structure for table `UserAccount_follows_UserAccount`
--

CREATE TABLE `UserAccount_follows_UserAccount` (
  `sioc_UserAccount_id` bigint(20) NOT NULL,
  `follows_id` bigint(20) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserAccount_follows_UserAccount`
--


-- --------------------------------------------------------

--
-- Table structure for table `UserDefinedCompetence`
--

CREATE TABLE `UserDefinedCompetence` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `competencedescription` varchar(255) DEFAULT NULL,
  `parent_id` bigint(20) DEFAULT NULL,
  `definedByUser` tinyblob,
  `resultingOrgCompetence` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324b6a73e9c0deee07` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserDefinedCompetence`
--


-- --------------------------------------------------------

--
-- Table structure for table `UserRating`
--

CREATE TABLE `UserRating` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `creationDate` datetime DEFAULT NULL,
  `author_id` bigint(20) DEFAULT NULL,
  `scale` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK1A21C74F1A35CD10d2f82168` (`author_id`),
  KEY `FKEF86282E5F3CFD321a21c74fd2f82168` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `UserRating`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_CompetencePreference`
--

CREATE TABLE `user_CompetencePreference` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321c22e19967d40998` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_CompetencePreference`
--

INSERT INTO `user_CompetencePreference` VALUES(464, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/3ce9680d-262e-4fcc-a26d-e9ff65d70a91', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(469, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/c3ac1171-2eb3-475b-821f-cf8bc5d6fb3c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(473, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/1a89acc9-7824-4e1b-947c-54a4f66256f0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(477, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/7ecd7da3-6e24-4a8c-8b52-17b43e8592ad', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(481, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/eb9729e0-7350-40c0-a733-79c7951203f5', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(485, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/c0d41e73-0de8-41f0-9c00-90e4460ed745', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(489, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/e3453644-0d66-4679-8a3d-176cc7e47c02', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(493, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/fef61452-3140-4f25-9c49-2d7158f87e46', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(497, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/5e56784f-1973-46ec-a2c5-216d62fc799d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(501, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/2fde5b20-684c-4376-a33d-46b6451e518d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(674, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/75d2fe77-0097-4574-aa41-44d3b839a59a', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(678, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/a0ce26f5-dffc-4dbc-b309-d43e691dd0c7', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(682, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/da99bc29-54f7-44d2-95eb-c6ee606419c3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(686, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/c60bbcd1-5114-464e-a6ac-5787d6098efa', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(690, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/6900eab8-7620-4e70-9fd0-77bc5be25cc3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(694, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/ddafa769-4171-4382-9192-225fe35e8ce0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(698, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/f0cde39b-7622-4712-a19f-af2c3a011fc8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(702, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/1be252d6-826c-4917-a573-6964b40f299e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(706, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/86df3c6d-1bf2-4683-8a2e-d3897fad9a8e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(710, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/e645be51-2c7e-4a30-8c0b-b248151107ce', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(714, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/a08969e2-826e-4e09-a1eb-7ac3f4d864de', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(718, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/a761db5c-a334-4edc-9154-46da6c207bce', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(722, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/f23d1238-48d6-4e55-9110-889eeebd192c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(726, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/66aff39d-c4ad-4292-bff4-3df5ef817fd4', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(730, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/8c829b77-f507-4861-b0c2-0b4048cefbf5', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(734, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/ad6b10e1-53de-4f13-b9f3-ae6e07c9bee3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(738, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/bcb9e481-1414-4bc3-b7ed-1dc35f6d402f', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(742, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/4f89534c-be33-46a0-b40d-2cb09f7b7773', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(746, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/637f1722-0eca-44b0-9e2d-04118050238b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_CompetencePreference` VALUES(750, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#CompetencePreference/985baaa1-198e-4700-83b9-36e293b2dce7', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_CompetencePreference_Competence`
--

CREATE TABLE `user_CompetencePreference_Competence` (
  `user_CompetencePreference_id` bigint(20) NOT NULL,
  `preferredCompetences_id` bigint(20) NOT NULL,
  UNIQUE KEY `preferredCompetences_id` (`preferredCompetences_id`),
  KEY `FK883F50F0654AF7DC` (`user_CompetencePreference_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_CompetencePreference_Competence`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_EmailPreferences`
--

CREATE TABLE `user_EmailPreferences` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321c22e199fc4e8bd0` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_EmailPreferences`
--

INSERT INTO `user_EmailPreferences` VALUES(466, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/172241c1-fa4a-43e6-8b51-7209c5750e19', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(470, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/3f8ddff8-1141-42a5-8888-d491d1d11d49', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(474, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/b039bd09-a23a-4db6-92f5-b86f3c2a8cbe', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(478, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/7e4d90be-7599-4a28-8b4d-b7c0f750efe6', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(482, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/e5886294-c061-4d29-b5a2-d9656bcfc1af', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(486, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/b0201190-dc9c-4452-a92d-c51590d5725e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(490, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/2181f722-d16a-475a-8cd4-6921f4f21e11', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(494, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/c7d804ac-8eab-4b44-a505-66a090574ed1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(498, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/5f1e4bc0-8cd7-4dcf-ac91-b0f24f8bba5e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(502, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/0c4273ab-19b1-4301-8c31-bb976c57fc23', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(675, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/cb545a0a-204e-474f-a7e2-ba59dd5e41bd', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(679, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/c89e3e09-756e-46ad-b1a0-1ec0a60413e2', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(683, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/209373df-0a94-42be-b04a-4b93857fb61b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(687, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/2e3dbd4f-d827-45b5-ba20-a0e9b10481de', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(691, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/74b2d6d6-a057-46dd-adbb-a30a0a0af089', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(695, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/f0718fd3-9440-48b8-a55a-6b67b01fcb48', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(699, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/3600ac5a-eb98-4989-8bec-2cd8e3ff71db', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(703, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/10a09ae4-ee82-4692-8004-a6074cf6be66', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(707, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/c91a100f-9df5-4f49-b23e-49dc74ce0670', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(711, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/45824b6e-2718-48e4-a8de-96e88f6155d6', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(715, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/3bd2d8f0-cc64-4363-a980-8143cba400fb', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(719, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/fd8c4863-1e87-4c0f-b2c2-4fd34cedd9e7', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(723, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/43a4ca6b-55a6-4b79-a912-df666d6f783c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(727, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/f508ce1b-7d49-4fba-af17-592b00a25b70', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(731, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/1a168fce-66e9-4377-9988-261cd704dd99', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(735, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/68301dcd-85d6-49ba-afa2-0ca33bb7aab0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(739, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/d83734fd-673b-4292-8ea6-44b06a58ece8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(743, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/91310290-7b7f-4b07-b218-907e45e3b9e6', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(747, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/8cb9950d-3d33-4998-a2f3-43b4c0a9667d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_EmailPreferences` VALUES(751, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#EmailPreferences/21e65497-acb0-48af-8048-36f9e19ae20b', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_FollowedEntity`
--

CREATE TABLE `user_FollowedEntity` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `requiredToFollow` char(1) DEFAULT NULL,
  `startedFollowing` datetime DEFAULT NULL,
  `followedCompetence_id` bigint(20) DEFAULT NULL,
  `followedResource_id` bigint(20) DEFAULT NULL,
  `followedRole_id` bigint(20) DEFAULT NULL,
  `followedUser_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK211F8327848E88C0` (`followedUser_id`),
  KEY `FKEF86282E5F3CFD32211f8327` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_FollowedEntity`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_GoalPriority`
--

CREATE TABLE `user_GoalPriority` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3249a12deb` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_GoalPriority`
--

INSERT INTO `user_GoalPriority` VALUES(987, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/High', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_GoalPriority` VALUES(1015, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/Medium', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_Invitation`
--

CREATE TABLE `user_Invitation` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `replyOf` tinyblob,
  `receiver` tinyblob,
  `sender` tinyblob,
  `status` tinyblob,
  `team` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32d43a63a8d43d8135da600ad` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_Invitation`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_LearningGoal`
--

CREATE TABLE `user_LearningGoal` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `archived` tinyint(1) DEFAULT NULL,
  `assignedBy` tinyblob,
  `deadline` datetime DEFAULT NULL,
  `goalPriority_id` bigint(20) DEFAULT NULL,
  `progress_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK71143B65DACEA67B` (`progress_id`),
  KEY `FK71143B6548549170` (`goalPriority_id`),
  KEY `FKEF86282E5F3CFD3271143b65` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_LearningGoal`
--

INSERT INTO `user_LearningGoal` VALUES(989, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'To Learn Ontologies0', 'http://intelleo.org/triplestore/bc_x#LearningGoal/74b57d32-4da3-443f-99bb-b886bf820790', NULL, 23, NULL, NULL, 988, 0, NULL, '2012-04-02 13:07:35', 987, 986);
INSERT INTO `user_LearningGoal` VALUES(1017, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn Ontologies0', 'http://intelleo.org/triplestore/bc_x#LearningGoal/18eef26d-0f82-4ff4-ad10-a57ca3d6db2d', NULL, 96, NULL, NULL, 1016, 0, NULL, '2012-03-20 13:07:35', 1015, 1014);
INSERT INTO `user_LearningGoal` VALUES(1043, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learning Ontologies0', 'http://intelleo.org/triplestore/bc_x#LearningGoal/9ce26187-4cb3-40de-98b4-d38a3b795be9', NULL, 81, NULL, NULL, 1042, 0, NULL, '2012-03-31 13:07:35', 1015, 1041);
INSERT INTO `user_LearningGoal` VALUES(1069, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learn Ontology Modeling0', 'http://intelleo.org/triplestore/bc_x#LearningGoal/28e4e411-200f-41cb-959c-76bbb58b9cfb', NULL, 126, NULL, NULL, 1068, 0, NULL, '2012-03-15 13:07:35', 1015, 1067);

-- --------------------------------------------------------

--
-- Table structure for table `User_learningGoals_LearningGoal`
--

CREATE TABLE `User_learningGoals_LearningGoal` (
  `user_User_id` bigint(20) NOT NULL,
  `learningGoals_id` bigint(20) NOT NULL,
  KEY `FK4E6B3A2279CA3D5F` (`learningGoals_id`),
  KEY `FK4E6B3A22146C725C` (`user_User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_learningGoals_LearningGoal`
--

INSERT INTO `User_learningGoals_LearningGoal` VALUES(23, 989);
INSERT INTO `User_learningGoals_LearningGoal` VALUES(96, 1017);
INSERT INTO `User_learningGoals_LearningGoal` VALUES(81, 1043);
INSERT INTO `User_learningGoals_LearningGoal` VALUES(126, 1069);

-- --------------------------------------------------------

--
-- Table structure for table `user_LearningGoal_user_TargetCompetence`
--

CREATE TABLE `user_LearningGoal_user_TargetCompetence` (
  `user_LearningGoal_id` bigint(20) NOT NULL,
  `targetCompetences_id` bigint(20) NOT NULL,
  UNIQUE KEY `targetCompetences_id` (`targetCompetences_id`),
  KEY `FK1D0900F48F3347B1` (`targetCompetences_id`),
  KEY `FK1D0900F4A49B42BC` (`user_LearningGoal_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_LearningGoal_user_TargetCompetence`
--

INSERT INTO `user_LearningGoal_user_TargetCompetence` VALUES(989, 985);
INSERT INTO `user_LearningGoal_user_TargetCompetence` VALUES(1017, 1013);
INSERT INTO `user_LearningGoal_user_TargetCompetence` VALUES(1043, 1040);
INSERT INTO `user_LearningGoal_user_TargetCompetence` VALUES(1069, 1066);

-- --------------------------------------------------------

--
-- Table structure for table `user_MembershipStatus`
--

CREATE TABLE `user_MembershipStatus` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32d5dcf57c` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_MembershipStatus`
--


-- --------------------------------------------------------

--
-- Table structure for table `User_memberships_TeamMembership`
--

CREATE TABLE `User_memberships_TeamMembership` (
  `user_User_id` bigint(20) NOT NULL,
  `memberships_id` bigint(20) NOT NULL,
  KEY `FK3FC45429C0DE40C6` (`memberships_id`),
  KEY `FK3FC45429146C725C` (`user_User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `User_memberships_TeamMembership`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_MonitoredEventPref`
--

CREATE TABLE `user_MonitoredEventPref` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `eventURI` varchar(255) DEFAULT NULL,
  `monitoringOn` tinyint(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD327d3bfd78` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_MonitoredEventPref`
--

INSERT INTO `user_MonitoredEventPref` VALUES(15, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/bb9a0987-efe7-4cbe-9ae3-4fa62a70b7cb', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(16, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f4c4eb94-bf8c-4bad-8e3b-45816dbdc652', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(17, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/4202b157-6bd0-4a77-a6fe-f25ddba4e7be', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(18, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c386315c-e9c8-4295-beee-747fd7e43a41', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(19, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e8b1529c-a004-4da0-8e2f-19d68a410fb6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(20, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7ae8a864-3925-4e49-b9a5-4fd8f57c4d57', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(21, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b7ee59d5-5737-413c-b320-ab6aa55325ad', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(43, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5c7c2559-4b25-4836-876f-4588fb91ae49', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(44, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/134f65c8-4cc5-4f64-a965-71672015e9ae', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(45, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6f642137-034f-48a6-ac20-80da15bc4f84', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(46, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/33a56d3e-d8ea-4a28-95d1-eea6637f2f32', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(47, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5fe13ae5-aacf-4e92-a720-f8a60b4f434e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(48, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e9ebdd63-73c8-4b5e-a7a2-7ece92339260', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(49, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/77d9fc59-cbfd-4db6-915f-720760655651', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(58, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/150528ca-b9b4-42b5-a68b-c6a16c0dc7aa', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(59, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a596990e-6f4d-47e9-b2b9-8e5f42c889a9', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(60, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5fbe3683-f517-43bb-8004-2343b5ee7023', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(61, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/aa8c8644-6bf4-43a2-82cf-b49033c133bf', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(62, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/edd76a48-34ce-4f21-9a19-97dbeac02523', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(63, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/beea5f28-2532-477f-be6b-f7d8752f9fb1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(64, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/2c2b199d-971d-4ace-86a1-54ca03ee12cc', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(73, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c1c3ebb5-6635-475a-943c-e2d94acd29b8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(74, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d017afab-4518-423a-b35b-7da41667cbf8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(75, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/500fe4a7-03f2-48d2-be5f-3ca516d1b8ad', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(76, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c6d5fb8d-3fc7-4202-9cf6-eebb9af75e36', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(77, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/9d0fa598-cb1d-4c75-9086-992818b29a5b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(78, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/11fb977a-decd-455f-905e-bf376ac77b7e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(79, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/af7140a5-8b75-4bea-bff0-a6e6e7d22776', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(88, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c3968a97-bdb5-48fb-a056-e37f87d649bf', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(89, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/666d520c-54fd-4ea3-8fae-c727b016bf2b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(90, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/2bc0af6f-9e19-4bcb-beeb-a004225bb3f3', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(91, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f7acd97a-b6d7-4b0d-882b-586a82ffa396', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(92, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a7e46a40-9a8e-4644-9ee3-7856bd88b2a1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(93, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/8b1a4978-678c-4b39-9409-88f753a9620d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(94, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/8ed9a57b-2e5a-469c-9d91-23881d3472fe', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(103, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d931c898-d067-4045-8f7d-a60b5713eb7a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(104, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/90989d47-5c73-42cb-9b06-a23e87031325', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(105, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/4c4e3988-997b-49df-ba2f-adbea34aaba8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(106, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/83e15788-6a18-4f6f-bd2e-4f2d5f327db4', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(107, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f4c4a555-2fd5-4572-8f99-58e85f51f818', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(108, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/71bbe4d6-a973-4a9f-9b34-84b82bf37793', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(109, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/85e3cdb2-ad8b-4c35-9132-b2edf3bdb69a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(118, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/09251af5-cb8a-4f53-95fb-73c4e2ee0a44', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(119, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/68061cbd-9932-4e1b-b5e6-49e5b077fb70', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(120, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/72fa9e53-4a87-4d4c-ab3e-a364005e4fbb', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(121, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a8f6960d-37d0-4f39-9304-74b61ac515e1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(122, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/17c1f15e-85aa-4b39-8f30-d4408cbcf759', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(123, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/50c0d48a-ed8d-46ad-85ca-8623e45093c7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(124, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1b96eb2d-d56b-47e1-a327-dfa9ee151285', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(133, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0f0763cc-d184-4df0-914d-4ce0ee4233be', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(134, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/15ad130f-3a99-45e1-99a6-d987e4496217', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(135, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e8c383cc-412b-49c8-84f9-ed1b83b65ee4', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(136, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/557593de-5d44-4534-80e0-a574986561da', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(137, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b1fbea47-d399-4568-94d1-e5141abd889b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(138, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/8b5a98a8-928b-4b25-ad6a-3376b9f66c73', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(139, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e296c79d-4da8-44e6-9cfc-9df577383c87', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(148, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f8dfa8d5-facf-4b5b-9a6d-997b232c21cc', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(149, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6a4e0755-dc26-49c5-9f1b-9c419e4b03da', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(150, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b714b3c4-90a3-4754-9ccd-92230c64d316', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(151, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/093d6901-11ee-45d2-8f50-a9f37413a098', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(152, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5eb7f929-edd0-409f-b1ef-bf7a3bb1b7c6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(153, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/08bca473-5380-44ad-a6a5-220a6efce482', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(154, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/611123c2-5a8e-41a3-9003-8097ece2da22', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(163, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b6b24010-6f89-4f8f-9e4c-41985e4fe81b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(164, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/65d0002b-8645-4d05-9099-1ca9f5364ba1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(165, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a900aa7b-b757-4159-91e8-67a9577f26c2', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(166, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0eb9632a-778c-48e9-a9c4-bd0924d9a3fb', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(167, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b8e7e045-245b-46fc-9ede-3c7db616ba1b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(168, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/25456e24-3947-4b56-910b-cb5f679d659b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(169, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/eda0c5e8-65b0-4aa3-9a41-326077a08ca7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(518, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/8f410178-b9ca-495a-815f-b3aff1e4d8ba', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(519, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/ef071c94-45bd-4fe3-809e-38a361b56fb1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(520, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/2079c1ce-ebe2-4ce2-aae6-86484e51d465', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(521, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f44a813a-ed55-46b4-a672-f559e293bb2c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(522, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/673f2bef-546f-4644-aa11-d8c3cf68367a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(523, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5f2f22d6-3577-418e-af18-a5f46f060a58', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(524, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/72b4c855-44e6-48a7-9166-0b62a77b8357', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(533, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/55397149-33d2-4087-839f-e015f475da52', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(534, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/cca1cf55-5d56-4d62-8e83-6e6fc4a90607', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(535, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/77117dad-2931-43fa-bf10-fd68cb55d30c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(536, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/9a4ca2cb-3a94-4916-afc8-ba72d03ca297', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(537, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0e2dcc9c-efe0-4b8e-9e24-e3c2a929dff1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(538, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/53d28875-118a-4fcc-8e33-d4c7a9a66f5e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(539, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/224bc3d7-6a7d-403c-bfc4-e075933f2704', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(548, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0cab74a5-69b3-4cbd-94bc-0d8f9846805d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(549, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d02dd341-76cf-4303-9592-13ba35c8658a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(550, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a149ece6-862c-4661-86e3-67dd483f7ac3', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(551, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5790dfc7-da63-4663-8732-7ee15a2be6e6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(552, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/ea47807c-b359-4cb1-8a5b-962dc0a7bfc6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(553, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e596a3a7-b6fd-4d93-9fac-291ac01cbe54', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(554, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/13249c2e-1b79-4bff-b449-bb318cd1fbff', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(563, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d309a5d2-9113-46f0-91e7-6fc6bd279847', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(564, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a0cc15eb-b5d9-4d0c-9b60-679590b2445a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(565, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3ffa2526-4061-41ad-ac12-92bffeb2585f', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(566, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b7720644-76a0-4eb8-98fc-766aeeac6847', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(567, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/523f9739-28d7-45a1-beb1-a7733322c45c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(568, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/546e0ae8-a41e-4b17-8a63-9015cac52087', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(569, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a2449267-dfb5-445c-be95-7b8b94993290', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(578, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e3e9629b-bd28-4275-babb-8e9d20a56547', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(579, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/4a874481-e55d-4d5e-84f8-e0d3ad0eb5d5', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(580, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/55a7d82a-2706-4e9c-9290-8f764f9f1816', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(581, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/83e3cca3-7c4e-4ecd-9d7a-1660bba3fa47', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(582, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/aa938f9d-079c-42ff-ac67-86e5073b6b38', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(583, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6b06e3c7-e136-4b40-a3a5-154573d21e8d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(584, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/852ef020-c7f2-4493-9c95-61e19db4b90f', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(593, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/88a895e7-7b44-417e-9ccd-3918bd81c43e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(594, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/90362e8c-cf35-4b1f-bf9a-1c4f5c7079b1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(595, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a315646f-40bd-4e18-bc8d-d783b1321241', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(596, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/dd13b2af-62b9-451e-8c9c-854844fd2a46', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(597, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/87905036-b571-4cdc-a483-b9b49fb4020d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(598, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a4b2804e-0dee-4eb0-8a7d-0877a836391c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(599, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/321ed1b4-e06f-482d-9b12-82d0c7b4d4c0', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(608, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/38252491-f5f0-4db5-bf27-18dca6e20308', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(609, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1e9f733a-d63a-462e-860a-602c06b8c330', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(610, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a5b20439-2967-4459-8d4e-8d87b7ef114b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(611, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7595b9ff-c525-4c8e-a4b1-4d3f4120a1a4', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(612, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3ed83b59-a78e-4b5c-bced-b7349d211231', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(613, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/932e6335-fa40-4354-adc4-cf8cf65a015d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(614, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/00c7dbf8-a74e-4b69-bd2b-d4c8efb0d2da', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(623, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/592715a8-8654-41c5-a02d-8df59fb25a79', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(624, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c2ce225b-cfe8-4a3d-b925-379728a0d4c7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(625, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/5457522b-011a-4448-9248-24d23a0dc2b3', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(626, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f0081c2f-9992-4033-845d-764e11a4d5e0', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(627, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f0c48a44-43c7-4edd-9a15-5176dc8020b8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(628, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/651910ec-a19f-4218-900e-ed5a37af1c1d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(629, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6b060054-5848-4185-a140-3d09d0513362', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(638, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6fcd2f5d-dcff-4090-be34-59c42a7288b8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(639, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/19eec1eb-8adc-40ca-9356-78ed0154d0cc', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(640, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b8d6ff84-98a2-4e08-a026-8da63afa4087', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(641, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/59e1a814-2556-4cd0-b27b-05095f5bed08', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(642, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f061307c-cdff-4543-b558-d008c04f720d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(643, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b26e4854-bcbd-4534-a7ec-c9877be1c785', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(644, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a69f2a4c-a35e-4d4c-b6ef-c4226e37c9f7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(653, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6cfef98f-a2e6-4aee-98a9-882da5d3ea3e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(654, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d4cb503d-2507-411e-87f9-5c12ed9c4a01', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(655, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/81a80997-fd24-4214-8089-fd4db65d7049', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(656, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7bfdfe08-9ff6-498f-b4da-c0a8e47adf8e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(657, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/209a2549-53fb-47ad-96c8-8d6a3ba45195', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(658, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/276636a0-14e7-46ef-a82a-77ed46343d2c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(659, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/ab44e3e0-0aef-47ec-8389-f1ea19b9f579', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(758, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0175a9b1-7737-4b9a-a181-09ff5ea1ae01', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(759, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/fd775b9b-3cab-476f-ba79-e51e546954be', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(760, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/30888d70-966b-423a-a6ac-2e7c22236720', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(761, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/688ae75c-d9d4-4898-86dd-c615405ffd25', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(762, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0112adb2-3eea-4c02-a9a5-296323553789', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(763, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e26c0b64-4c36-451e-b84e-1cf330c42189', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(764, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/df33acba-eeb4-4935-9ba6-507b5e50eff8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(773, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7ba82d78-7cde-4dd8-b078-89ea049b7811', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(774, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1d2cd24e-1326-48b1-8dd3-15f274c042b2', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(775, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/40265b65-8814-4c0d-ab08-45eae21de687', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(776, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f82f5f10-f4b3-469d-b601-41b8dfbfb7b2', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(777, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/a9a31b2a-1782-4ba5-bbb0-b4709772d38a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(778, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0d2f98aa-e621-4505-bf63-c94a84c3ce3c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(779, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1e7e2124-bbde-4967-9c79-0d994f654ff5', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(788, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/0ef2375d-576b-47be-95a8-97781dbc085c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(789, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3a8d1b3f-87e9-4944-8c49-5ee6297d232f', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(790, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/117f8ed6-a727-4e2f-bb7d-ce60bec347b8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(791, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/74eb2389-fece-4176-b3cc-9f78e6fb9023', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(792, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/d32db4c8-72e6-4e1b-870d-ff86ecce5ae0', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(793, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/bba2b7d6-e173-4838-9ca4-2cdae26a48b5', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(794, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/64a35463-f6d6-4386-8201-97105db2216d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(803, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f1a6f7ff-febc-4cdc-8e7a-6a681cdabef3', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(804, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6cb1bbb8-7b8a-496f-9873-69230ef67111', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(805, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6f798111-7fef-4f34-8388-f13e645b2766', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(806, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/ed2446e8-3408-4d57-975b-af5bc9e9fed6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(807, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/38e33ffa-ad18-4be7-a229-5527abbb0687', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(808, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/67417304-0e35-408e-b397-a4307a60e874', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(809, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/4457404b-9aab-42b8-b64c-fd265eb7ce91', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(818, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3db6a637-1913-4115-b6e3-86f0cf99df5b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(819, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/cdea7f6f-2081-441e-90e8-f0aecb2a8f71', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(820, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b563e4f3-81fe-4d7f-a95c-30a7010c6561', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(821, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/00f693b1-0491-46dc-9844-47b1b881eeab', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(822, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3078ad74-cdbf-4e81-962b-7a9800cf79a7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(823, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/ad346800-f9ce-4a6d-a4ae-883a7acd01dc', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(824, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/446ce3c6-610b-4de2-a922-6bdbf7cf09c1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(833, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f177a07e-5b3f-4dd4-a38a-fbe9bd3252c5', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(834, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c195cb11-c5d4-474b-8b13-3c73d7540e9a', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(835, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7fbe42c1-bcd2-4082-952d-736b48b3f31c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(836, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/90ccc016-c0f5-4f1f-bb56-f94e3cccd7b7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(837, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f857b9c9-4bc2-448b-981e-506d1571b589', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(838, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7f93152d-6ebd-4ac9-b349-3126d0e24c85', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(839, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/86eddf46-0018-4167-80c3-1297bd7f0e1e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(848, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7c3cf098-999d-4134-aee7-fd5d58118d0c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(849, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/f910b166-cd58-4086-aed7-2def2026045d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(850, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/443e3ab4-1f3f-41ec-885a-efb5e17a0b34', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(851, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/fb5c7f74-11c3-44ab-8d2c-8a958e2429b6', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(852, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/7e87c1b1-5bb6-46c8-889d-feb6567c259b', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(853, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b0a1d0d5-d4ce-45b3-bddc-70064e9cf2a7', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(854, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/572baf35-bed6-440c-a50b-b9904f057662', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(863, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/4a893898-3178-4d72-b401-0cc2b1ac6719', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(864, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/aa3d487e-ea17-48fd-a637-1fe631b9735c', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(865, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/aa2fce69-fbe1-4276-93fa-c1bde0f96510', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(866, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/22250d04-3070-47c0-bc62-6d6074f0b6bc', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(867, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6727d0ca-a0af-4b48-a954-9b864b3a55b1', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(868, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/eaa7e6ea-b501-4b66-af3c-9fa90e1a413d', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(869, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/231568e6-bd10-44a1-bc33-3bf451bcfabf', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(878, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6c922817-1487-412d-bad8-f0a6d00e1c0e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(879, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/764ea761-d6f9-43ce-a924-a8f264b2be17', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(880, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/3740b6b0-4735-48a8-9f57-66e82cc9bf47', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(881, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/bc484b89-fcba-4296-92bf-138f33a1416f', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(882, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/fc3cbe6b-e6fb-43de-8250-594c72e3aa56', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(883, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1f8e1a49-f440-4c99-ae41-30e295960c0e', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(884, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/b1c1d81f-5078-49f9-a1d7-5b5d3e73f2a0', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(893, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/453c68c6-a97a-40c0-9ec4-838452c65bd8', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Save', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(894, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/aed88388-2219-471f-884f-c7e54cff7063', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Delete', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(895, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/6f3be872-747c-4b88-9c86-c9728e9af245', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Restore', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(896, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/e7b44abd-2a3e-49ff-8457-c75ad41d0278', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Logging', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(897, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/c2009c0e-fbbf-437b-b162-89e1c0963fd5', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/SubscribeToChanges', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(898, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/1a2a3a92-3d58-423f-bc20-5a970def5fb4', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Upload', 1);
INSERT INTO `user_MonitoredEventPref` VALUES(899, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoredEventPreference/037fb56d-644c-4bd9-af91-d7807f61e081', NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/activities/ns/Query', 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_MonitoringPreferences`
--

CREATE TABLE `user_MonitoringPreferences` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `anonymousMonitoring` tinyint(1) DEFAULT NULL,
  `monitoringSettings` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321c22e1994642a7fc` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_MonitoringPreferences`
--

INSERT INTO `user_MonitoringPreferences` VALUES(22, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/c6a5fcc5-fde0-4dc9-93fb-5cc8d0c8c3df', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(50, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/a0a13520-5439-4aa4-b784-647097ded895', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(65, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/bbb1a5f3-7156-4fe2-91f7-4227f9f49b2b', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(80, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/99134e9b-0acb-4e98-846b-0a6a542e5b2e', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(95, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/07ec86a2-6950-4b1f-ac2d-29a1e6509276', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(110, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/0020a0c7-08a7-4662-bea9-dcc1b300e51d', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(125, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/df8c8f13-5c32-4a0c-98f3-dd81129d9de7', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(140, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/2c16bdf8-3a08-4fa2-8a1f-4641d6848ba0', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(155, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/036dc1e4-7d6d-46c8-90ac-36b4b40ebf8d', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(170, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/e509dccf-b1a0-4c71-8bd9-c1f7c210cea1', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(525, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/99adebbb-dd82-4661-80a2-bae2109ce1aa', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(540, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/5b1fa8ba-d445-45ec-9ce4-2420d59aad07', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(555, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/14caa053-5f97-4cac-95cb-44700832cb91', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(570, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/89a223b0-b2cb-4ba6-ab97-65c595314644', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(585, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/7aa0fce2-788a-44d6-8043-896bab09d95e', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(600, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/ed24daf8-b828-4693-b024-1d7c9868d5ee', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(615, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/eaa76ac2-41df-4dca-b74c-bcc0449566aa', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(630, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/b8e3d131-521a-424b-82f4-5fe9c1f41309', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(645, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/accf12b3-d42b-4b2c-9955-4138a1ae1c1e', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(660, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/b39ca584-8daa-4179-8955-09c13a660eed', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(765, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/f82c673a-e311-4cc6-94eb-66d7d0257616', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(780, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/c1cb050c-b629-459b-978f-d42c9e7eab00', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(795, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/e9e61594-aac4-4b5e-8ab4-d984708b8765', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(810, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/c63c5808-eb26-4591-9a5f-7bc69985e502', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(825, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/36977383-02a1-4cdf-ac99-b9a0ae7611c1', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(840, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/e960d4c9-5e89-4959-a91b-6790b7daf463', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(855, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/00a3c669-c59d-4dfc-b6c6-d3af9334f759', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(870, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/9a4fe739-942d-4396-b4e5-6532b2289e68', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(885, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/57a5f45f-ef77-44a6-a65d-96ea38bf25e7', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');
INSERT INTO `user_MonitoringPreferences` VALUES(900, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#MonitoringPreferences/24101e05-627d-4d53-99ae-ead58e0ccab1', NULL, NULL, NULL, NULL, NULL, 0, 'ALL');

-- --------------------------------------------------------

--
-- Table structure for table `user_MonitoringPreferences_user_MonitoredEventPref`
--

CREATE TABLE `user_MonitoringPreferences_user_MonitoredEventPref` (
  `user_MonitoringPreferences_id` bigint(20) NOT NULL,
  `eventPreferences_id` bigint(20) NOT NULL,
  UNIQUE KEY `eventPreferences_id` (`eventPreferences_id`),
  KEY `FKC3D976352FFCC52E` (`eventPreferences_id`),
  KEY `FKC3D9763559533758` (`user_MonitoringPreferences_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_MonitoringPreferences_user_MonitoredEventPref`
--

INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 15);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 16);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 17);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 18);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 19);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 20);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(22, 21);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 43);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 44);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 45);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 46);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 47);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 48);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(50, 49);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 58);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 59);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 60);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 61);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 62);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 63);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(65, 64);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 73);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 74);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 75);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 76);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 77);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 78);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(80, 79);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 88);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 89);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 90);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 91);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 92);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 93);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(95, 94);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 103);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 104);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 105);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 106);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 107);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 108);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(110, 109);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 118);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 119);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 120);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 121);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 122);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 123);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(125, 124);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 133);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 134);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 135);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 136);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 137);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 138);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(140, 139);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 148);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 149);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 150);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 151);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 152);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 153);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(155, 154);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 163);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 164);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 165);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 166);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 167);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 168);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(170, 169);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 518);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 519);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 520);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 521);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 522);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 523);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(525, 524);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 533);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 534);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 535);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 536);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 537);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 538);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(540, 539);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 548);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 549);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 550);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 551);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 552);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 553);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(555, 554);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 563);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 564);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 565);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 566);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 567);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 568);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(570, 569);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 578);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 579);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 580);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 581);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 582);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 583);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(585, 584);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 593);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 594);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 595);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 596);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 597);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 598);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(600, 599);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 608);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 609);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 610);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 611);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 612);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 613);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(615, 614);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 623);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 624);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 625);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 626);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 627);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 628);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(630, 629);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 638);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 639);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 640);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 641);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 642);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 643);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(645, 644);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 653);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 654);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 655);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 656);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 657);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 658);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(660, 659);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 758);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 759);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 760);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 761);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 762);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 763);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(765, 764);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 773);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 774);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 775);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 776);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 777);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 778);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(780, 779);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 788);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 789);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 790);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 791);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 792);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 793);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(795, 794);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 803);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 804);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 805);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 806);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 807);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 808);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(810, 809);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 818);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 819);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 820);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 821);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 822);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 823);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(825, 824);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 833);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 834);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 835);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 836);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 837);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 838);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(840, 839);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 848);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 849);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 850);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 851);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 852);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 853);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(855, 854);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 863);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 864);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 865);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 866);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 867);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 868);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(870, 869);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 878);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 879);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 880);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 881);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 882);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 883);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(885, 884);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 893);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 894);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 895);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 896);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 897);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 898);
INSERT INTO `user_MonitoringPreferences_user_MonitoredEventPref` VALUES(900, 899);

-- --------------------------------------------------------

--
-- Table structure for table `user_PriorityType`
--

CREATE TABLE `user_PriorityType` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32afbb9f12` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_PriorityType`
--

INSERT INTO `user_PriorityType` VALUES(5, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/TopicPriority', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_PriorityType` VALUES(8, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/LearningGoalPriority', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_PriorityType` VALUES(10, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/CompetencePriority', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_PriorityType` VALUES(12, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/LearningHistoryPriority', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_Recognition`
--

CREATE TABLE `user_Recognition` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `message` varchar(255) DEFAULT NULL,
  `givenBy_id` bigint(20) DEFAULT NULL,
  `recognitionFor_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK20AA19235DD28D67` (`givenBy_id`),
  KEY `FKEF86282E5F3CFD3220aa1923` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_Recognition`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_RecommendationPreferences`
--

CREATE TABLE `user_RecommendationPreferences` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `hrRecommendationFrequency` tinyblob,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321c22e199606315eb` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_RecommendationPreferences`
--

INSERT INTO `user_RecommendationPreferences` VALUES(14, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/261075da-d7ae-43af-9c6e-00dfe2496efb', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(42, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/328690f2-7d57-4ed9-be07-bc32821c4d47', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(57, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/a91b41ef-3e82-4c38-bc0f-9f80a8918238', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(72, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/8ff83f0f-1b6b-4b0a-b8aa-a718d0e102d9', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(87, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/39aba973-b356-45b5-b54c-5d9f7b24279c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(102, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/cd316f80-8ae0-4568-bed8-654572234974', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(117, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/2aee4709-eb7b-4d66-a575-a863d0f49ef8', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(132, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/426aadb5-1586-4879-886e-032c67f2fe7f', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(147, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/adbdc56b-c024-4f21-810b-24f8176cd462', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(162, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/a2edb29f-63ef-4a0c-8cf1-a246683dfbee', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(517, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/9113e412-cc5f-451c-9b38-0e99faf8dd38', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(532, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/b379c4bd-bc1a-4539-8996-23d08fef6a0b', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(547, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/e2618796-aaa1-4708-bbc6-f4d712b20131', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(562, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/ea9f1f3a-7c28-492d-8d58-d243be0b7aad', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(577, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/608ad155-19d7-4bd5-919d-2866e16cee15', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(592, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/ef582deb-36b3-4592-af65-19dd9c38aa20', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(607, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/8570db74-a6a6-4569-9dcd-c4540d129b44', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(622, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/47f12508-88bf-479d-acb9-c8b8023a9dd9', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(637, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/76429147-8e17-49d0-b0ee-787af0ca2387', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(652, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/28f9bdd2-990e-47fd-9267-01e61fb045e5', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(757, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/b3d23c4b-6827-4e65-b22a-7c62ab827856', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(772, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/eca59e77-aeb1-4260-b26b-434bd50509ae', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(787, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/1d31341d-cff7-4dc7-aef3-3513552fa35c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(802, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/3e53b612-f593-4791-a7ca-4ffcd3bf2098', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(817, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/5afa36d8-fec5-414d-8f4a-29be595a3a57', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(832, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/b3d4ad00-fcbb-4f23-b1f0-ee6d6c153357', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(847, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/687ed3f6-8061-46a2-b6e4-8644bab55fb5', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(862, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/f24df59a-0ac1-4197-b118-c677b06bf93c', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(877, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/79f6545d-8711-4fef-bd8a-a24246293e78', NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_RecommendationPreferences` VALUES(892, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#RecommendationPreferences/ff378b09-fbaf-4947-a483-cbad5eadcefb', NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_RecommendationPreferences_user_UserDefinedPriority`
--

CREATE TABLE `user_RecommendationPreferences_user_UserDefinedPriority` (
  `user_RecommendationPreferences_id` bigint(20) NOT NULL,
  `userPriorities_id` bigint(20) NOT NULL,
  UNIQUE KEY `userPriorities_id` (`userPriorities_id`),
  KEY `FK8A7258C2984CEDF8` (`user_RecommendationPreferences_id`),
  KEY `FK8A7258C25C02EB19` (`userPriorities_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_RecommendationPreferences_user_UserDefinedPriority`
--

INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(14, 7);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(14, 9);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(14, 11);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(14, 13);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(42, 38);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(42, 39);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(42, 40);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(42, 41);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(57, 53);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(57, 54);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(57, 55);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(57, 56);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(72, 68);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(72, 69);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(72, 70);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(72, 71);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(87, 83);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(87, 84);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(87, 85);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(87, 86);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(102, 98);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(102, 99);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(102, 100);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(102, 101);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(117, 113);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(117, 114);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(117, 115);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(117, 116);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(132, 128);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(132, 129);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(132, 130);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(132, 131);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(147, 143);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(147, 144);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(147, 145);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(147, 146);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(162, 158);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(162, 159);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(162, 160);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(162, 161);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(517, 513);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(517, 514);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(517, 515);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(517, 516);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(532, 528);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(532, 529);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(532, 530);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(532, 531);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(547, 543);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(547, 544);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(547, 545);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(547, 546);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(562, 558);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(562, 559);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(562, 560);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(562, 561);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(577, 573);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(577, 574);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(577, 575);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(577, 576);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(592, 588);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(592, 589);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(592, 590);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(592, 591);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(607, 603);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(607, 604);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(607, 605);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(607, 606);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(622, 618);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(622, 619);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(622, 620);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(622, 621);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(637, 633);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(637, 634);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(637, 635);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(637, 636);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(652, 648);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(652, 649);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(652, 650);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(652, 651);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(757, 753);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(757, 754);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(757, 755);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(757, 756);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(772, 768);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(772, 769);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(772, 770);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(772, 771);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(787, 783);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(787, 784);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(787, 785);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(787, 786);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(802, 798);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(802, 799);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(802, 800);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(802, 801);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(817, 813);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(817, 814);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(817, 815);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(817, 816);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(832, 828);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(832, 829);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(832, 830);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(832, 831);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(847, 843);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(847, 844);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(847, 845);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(847, 846);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(862, 858);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(862, 859);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(862, 860);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(862, 861);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(877, 873);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(877, 874);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(877, 875);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(877, 876);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(892, 888);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(892, 889);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(892, 890);
INSERT INTO `user_RecommendationPreferences_user_UserDefinedPriority` VALUES(892, 891);

-- --------------------------------------------------------

--
-- Table structure for table `user_SocialEvent`
--

CREATE TABLE `user_SocialEvent` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `deleted` char(1) DEFAULT NULL,
  `readed` char(1) DEFAULT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD328e5ca099` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_SocialEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_SocialStream`
--

CREATE TABLE `user_SocialStream` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD325504e161` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_SocialStream`
--

INSERT INTO `user_SocialStream` VALUES(462, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/b4a9c101-9cec-4834-800c-ff2e167c045f', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(467, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/0d48eb92-c12e-4040-9874-c48713a46c86', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(471, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/0009fbda-3379-4ede-bb0e-67edf25cdb9d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(475, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/d9ee9c28-00e9-4838-8302-8a8405811ba7', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(479, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/6ec957d6-6cb0-40ee-93c1-dfa10d31d973', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(483, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/3ada3971-1c42-4be2-9410-7c2aa944cfd4', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(487, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/22ee7203-dc14-421d-ad82-d3ad1e1a32a1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(491, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/a833de03-79f6-4d4e-a2db-1ead6125dcc8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(495, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/fd393a92-fe28-4395-bfe8-1cea54618c43', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(499, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/54aa99f2-209d-4354-9762-6a44d9e108c9', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(672, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/a746fc97-32d4-4cae-a349-d184291686bd', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(676, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/973bfdc2-30ab-428b-9c9b-ea6d4694b259', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(680, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/8c441abe-14b2-4ea1-9fe8-2b65ec9cb2e1', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(684, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/ca88ebd7-1613-45ab-a486-a0028d9ac7e9', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(688, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/d03c75fb-e3d8-4bb4-8d24-b99a736528c3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(692, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/9ae4fe67-8f1a-4727-8e9f-5078bf94e961', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(696, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/966b0be9-47d4-4fbf-94bf-f4d14e48032b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(700, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/c1be579f-fd16-4549-9d60-8167cae0dd8f', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(704, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/5e2f9837-fb1f-4de2-a19a-de1e92c2c05e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(708, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/2935a648-dd2b-46df-a717-faef8400d26b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(712, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/f69a5a63-4b16-48df-a4a7-46d7a3c284f5', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(716, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/fcacee07-7d32-403b-af42-65a244f57976', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(720, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/bfbf5614-8cf9-4eda-8f54-c3281b918e60', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(724, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/9bb91a2b-6edb-4930-929b-3b43b533f678', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(728, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/3f46e5e3-caaa-4476-be9c-5f5548033c02', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(732, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/20ef24e5-b2b9-453b-9b24-c335eb8d8930', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(736, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/b809aee1-ae63-4063-b722-0c7a8efb73b0', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(740, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/e3ab7ca4-93f2-4bd2-aef3-689c59ba6d7c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(744, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/82778b46-6cf2-46ac-9e8b-3f0c5bd157f5', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(748, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/8d830e6e-346f-48e3-82f0-e6622ef9f1fa', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(912, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/2f98000d-efb4-4cae-9617-902fa219fbb8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(913, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/9b1961bf-8732-47c9-baab-080cdceb5202', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(914, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/dca9ecbe-d54a-456a-bc37-d3e49b61929c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(915, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/018f32ba-55f0-4407-9ca0-0ac6ee3de3fc', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(916, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/5cb00557-5659-4b63-a6bc-3ed449b83398', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(917, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/fecbdc2e-7280-419c-b6f3-821e82955371', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(918, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/59401776-0ede-49c4-ba03-b97ecf5052f8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(919, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/84ef5211-717c-4788-b34e-a95d42ccb041', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(920, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/08676ba3-53a2-4667-9ff6-cda8ae68870b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(921, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/1360b86a-0c12-494b-bf4b-d3ffb952b647', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(922, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/289eedc5-433b-4995-9bce-c3a82ebb5a35', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(923, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/408da5ee-1610-478a-8b30-4b8f06932a40', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(924, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/270c4251-5402-4efa-bd1a-b52154006dc3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(925, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/e92ca489-7b16-4d51-9968-be7ec4c17104', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(926, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/e019813e-e740-494f-bed6-9ba6384bec3e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(927, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/513badfd-a6f2-4013-8ac9-c1c5c59cea27', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(928, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/72656a11-0129-422b-9d55-ab11bcd8a92e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(929, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/c34e254b-2974-4c6a-8a3e-df1bcdce0f02', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(930, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/255945e8-58e8-4652-867b-1217b873ce2a', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(931, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/8804ae4b-87a9-4417-b594-475d1cd229b2', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(932, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/a9a2653d-b38f-4633-be99-e8dc46cd1c76', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(933, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/b9eafb24-8d62-4c37-a3e1-696b4c20ad3c', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(934, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/dee8730a-38e4-44c7-807c-5c422dbf036b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(935, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/48064a4d-ac4e-4c81-9057-efbf271924f8', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(936, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/13974670-c702-4e44-bb5a-5c73e8c171a2', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(937, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/d9c74928-6cbd-44af-8d23-4af010f5dbc5', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(938, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/e49f435a-5393-4f06-ab74-07d956765ffd', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(939, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/e8929226-80ce-4957-bfec-6c201930f1f3', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(940, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/7f9ef604-8fe5-4abf-9fc2-23455e8cfb22', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_SocialStream` VALUES(941, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#SocialStream/c9835dad-e8eb-426e-8e95-710001c33b08', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_SocialStream_user_SocialEvent`
--

CREATE TABLE `user_SocialStream_user_SocialEvent` (
  `user_SocialStream_id` bigint(20) NOT NULL,
  `socialEvents_id` bigint(20) NOT NULL,
  UNIQUE KEY `socialEvents_id` (`socialEvents_id`),
  KEY `FK3E5EFB715D6293C` (`user_SocialStream_id`),
  KEY `FK3E5EFB772BC66AB` (`socialEvents_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_SocialStream_user_SocialEvent`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_TargetCompetence`
--

CREATE TABLE `user_TargetCompetence` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `arhived` char(1) DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `goalcompetencerelatedness` double DEFAULT NULL,
  `assignedBy_id` bigint(20) DEFAULT NULL,
  `competence_id` bigint(20) DEFAULT NULL,
  `currentLevel_id` bigint(20) DEFAULT NULL,
  `currentTask_id` bigint(20) DEFAULT NULL,
  `progress_id` bigint(20) DEFAULT NULL,
  `targetLevel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKD3714E4E5BC392F9` (`currentLevel_id`),
  KEY `FKD3714E4EDACEA67B` (`progress_id`),
  KEY `FKD3714E4E84F1C1B6` (`assignedBy_id`),
  KEY `FKEF86282E5F3CFD32d3714e4e` (`originatesFrom`),
  KEY `FKD3714E4E768CAF11` (`targetLevel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TargetCompetence`
--

INSERT INTO `user_TargetCompetence` VALUES(211, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/ff7617cd-3ce0-4415-a9b5-c4678dc2b08e', NULL, 126, NULL, NULL, 210, 'F', NULL, 0, NULL, 190, 209, 206, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(240, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/23cc80c6-d942-47d9-87fd-dd5b285afb5a', NULL, 81, NULL, NULL, 239, 'F', NULL, 0, NULL, 190, 209, 234, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(275, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/0687bb24-11e0-47fc-9f30-53c22ad1838a', NULL, 141, NULL, NULL, 274, 'F', NULL, 0, NULL, 242, 209, 269, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(294, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/3a5c843f-2081-4100-9bab-8e06bd4a9561', NULL, 81, NULL, NULL, 293, 'F', NULL, 0, NULL, 242, 209, 288, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(319, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/197cc85c-a400-40b6-a158-649732d0daff', NULL, 126, NULL, NULL, 318, 'F', NULL, 0, NULL, 242, 209, NULL, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(338, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/b9633bed-d214-41d9-b228-c394d6ecc016', NULL, 23, NULL, NULL, 337, 'F', NULL, 0, NULL, NULL, 209, NULL, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(432, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/e2d08d64-72a6-4d55-a9c4-82175961af54', NULL, 111, NULL, NULL, 431, 'F', NULL, 0, NULL, 190, 209, 428, NULL, 176);
INSERT INTO `user_TargetCompetence` VALUES(438, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to formalize domain model using OWL ontology language0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/f1b79559-27fd-46f6-8c12-add5188bd8eb', NULL, NULL, NULL, NULL, 437, 'F', '2012-04-02 13:07:20', 0, NULL, 340, 433, 420, 436, 176);
INSERT INTO `user_TargetCompetence` VALUES(985, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/3769099b-01a3-4fe8-ba27-931f34469816', NULL, 23, NULL, NULL, 984, 'F', '2012-03-26 13:07:35', 0, NULL, 175, 433, 979, 965, 176);
INSERT INTO `user_TargetCompetence` VALUES(990, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/21c339c6-f080-49a5-8210-bf88e5fa81ac', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 991, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1013, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/f22e786f-3370-4a7b-ba6f-c05fa5995536', NULL, 96, NULL, NULL, 1012, 'F', '2012-03-16 13:07:35', 0, NULL, 175, 209, 1007, 993, 176);
INSERT INTO `user_TargetCompetence` VALUES(1018, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/0c7779a8-0ad4-4343-b237-74027bed6286', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 1019, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1040, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/79aa959e-b1fe-4d8b-b63d-4728eeb8d92b', NULL, 81, NULL, NULL, 1039, 'F', '2012-03-28 13:07:35', 0, NULL, 175, 209, 1034, 1020, 176);
INSERT INTO `user_TargetCompetence` VALUES(1044, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/52d9a3bf-5b89-4fd4-aecf-3812b82b0278', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 1045, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1066, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to create a domain model at conceptual level0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/89c15fb1-4991-4031-a12d-731ee06a8595', NULL, 126, NULL, NULL, 1065, 'F', '2012-03-13 13:07:35', 0, NULL, 175, 176, 1060, 1046, 176);
INSERT INTO `user_TargetCompetence` VALUES(1070, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/62ce2d7b-78d0-4b30-a839-8273e7807cc7', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 1071, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1072, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to construct industrial software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/c3929b58-fad1-4566-975f-04b91b870a9e', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 1073, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1074, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/01e9c74e-01c4-4114-8150-228e84234657', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TargetCompetence` VALUES(1075, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Ability to develop complex software systems0', 'http://intelleo.org/triplestore/bc_x#TargetCompetence/22ebfa1d-836a-4684-aa55-f0f901f6cc5a', NULL, NULL, NULL, NULL, NULL, 'F', NULL, 0, NULL, 1076, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_TargetCompetence_CompetenceRecord`
--

CREATE TABLE `user_TargetCompetence_CompetenceRecord` (
  `user_TargetCompetence_id` bigint(20) NOT NULL,
  `competenceRecords_id` bigint(20) NOT NULL,
  UNIQUE KEY `competenceRecords_id` (`competenceRecords_id`),
  KEY `FK5AD0336BAC9ACE8C` (`competenceRecords_id`),
  KEY `FK5AD0336B2982051C` (`user_TargetCompetence_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TargetCompetence_CompetenceRecord`
--

INSERT INTO `user_TargetCompetence_CompetenceRecord` VALUES(438, 435);
INSERT INTO `user_TargetCompetence_CompetenceRecord` VALUES(985, 966);
INSERT INTO `user_TargetCompetence_CompetenceRecord` VALUES(1013, 994);
INSERT INTO `user_TargetCompetence_CompetenceRecord` VALUES(1040, 1021);
INSERT INTO `user_TargetCompetence_CompetenceRecord` VALUES(1066, 1047);

-- --------------------------------------------------------

--
-- Table structure for table `user_TargetCompetence_user_TargetCompetence`
--

CREATE TABLE `user_TargetCompetence_user_TargetCompetence` (
  `user_TargetCompetence_id` bigint(20) NOT NULL,
  `targetCompetenceChildren_id` bigint(20) NOT NULL,
  UNIQUE KEY `targetCompetenceChildren_id` (`targetCompetenceChildren_id`),
  KEY `FKAF910F1D94ACC731` (`targetCompetenceChildren_id`),
  KEY `FKAF910F1D2982051C` (`user_TargetCompetence_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TargetCompetence_user_TargetCompetence`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_TargetCompetence_workflow_LearningTask`
--

CREATE TABLE `user_TargetCompetence_workflow_LearningTask` (
  `user_TargetCompetence_id` bigint(20) NOT NULL,
  `recommendedTasks_id` bigint(20) NOT NULL,
  `abandonedTasks_id` bigint(20) NOT NULL,
  UNIQUE KEY `recommendedTasks_id` (`recommendedTasks_id`),
  UNIQUE KEY `abandonedTasks_id` (`abandonedTasks_id`),
  KEY `FK5D4ED3322982051C` (`user_TargetCompetence_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TargetCompetence_workflow_LearningTask`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_Team`
--

CREATE TABLE `user_Team` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  `teamInitiator_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD323c452e5b537398e142e2a71` (`originatesFrom`),
  KEY `FK142E2A7184DD58C9` (`teamInitiator_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_Team`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_TeamMembership`
--

CREATE TABLE `user_TeamMembership` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `endDate` datetime DEFAULT NULL,
  `startDate` datetime DEFAULT NULL,
  `status_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  `user_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK97E3F527B97CDAD0` (`user_id`),
  KEY `FK97E3F5275C530FE6` (`status_id`),
  KEY `FK97E3F5276C777990` (`team_id`),
  KEY `FKEF86282E5F3CFD3297e3f527` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TeamMembership`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_Team_user_TeamMembership`
--

CREATE TABLE `user_Team_user_TeamMembership` (
  `user_Team_id` bigint(20) NOT NULL,
  `memberships_id` bigint(20) NOT NULL,
  UNIQUE KEY `memberships_id` (`memberships_id`),
  KEY `FK65EC0A59C0DE40C6` (`memberships_id`),
  KEY `FK65EC0A59C767111C` (`user_Team_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_Team_user_TeamMembership`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_TimeFrame`
--

CREATE TABLE `user_TimeFrame` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32d5a8230c` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TimeFrame`
--

INSERT INTO `user_TimeFrame` VALUES(465, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/user-model/ns/Daily', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_TopicPreference`
--

CREATE TABLE `user_TopicPreference` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321c22e199f6dfad6` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_TopicPreference`
--

INSERT INTO `user_TopicPreference` VALUES(172, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/bc10c15b-92b2-4c63-a611-4317e59bee7f', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(173, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/5a0dff3b-e18c-473c-97ba-55078aebe761', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(463, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/6ed9b12a-dd60-43e1-b57c-042cfc930f36', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(468, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/c8a7c4a4-513d-489e-98a3-5b7b4d01a0be', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(472, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/79feeb73-2677-4479-b8c1-f0372c455a9a', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(476, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/961b33f7-a8bc-408a-a123-e5c1e55be8b2', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(480, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/28e92006-aeb9-442a-b804-3df61483a0ec', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(484, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/522a3952-f7cf-4aa0-b9c5-bd70a67e0e0b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(488, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/b8e33371-c9f8-4b93-a4ff-3e79fd40d2e7', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(492, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/5c7d3eeb-7e43-49fb-8237-b47fc3ec62df', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(496, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/28143167-3ab4-419c-b109-cf143306485d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(500, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/10fae83f-7ea3-45c3-82c3-3084c8f6fc27', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(673, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/860d3ab6-cd25-48ae-bf59-ffd442fec5de', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(677, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/bbaf3d75-cfdf-4d87-9d98-4717af355c20', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(681, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/48690a61-97fd-4904-ae98-d4568836e30f', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(685, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/4bffa34a-967e-49e5-8ed4-ce16e777c081', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(689, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/3dfa948a-4e2c-48b0-80d7-88dbd2fe0d5b', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(693, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/22b56b2f-ebad-4949-ab10-f10f25e26398', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(697, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/6eef794b-3f07-466a-b353-4d9b844c285d', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(701, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/970d42c8-d316-4541-a472-96f3511b9078', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(705, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/6213cf01-ed6f-4463-a963-948211219c98', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(709, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/a2986452-5d13-4a43-9720-df260adea61e', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(713, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/86adb45c-d308-4b5f-a94d-02e4ef8d4532', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(717, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/0e15f28b-9b39-481c-b609-c44648943193', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(721, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/eedc1ea9-a68a-4539-90c1-52dc6d798f97', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(725, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/90023687-db80-41bb-8517-7b687540bc9a', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(729, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/ff24e84b-a7d6-4092-af32-dd26dd060a61', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(733, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/306e986f-8a50-41af-bf13-ef8c9bf4979a', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(737, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/1e09fd2c-f8e2-449b-8a4b-1fc2c5dbaf11', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(741, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/5fb00c35-0d7e-4e8d-915b-d7a1f984d177', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(745, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/42d67d5d-5356-4c36-9be7-17a5ad949fed', NULL, NULL, NULL, NULL, NULL);
INSERT INTO `user_TopicPreference` VALUES(749, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#TopicPreference/71543cdc-9273-43bb-a1c7-586e792028c6', NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_User`
--

CREATE TABLE `user_User` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `holderOf` tinyblob,
  `name` varchar(255) DEFAULT NULL,
  `style` tinyblob,
  `position_id` bigint(20) DEFAULT NULL,
  `socialStream_id` bigint(20) DEFAULT NULL,
  `user_organisation_id` bigint(20) DEFAULT NULL,
  `worksInOrgUnit_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK142ED3DFA04529E6` (`position_id`),
  KEY `FK142ED3DFEAD5B2ED` (`user_organisation_id`),
  KEY `FK142ED3DF7CDEE209` (`worksInOrgUnit_id`),
  KEY `FKEF86282E5F3CFD323c452e58e488775142ed3df` (`originatesFrom`),
  KEY `FK142ED3DFA700DDB0` (`socialStream_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_User`
--

INSERT INTO `user_User` VALUES(23, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/9e167de6-b58e-4f00-a8c5-8d64a1af79cf', NULL, NULL, NULL, 1, NULL, NULL, 'Zoran Jeremic', NULL, 3, 912, 1, 2);
INSERT INTO `user_User` VALUES(51, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/27ae5f34-cd41-46f8-ba2c-c248b836bb12', NULL, NULL, NULL, 26, NULL, NULL, 'Bojan Tomic0', NULL, 36, 913, 26, 31);
INSERT INTO `user_User` VALUES(66, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/dcf9e6c9-9507-40c2-9f7b-5b7dd1b11e2a', NULL, NULL, NULL, 26, NULL, NULL, 'Zoran Sevarac0', NULL, 36, 914, 26, 31);
INSERT INTO `user_User` VALUES(81, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/3702d6cb-52d5-44b5-91fd-75b8da521274', NULL, NULL, NULL, 26, NULL, NULL, 'Dragan Djuric0', NULL, 36, 915, 26, 31);
INSERT INTO `user_User` VALUES(96, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/3529bb81-5700-4e30-9c5e-49b97abc0734', NULL, NULL, NULL, 26, NULL, NULL, 'Nikola Milikic0', NULL, 36, 916, 26, 31);
INSERT INTO `user_User` VALUES(111, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/b8d8a4a2-ca29-47ee-99ea-826e5b51bf6b', NULL, NULL, NULL, 26, NULL, NULL, 'Vladan Devedzic0', NULL, 34, 917, 26, 31);
INSERT INTO `user_User` VALUES(126, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/4706cbcf-24a6-4070-bef5-754456c5751c', NULL, NULL, NULL, 26, NULL, NULL, 'Jelena Jovanovic0', NULL, 36, 918, 26, 31);
INSERT INTO `user_User` VALUES(141, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/40aad7f1-3e5f-4e03-bd14-42f005afec79', NULL, NULL, NULL, 26, NULL, NULL, 'Sonja Radenkovic0', NULL, 34, 919, 26, 31);
INSERT INTO `user_User` VALUES(156, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/9b1e3b6d-20c7-4a5b-aee1-a80bed0dd6a8', NULL, NULL, NULL, 26, NULL, NULL, 'Tanja Milic0', NULL, 34, 920, 26, 31);
INSERT INTO `user_User` VALUES(171, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/057f90b0-9edb-47df-a772-50ed6d3b92d4', NULL, NULL, NULL, 26, NULL, NULL, 'Srecko Joksimovic0', NULL, 34, 921, 26, 31);
INSERT INTO `user_User` VALUES(526, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/887d8d02-9584-4cc4-bb95-c7f61a6536e8', NULL, NULL, NULL, 25, NULL, NULL, 'Nikola Damjanovic', NULL, 32, 922, 25, 29);
INSERT INTO `user_User` VALUES(541, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/3d418ad7-7560-4e21-9ee4-030f16d8bd4e', NULL, NULL, NULL, 25, NULL, NULL, 'Jelena Jovanovic', NULL, 32, 923, 25, 29);
INSERT INTO `user_User` VALUES(556, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/80fb6644-6466-4284-ade6-fd8fe8660e99', NULL, NULL, NULL, 25, NULL, NULL, 'Viktor Pocajt', NULL, 32, 924, 25, 29);
INSERT INTO `user_User` VALUES(571, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/7f52768b-04ee-45db-a93e-dc9a363e46af', NULL, NULL, NULL, 25, NULL, NULL, 'Jelena Djerkovic', NULL, 32, 925, 25, 29);
INSERT INTO `user_User` VALUES(586, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/78e4092a-8c2a-4a10-8129-5614ddcd87e7', NULL, NULL, NULL, 25, NULL, NULL, 'Mirjana Stankovic', NULL, 32, 926, 25, 29);
INSERT INTO `user_User` VALUES(601, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/225b3e03-4075-43ee-bea2-c06fad619a8b', NULL, NULL, NULL, 25, NULL, NULL, 'Jelena Jankovic', NULL, 32, 927, 25, 29);
INSERT INTO `user_User` VALUES(616, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/bd15ca08-019d-497e-bc66-a7f7d3129ad0', NULL, NULL, NULL, 25, NULL, NULL, 'Radmila Damjanovic', NULL, 32, 928, 25, 29);
INSERT INTO `user_User` VALUES(631, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/a18dddb9-4fcb-45fc-85e8-8612ec1cc868', NULL, NULL, NULL, 25, NULL, NULL, 'Aleksandra Petkovic', NULL, 32, 929, 25, 29);
INSERT INTO `user_User` VALUES(646, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/bffac3fa-fc1e-44e7-8c64-2de5b8ff1eda', NULL, NULL, NULL, 25, NULL, NULL, 'Zeljka Vragolovic', NULL, 32, 930, 25, 29);
INSERT INTO `user_User` VALUES(661, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/ea01ce83-3102-467d-b9a7-bef1928d4441', NULL, NULL, NULL, 25, NULL, NULL, 'Vladimir Markovic', NULL, 32, 931, 25, 29);
INSERT INTO `user_User` VALUES(766, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/13301bad-7d77-4d11-bc71-708be7aeb20e', NULL, NULL, NULL, 27, NULL, NULL, 'Djordje Gligorijevic', NULL, 33, 932, 27, 30);
INSERT INTO `user_User` VALUES(781, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/6a9f0c0d-b781-4a42-b0fc-f44cd4d0f8a4', NULL, NULL, NULL, 27, NULL, NULL, 'Jelena Djordjevic', NULL, 33, 933, 27, 30);
INSERT INTO `user_User` VALUES(796, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/199c517d-3632-4465-8c93-538c261430b3', NULL, NULL, NULL, 27, NULL, NULL, 'Jelena Stojanovic', NULL, 33, 934, 27, 30);
INSERT INTO `user_User` VALUES(811, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/d8ccb444-52a2-46e1-b226-b483aee26f57', NULL, NULL, NULL, 27, NULL, NULL, 'Marjan Hrdzic', NULL, 33, 935, 27, 30);
INSERT INTO `user_User` VALUES(826, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/99cf81cb-7462-4568-9e14-19d3c2bbe24d', NULL, NULL, NULL, 27, NULL, NULL, 'Vedrana Gajic', NULL, 33, 936, 27, 30);
INSERT INTO `user_User` VALUES(841, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/28af5939-36ac-4b87-8d85-1b65876b74b7', NULL, NULL, NULL, 27, NULL, NULL, 'Misa Lazovic', NULL, 33, 937, 27, 30);
INSERT INTO `user_User` VALUES(856, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/3e46205c-3718-408e-82ad-9c60fd9d876c', NULL, NULL, NULL, 27, NULL, NULL, 'Ivan Stankovic', NULL, 33, 938, 27, 30);
INSERT INTO `user_User` VALUES(871, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/5164ccc1-0a19-41f5-b07c-f135123f8308', NULL, NULL, NULL, 27, NULL, NULL, 'Dusan Milicevic', NULL, 33, 939, 27, 30);
INSERT INTO `user_User` VALUES(886, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/5aef17a2-bb20-452d-9fd0-5c671a88f335', NULL, NULL, NULL, 27, NULL, NULL, 'Milos Maksimovic', NULL, 33, 940, 27, 30);
INSERT INTO `user_User` VALUES(901, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#User/81a5610a-9958-4ed7-9bce-429aeaa78f7a', NULL, NULL, NULL, 27, NULL, NULL, 'Nina Brcic', NULL, 33, 941, 27, 30);

-- --------------------------------------------------------

--
-- Table structure for table `user_UserAccount`
--

CREATE TABLE `user_UserAccount` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `accountHolder_id` bigint(20) DEFAULT NULL,
  `accountServiceHomepage_id` bigint(20) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD324186a1adae40054e` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_UserAccount`
--

INSERT INTO `user_UserAccount` VALUES(24, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/4d040fdf-2e21-4973-a973-c52cf00a5b5b', NULL, NULL, NULL, NULL, NULL, 'Zoran.jeremic', 23, NULL, 'TH9VS4U4Z3+edctERE3pPForvgZBzoyjjTPIOhDoHSq72GSYnfJri7WjbSKadIt1');
INSERT INTO `user_UserAccount` VALUES(503, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/9db0baf5-e58c-4ece-958f-7ce1fbc83a5a', NULL, NULL, NULL, NULL, NULL, 'Bojan.tomic', 51, NULL, 'xonPMC/n9zx38JAl3dAteL2qwp9zhheSwvhZD89EUVMQKCCEdhVAWDVZgpzB4Aul');
INSERT INTO `user_UserAccount` VALUES(504, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/2ef42c8b-2244-4aef-be04-ebf44fae7b89', NULL, NULL, NULL, NULL, NULL, 'Zoran.sevarac', 66, NULL, '8aG0aJbT58skmiYdRsX/M9qW1TKE0RSF61scPhOGI/+iI7aAaTDUNEN32TNPzixJ');
INSERT INTO `user_UserAccount` VALUES(505, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/1dbfbbc9-c441-4e21-b611-d4378285293d', NULL, NULL, NULL, NULL, NULL, 'Dragan.djuric', 81, NULL, 'WGQ3wJi/Q1MeJ9m2ktevL3sVa7MxatYFfVizpwSLu3hD49vejCKPZh4EOV/qivLa');
INSERT INTO `user_UserAccount` VALUES(506, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/25546456-20ae-48c7-907e-77667ebebfce', NULL, NULL, NULL, NULL, NULL, 'Nikola.milikic', 96, NULL, '5kMtYvNjGpvbkZL4UG4C/EY6mYxzbJOKDYrUWT9ipcZ/dJsjAmVSXdCE7S+RFOmw');
INSERT INTO `user_UserAccount` VALUES(507, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/8586da5a-7e7b-4955-ae98-d2e68a3bda46', NULL, NULL, NULL, NULL, NULL, 'Vladan.devedzic', 111, NULL, 'oDHU4zH38yaIDTW3BU3TlLjWlGFBMCtBIshnonHXAfAvwdyHNeIfXP7M4eVQXtg1');
INSERT INTO `user_UserAccount` VALUES(508, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/2cd6a395-ba4b-4dfe-b8b2-241348707933', NULL, NULL, NULL, NULL, NULL, 'Jeljov', 126, NULL, 'ODIxDpmrJpXHk8+7nLGRvMnwnDbXAWPt9zHynZLHOXcOu0hfAjX1c4nU0wNBji8A');
INSERT INTO `user_UserAccount` VALUES(509, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/736ae604-b1ac-4c1e-bccb-34c01fc5c879', NULL, NULL, NULL, NULL, NULL, 'Sonja.radenkovic', 141, NULL, 'gp2/zIg0XX1185NNiidoc5lymwM4IDn2NhcMbBeSNsgT7vgXuqCQmkSW8J0gBFLT');
INSERT INTO `user_UserAccount` VALUES(510, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/094f4145-e9a6-475f-ba06-2fcac85a8114', NULL, NULL, NULL, NULL, NULL, 'Tanja.milic', 156, NULL, 'TbEKHFgCLgnim9KC5KI2ogrcpgOb9dO1e7+jLasunlPl5GZvty+MS1rJQXF1PR0g');
INSERT INTO `user_UserAccount` VALUES(511, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/59939671-669f-44f4-9f29-dabff56da052', NULL, NULL, NULL, NULL, NULL, 'Srecko.joksimovic', 171, NULL, 'b6GdxLz+DpX2ehObbB3+Y+kiBfdoy6wGQXaLR0+fHsVrqUebE1SMnR+XkWsFw3Ih');
INSERT INTO `user_UserAccount` VALUES(662, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/f1b42ea3-5f48-44b7-ab6b-addb27cd5bb7', NULL, NULL, NULL, NULL, NULL, 'Nikola.damjanovic', 526, NULL, '1SOqoS6a+EFK9i1cfHDqdOf8kudDISje+ANbZvyPW0XgkSkGZXa9xk6EOqQG02Ug');
INSERT INTO `user_UserAccount` VALUES(663, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/796efb36-188b-4fdb-94f8-8fac9a4f0c73', NULL, NULL, NULL, NULL, NULL, 'Jelena.jovanovic', 541, NULL, 'f4q1Denf7nVARPGEYHgWfhC8anKb0AguWlXIscjWOKorX5gzr4Ay4enNViCkGsvD');
INSERT INTO `user_UserAccount` VALUES(664, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/eeaf69de-aa76-4718-a704-5050f5416799', NULL, NULL, NULL, NULL, NULL, 'Viktor.pocajt', 556, NULL, 'OHFG0HWI4bXctaWgtxZUcrNWD7xxckV66GFFD0cZyYSsOqe5v0wfzh79qMVpGb+i');
INSERT INTO `user_UserAccount` VALUES(665, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/e998856b-d090-4a72-89bb-5f2395dadddd', NULL, NULL, NULL, NULL, NULL, 'Jelena.djerkovic', 571, NULL, 'oVqUzUJITl+33ZOIR07Jk0o8WrFjuWUaZucbOCXafeAg5HLbaVAuf/2bnrseDzht');
INSERT INTO `user_UserAccount` VALUES(666, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/79fec07d-1598-40c0-9261-db342987ef82', NULL, NULL, NULL, NULL, NULL, 'Mirjana.stankovic', 586, NULL, 'z1ZQYYECyTAhNxRhXHeOwznkkuxMS9c07GWAmlckveL23CmDvpaa1B7ZVQatxUir');
INSERT INTO `user_UserAccount` VALUES(667, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/ff0569c9-2f85-4f4d-a140-733d2c586a71', NULL, NULL, NULL, NULL, NULL, 'Jelena.jankovic', 601, NULL, 'g/5ywp03uPWmOTkxpBpWtx4Hcbsj482If2xUro/aNQCuhOxOdFyjc2mrS9kTAWZf');
INSERT INTO `user_UserAccount` VALUES(668, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/126bd5ec-1ef0-40b5-b561-4a11d645caf5', NULL, NULL, NULL, NULL, NULL, 'Radmila.damjanovic', 616, NULL, 'RnmVuwvS2kxIUD2JPicu+XjNJ3ZtSmYuvcwrfYTqlsDXCNUrHZxHD9/nAh6JH6Wu');
INSERT INTO `user_UserAccount` VALUES(669, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/887a9eab-14cc-467c-b526-110a4fe8464e', NULL, NULL, NULL, NULL, NULL, 'Aleksandra.petkovic', 631, NULL, 'dnFAGW3J7ekHZjgsG7O19E1+En4DYNsCzPWKg9GsMDKbB0UcCOkVDB32q/YEY3WP');
INSERT INTO `user_UserAccount` VALUES(670, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/3ddbb9af-f375-42fe-a419-d63a3afbf838', NULL, NULL, NULL, NULL, NULL, 'Zeljka.vragolovic', 646, NULL, 'j08LySaXUXr42la3O3cjBtUmjh9zTL2L5hJTykzLppY4hx0fBc6T7tr0GGCmH7a7');
INSERT INTO `user_UserAccount` VALUES(671, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/3bc91f9d-726a-4787-bdda-4bd103ea11e4', NULL, NULL, NULL, NULL, NULL, 'Vladimir.markovic', 661, NULL, 'cf5v9hOnapZentfr5vtqyyu0qagHVVhgN73mDzCtVansHJ/qt7j00zadStZsLnoK');
INSERT INTO `user_UserAccount` VALUES(902, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/96370447-3dd5-4c1b-a9d8-c90c3c0e9682', NULL, NULL, NULL, NULL, NULL, 'Djordje.gligorijevic', 766, NULL, 'acpHslTlKMjW93lBBZ4xOhJAbPG8OBhzs6uD7El+phMV0ChlfHUEs9bCcj/qKWGa');
INSERT INTO `user_UserAccount` VALUES(903, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/e2a72f57-e0de-411b-bc06-6e60e87b0657', NULL, NULL, NULL, NULL, NULL, 'Jelena.djordjevic', 781, NULL, 'NSPiC1xHCeV2VqGO9BWOgG17C1Hsep5ZXymcCWDALFz+7obY0D2V6cTOBCGrbBYF');
INSERT INTO `user_UserAccount` VALUES(904, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/45e4616f-6460-4752-b665-84f85afcba96', NULL, NULL, NULL, NULL, NULL, 'Jelena.stojanovic', 796, NULL, 'JTGWKClx4+wy4dzbUYfb5yi0yAvIcXAEL94Ieh8mOj/SuXXAOj0pto0i0KYQYLi9');
INSERT INTO `user_UserAccount` VALUES(905, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/db73cbac-0240-406f-98ee-c805ee0297bb', NULL, NULL, NULL, NULL, NULL, 'Marjan.hrdzic', 811, NULL, 'coaGapeN5O7M5EEqReEYrKDIiusQwFvaYL5bqqs48hbSHoxR21fAlRjTk8mOpA53');
INSERT INTO `user_UserAccount` VALUES(906, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/e4512928-0311-4f91-9c97-073ab6f0819b', NULL, NULL, NULL, NULL, NULL, 'Vedrana.gajic', 826, NULL, 'TkJfkHBekvEalVM+lo+ePaFnN+4A14Ib8l7jOzU2Dw4AWq5IdjGY1ZfPS78xaORd');
INSERT INTO `user_UserAccount` VALUES(907, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/63380739-a335-48d2-9cd1-6af34900c7f9', NULL, NULL, NULL, NULL, NULL, 'Misa.lazovic', 841, NULL, '0et6X0uURFkAicitxN2GoS+qqT0sl0DM+Ldxfpt8r9Er2IZvZljdGAmJ3o7He4H5');
INSERT INTO `user_UserAccount` VALUES(908, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/77805d8e-d9b0-4c9b-9041-44541525c8d8', NULL, NULL, NULL, NULL, NULL, 'Ivan.stankovic', 856, NULL, 'WfaTfCJ6uZOcnI6S2xw0Vo3u9OhagcRjIXa3HqF91i1IM3vFkoY228FP764fzHU5');
INSERT INTO `user_UserAccount` VALUES(909, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/c628f821-0a1f-47a9-89ea-0262462665e3', NULL, NULL, NULL, NULL, NULL, 'Dusan.milicevic', 871, NULL, 'y5giwK390Bi8Kk2uqTrFH7AJ+77v9Rram+Pbat894MzXH8cYu5tMjLzK2lkaQkL7');
INSERT INTO `user_UserAccount` VALUES(910, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/09daeac8-0b42-41d7-8cce-11d4c2ab0267', NULL, NULL, NULL, NULL, NULL, 'Milos.maksimovic', 886, NULL, '/IkQwjT/LYGM1LSQw0799uKzFQVBivaflppoWGOkG8uJJmuoQtftKls+2guULn6u');
INSERT INTO `user_UserAccount` VALUES(911, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserAccount/ea84ca8c-6745-4c9a-9674-a4c4d5e97356', NULL, NULL, NULL, NULL, NULL, 'Nina.brcic', 901, NULL, 'LxibbM4wC+cUdKV71bPhiL6STTmXhtl0n7nUgBoB7Kdxx/6Z0PR7vH2XH2Lx8tTq');

-- --------------------------------------------------------

--
-- Table structure for table `user_UserDefinedPriority`
--

CREATE TABLE `user_UserDefinedPriority` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `priorityLevel` double DEFAULT NULL,
  `priorityScale_id` bigint(20) DEFAULT NULL,
  `priorityType_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK3137ECEEF7FF3E3` (`priorityScale_id`),
  KEY `FK3137ECEE8DB5BC10` (`priorityType_id`),
  KEY `FKEF86282E5F3CFD323137ecee` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_UserDefinedPriority`
--

INSERT INTO `user_UserDefinedPriority` VALUES(7, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/fc5b5d41-e3dd-4aa2-b80f-ff19430a2f3a', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(9, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/43208416-e90a-40c0-bb48-8bf46fa1e267', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(11, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a67b4ff4-0a13-47df-9770-57531f555611', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(13, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/78ed1da8-3e0d-439e-8e3d-5f8c452a62ff', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(38, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/057523fe-b6e8-48b3-b813-387cd4e9aa6a', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(39, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/9f39b588-b1a1-45f9-aeca-23043d636a17', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(40, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/5c05e94e-a8c2-436a-a086-ee42896103d4', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(41, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/853e0f6c-6bef-4867-9454-b8dcf0355c22', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(53, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/11ade243-f097-4514-9b35-c0018ef96e9c', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(54, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/50be1906-940f-4454-8e06-c1e927bb2fce', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(55, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/bbac1b4b-d75b-4842-8431-7711f25a8137', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(56, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/fcaec515-9300-4b7f-9ae8-c578371c0ea3', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(68, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/103a9768-9d29-4037-b037-15278544c5a8', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(69, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/92bc2c44-dc9a-4cd7-82eb-e0f33faeab5c', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(70, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/92f13b8d-f0c2-449b-9c07-71c9b7732b30', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(71, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/4a313473-87ce-4ca5-8bae-6c4ededcc84a', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(83, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/44e96820-b7bc-447e-abc5-bfef87251181', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(84, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/bece97c0-254e-486b-afe9-c52810ac56d7', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(85, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/e9344d21-3905-4695-9553-05b1ed1faac8', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(86, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/b20ac52d-9dd4-433b-b6a6-e05b73d01069', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(98, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/c8acf56f-6684-42d4-b7a3-57c7c9de8668', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(99, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/92a28ea4-4457-4c40-b751-8dd9a4b39881', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(100, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/25a813de-3fc8-401b-81e1-20a364bbe075', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(101, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/4460766a-4df7-43ad-b74f-c7d789282a8d', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(113, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/2784e0cc-eacf-4a8a-a0bf-4c5b77e29ce4', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(114, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/6afd201f-4a6d-4e9d-81f0-934dc22d2f2d', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(115, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/15aac8dc-a9c7-49ec-bfb7-3ee042dd3138', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(116, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0f9b65bc-abb3-4773-a816-ac6beebcd2db', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(128, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/70a3e630-83cb-4475-9d63-4e54e2745a4f', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(129, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f1c4d166-600c-4a5e-8f4b-44ecef76e52b', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(130, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/21ecee94-4935-4d7e-af0a-d34febc12142', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(131, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/ab7a6d61-a3b1-454a-a0a6-11b7026ad070', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(143, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/e3f2a0d4-1e01-449a-9b00-5b17f2c96fa9', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(144, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/b6d91a6d-0c9f-439c-9e2b-04babea87d4c', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(145, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0f4c8b8f-9d84-41f7-beaa-2b592b8bd8ce', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(146, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/5b5027de-77ff-4912-bcee-97bd65f5bacf', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(158, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/63911784-71ce-49d9-89f5-74b79548d2d1', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(159, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/474ee594-fd8b-44dc-add9-28b2b278a37e', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(160, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a24e498f-ec93-4d7a-b627-2b55653f0e12', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(161, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/12d0d11f-d5f8-4d2d-991d-ad23a99e9008', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(513, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f9a147a0-7578-43ab-963b-e7c7cfc486f2', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(514, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8fa6a70c-c213-43e8-8a0b-a9e5f9de2588', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(515, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/4c6f2fd3-f45e-422c-8431-85024b947f43', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(516, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/63057a6c-f2f0-4ca9-81b5-c3f485636923', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(528, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/aef07c91-ae4d-4e87-811a-868d7745e31c', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(529, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/94fc52ce-8761-46d2-bfd7-9b51c9c4c00b', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(530, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/ab30f310-4772-4c93-9e05-f2a9be7aaac4', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(531, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/88848bc9-3484-4ace-a6b7-a8c7cce25345', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(543, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/9386f8a7-23f2-4ea9-b91c-77f2e4b3a946', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(544, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/3c32f909-195c-4d68-a272-0b8cb28c205c', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(545, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/71f0650b-7b2d-4a0a-b790-f188d14bad90', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(546, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/833cdb28-ad6a-4d3e-b8af-4a46de725e51', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(558, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a6829431-f83b-405e-854e-f1314f5b86f6', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(559, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/eac7d871-4c3e-4dad-9524-dd907972b931', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(560, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8f5b5569-2f91-417b-b25a-802c4b8cbd32', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(561, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/48d6a492-db66-4634-b0ec-c702132f0e4b', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(573, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/92ef59aa-44f0-4040-b45c-ac68f1892a8b', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(574, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/6736f354-3de1-4162-b8d5-6626403a167a', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(575, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a706de6f-d1a5-4f7b-bf87-ebb3130ddb6f', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(576, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0356f99f-c1f2-4492-8198-9d7acf8553bf', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(588, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/56d466e0-3f60-48f9-a8c4-7d6e2d521e9f', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(589, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/283a5542-07c9-4012-8b28-523476f11660', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(590, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f3599fe5-4949-44d2-82a1-366e5e844c5f', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(591, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f9c2d3b3-8493-4f43-86ff-421d00d4a63f', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(603, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/3f7e729b-64d0-480b-94be-d66d9092e1ec', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(604, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f6699807-8e0c-4ab7-a2d3-cbb3652fd9f1', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(605, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/57ed6e7d-ffb6-49f9-9183-34f36f43fa0e', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(606, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/3db61165-9bb7-4b40-8b75-315f7fcc8647', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(618, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8d661935-e214-4467-a82d-2f7b12469ed6', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(619, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/28fdb516-8b3e-4dd3-800e-624c2b30d9de', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(620, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a26e7b8f-01ab-425d-aad4-31ff822453b3', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(621, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f1d6e1bb-7382-48ff-b113-3e04cef22f61', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(633, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/5f44da6f-489c-46c1-bf71-44813fbc1053', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(634, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0468983f-8fa4-48b0-b998-7b45f93fe4ca', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(635, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/b0423796-326f-4b84-b782-dbb5e7469a82', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(636, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a63145e4-1d06-49c2-a878-39e3f0c15f58', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(648, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/738e1845-55e2-463c-b456-2031ae926dc0', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(649, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a84e5765-10ff-43cc-85fa-8b0d97afa793', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(650, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/5cc02a24-6ab7-4d86-b1f8-7ee624e3914d', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(651, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/c3d63920-e5d4-4b22-ac85-a8f436ccbb93', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(753, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/1ec728d2-d728-4034-a35b-1442ac66a6b6', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(754, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/06bde4e1-941d-4369-aa10-4cdaa8d292c6', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(755, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/d5f8293b-5e89-41b4-ba4b-85b626c214ce', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(756, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/dcd8b68b-969b-494a-aa92-a45987cfd569', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(768, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/6e250598-0d6c-4028-9445-6f902f911fb9', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(769, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/2832e4b5-2131-4498-9bdd-e1d9a91bc582', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(770, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0e8aaa4f-d4b3-4fe6-b3ab-af78cd6f5700', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(771, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/bef357e5-9835-4241-aac1-c66f8bb2fdac', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(783, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8575cdd1-86a2-4dc8-b0fc-0cbc80de45bf', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(784, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/0449dd93-ba04-4005-9478-9d9fbf8ddde2', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(785, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/889fe7fc-11bf-49af-89b4-6e3c1971586f', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(786, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/d6d2e018-2505-4dc1-a69c-a5554701bdbd', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(798, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/81592e97-90b0-42e1-b306-8a70e17cfbfe', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(799, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/4adbb59b-efd8-4ebc-8675-334f9e904369', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(800, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/26bed9e0-3d92-41c3-9e5a-1a0f0ec55624', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(801, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/9f4f7d04-f703-4761-ae7f-f68bdf25231b', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(813, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/42c8b3cc-8741-4377-9905-31035a141565', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(814, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a0469281-fcd9-4d26-aae9-6361bc4ac830', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(815, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/ff889e57-a54e-449d-9645-7b3f7cedec5e', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(816, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/bda20519-e50f-4be6-8f36-92b4627390c2', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(828, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/d802e82b-e01c-4274-a48f-d267e60630ab', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(829, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/354a1f8d-3c93-4a6e-8505-92ea1b9f7bde', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(830, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/a8a3a03e-4d6d-4f33-9ee2-c11caf0ff986', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(831, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/ffda1cbc-b90d-411e-a6bf-aa1417e24021', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(843, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/7f772b05-3365-47c5-9ed9-5422386a42e7', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(844, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8446f8c8-2860-494a-b185-728d30ec7de1', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(845, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/c216a717-e928-40c6-90ef-475a2f56c39b', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(846, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/9c67ace1-0ad8-4720-9093-3184e432f2ca', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(858, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/b04ab66a-c314-45b3-a439-5b898448101b', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(859, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/d82453b1-e12e-4d6a-a7bc-425f7047c2c8', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(860, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/b13fb18a-a9c7-4b02-9c14-4b7ba35932b4', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(861, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/f2bd54cd-564f-42f6-aaa5-f6da0e291700', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(873, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/06f4005f-621d-4966-971e-8b29bb8d9c3f', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(874, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/3b5d40ff-6f5d-4418-96a6-3799d5d39ed2', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(875, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/9cc57919-a75d-4d79-94e5-c038753e0772', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(876, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/3e4f6b67-af26-4c92-a18c-51814dddb5a6', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);
INSERT INTO `user_UserDefinedPriority` VALUES(888, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/80a3934e-d76c-4fb1-a6b6-0810f29dd945', NULL, NULL, NULL, NULL, NULL, 1, 6, 5);
INSERT INTO `user_UserDefinedPriority` VALUES(889, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/8af425de-d448-4320-9f96-7514a3aa7676', NULL, NULL, NULL, NULL, NULL, 1, 6, 8);
INSERT INTO `user_UserDefinedPriority` VALUES(890, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/349b8a39-0ae9-4cd8-97e4-3a5ee1ee06dd', NULL, NULL, NULL, NULL, NULL, 1, 6, 10);
INSERT INTO `user_UserDefinedPriority` VALUES(891, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserDefinedPriority/d6a60fa7-88b8-4f41-b8a3-52100ee0f42f', NULL, NULL, NULL, NULL, NULL, 1, 6, 12);

-- --------------------------------------------------------

--
-- Table structure for table `user_UserProgress`
--

CREATE TABLE `user_UserProgress` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `userProgressLevel` double DEFAULT NULL,
  `progressScale_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK5D77AB2CBBE1D2B8` (`progressScale_id`),
  KEY `FKEF86282E5F3CFD325d77ab2c` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_UserProgress`
--

INSERT INTO `user_UserProgress` VALUES(436, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/4c9337ca-f0f2-4b98-a64e-c7f719d49982', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `user_UserProgress` VALUES(965, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/24c33122-7576-428f-84b3-98dd8536fbf8', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `user_UserProgress` VALUES(986, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/48e0d32b-286f-47ad-9c67-6f9863bda742', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `user_UserProgress` VALUES(993, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/367b0183-4560-4938-963c-fb5474a46bc4', NULL, NULL, NULL, NULL, NULL, 60, 992);
INSERT INTO `user_UserProgress` VALUES(1014, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/943eec27-9dbb-47d6-a2d1-cf7af301c1ab', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `user_UserProgress` VALUES(1020, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/1dc95d4b-ecde-4cf1-b6d7-31f19af02084', NULL, NULL, NULL, NULL, NULL, 40, 992);
INSERT INTO `user_UserProgress` VALUES(1041, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/23f7e030-9c6c-4d93-9235-69b61eb7def3', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `user_UserProgress` VALUES(1046, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/d6370378-0e5d-498f-9426-10e85d24171b', NULL, NULL, NULL, NULL, NULL, 100, 992);
INSERT INTO `user_UserProgress` VALUES(1067, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#UserProgress/7ad7a5ef-5c06-4d82-b462-99b7fd2c7118', NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_User_CompetenceRecord`
--

CREATE TABLE `user_User_CompetenceRecord` (
  `user_User_id` bigint(20) NOT NULL,
  `competenceRecords_id` bigint(20) NOT NULL,
  UNIQUE KEY `competenceRecords_id` (`competenceRecords_id`),
  KEY `FK2CCE61FAAC9ACE8C` (`competenceRecords_id`),
  KEY `FK2CCE61FA146C725C` (`user_User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_User_CompetenceRecord`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_User_Document`
--

CREATE TABLE `user_User_Document` (
  `user_User_id` bigint(20) NOT NULL,
  `homepages_id` bigint(20) NOT NULL,
  UNIQUE KEY `homepages_id` (`homepages_id`),
  KEY `FK50647D9B8ADC38E3` (`homepages_id`),
  KEY `FK50647D9B146C725C` (`user_User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_User_Document`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_User_user_FollowedEntity`
--

CREATE TABLE `user_User_user_FollowedEntity` (
  `user_User_id` bigint(20) NOT NULL,
  `followedEntities_id` bigint(20) NOT NULL,
  UNIQUE KEY `followedEntities_id` (`followedEntities_id`),
  KEY `FK52F33EC7146C725C` (`user_User_id`),
  KEY `FK52F33EC7152F25D2` (`followedEntities_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_User_user_FollowedEntity`
--


-- --------------------------------------------------------

--
-- Table structure for table `user_User_user_UserPreferences`
--

CREATE TABLE `user_User_user_UserPreferences` (
  `user_User_id` bigint(20) NOT NULL,
  `preferences_id` bigint(20) NOT NULL,
  UNIQUE KEY `preferences_id` (`preferences_id`),
  KEY `FK24C699F9146C725C` (`user_User_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user_User_user_UserPreferences`
--

INSERT INTO `user_User_user_UserPreferences` VALUES(23, 464);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 463);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 469);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 468);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 473);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 472);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 477);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 476);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 481);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 480);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 485);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 484);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 489);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 488);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 493);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 492);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 497);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 496);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 501);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 500);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 466);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 173);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 172);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 22);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 14);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 470);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 50);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 42);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 474);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 65);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 57);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 478);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 80);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 72);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 482);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 95);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 87);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 486);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 110);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 102);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 490);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 125);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 117);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 494);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 140);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 132);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 498);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 155);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 147);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 502);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 170);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 162);
INSERT INTO `user_User_user_UserPreferences` VALUES(526, 525);
INSERT INTO `user_User_user_UserPreferences` VALUES(526, 517);
INSERT INTO `user_User_user_UserPreferences` VALUES(541, 540);
INSERT INTO `user_User_user_UserPreferences` VALUES(541, 532);
INSERT INTO `user_User_user_UserPreferences` VALUES(556, 555);
INSERT INTO `user_User_user_UserPreferences` VALUES(556, 547);
INSERT INTO `user_User_user_UserPreferences` VALUES(571, 570);
INSERT INTO `user_User_user_UserPreferences` VALUES(571, 562);
INSERT INTO `user_User_user_UserPreferences` VALUES(586, 585);
INSERT INTO `user_User_user_UserPreferences` VALUES(586, 577);
INSERT INTO `user_User_user_UserPreferences` VALUES(601, 600);
INSERT INTO `user_User_user_UserPreferences` VALUES(601, 592);
INSERT INTO `user_User_user_UserPreferences` VALUES(616, 615);
INSERT INTO `user_User_user_UserPreferences` VALUES(616, 607);
INSERT INTO `user_User_user_UserPreferences` VALUES(631, 630);
INSERT INTO `user_User_user_UserPreferences` VALUES(631, 622);
INSERT INTO `user_User_user_UserPreferences` VALUES(646, 645);
INSERT INTO `user_User_user_UserPreferences` VALUES(646, 637);
INSERT INTO `user_User_user_UserPreferences` VALUES(661, 660);
INSERT INTO `user_User_user_UserPreferences` VALUES(661, 652);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 675);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 673);
INSERT INTO `user_User_user_UserPreferences` VALUES(23, 674);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 679);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 677);
INSERT INTO `user_User_user_UserPreferences` VALUES(51, 678);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 683);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 681);
INSERT INTO `user_User_user_UserPreferences` VALUES(66, 682);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 687);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 685);
INSERT INTO `user_User_user_UserPreferences` VALUES(81, 686);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 691);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 689);
INSERT INTO `user_User_user_UserPreferences` VALUES(96, 690);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 695);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 693);
INSERT INTO `user_User_user_UserPreferences` VALUES(111, 694);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 699);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 697);
INSERT INTO `user_User_user_UserPreferences` VALUES(126, 698);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 703);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 701);
INSERT INTO `user_User_user_UserPreferences` VALUES(141, 702);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 707);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 705);
INSERT INTO `user_User_user_UserPreferences` VALUES(156, 706);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 711);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 709);
INSERT INTO `user_User_user_UserPreferences` VALUES(171, 710);
INSERT INTO `user_User_user_UserPreferences` VALUES(526, 715);
INSERT INTO `user_User_user_UserPreferences` VALUES(526, 713);
INSERT INTO `user_User_user_UserPreferences` VALUES(526, 714);
INSERT INTO `user_User_user_UserPreferences` VALUES(541, 719);
INSERT INTO `user_User_user_UserPreferences` VALUES(541, 717);
INSERT INTO `user_User_user_UserPreferences` VALUES(541, 718);
INSERT INTO `user_User_user_UserPreferences` VALUES(556, 723);
INSERT INTO `user_User_user_UserPreferences` VALUES(556, 721);
INSERT INTO `user_User_user_UserPreferences` VALUES(556, 722);
INSERT INTO `user_User_user_UserPreferences` VALUES(571, 727);
INSERT INTO `user_User_user_UserPreferences` VALUES(571, 725);
INSERT INTO `user_User_user_UserPreferences` VALUES(571, 726);
INSERT INTO `user_User_user_UserPreferences` VALUES(586, 731);
INSERT INTO `user_User_user_UserPreferences` VALUES(586, 729);
INSERT INTO `user_User_user_UserPreferences` VALUES(586, 730);
INSERT INTO `user_User_user_UserPreferences` VALUES(601, 735);
INSERT INTO `user_User_user_UserPreferences` VALUES(601, 733);
INSERT INTO `user_User_user_UserPreferences` VALUES(601, 734);
INSERT INTO `user_User_user_UserPreferences` VALUES(616, 739);
INSERT INTO `user_User_user_UserPreferences` VALUES(616, 737);
INSERT INTO `user_User_user_UserPreferences` VALUES(616, 738);
INSERT INTO `user_User_user_UserPreferences` VALUES(631, 743);
INSERT INTO `user_User_user_UserPreferences` VALUES(631, 741);
INSERT INTO `user_User_user_UserPreferences` VALUES(631, 742);
INSERT INTO `user_User_user_UserPreferences` VALUES(646, 747);
INSERT INTO `user_User_user_UserPreferences` VALUES(646, 745);
INSERT INTO `user_User_user_UserPreferences` VALUES(646, 746);
INSERT INTO `user_User_user_UserPreferences` VALUES(661, 751);
INSERT INTO `user_User_user_UserPreferences` VALUES(661, 749);
INSERT INTO `user_User_user_UserPreferences` VALUES(661, 750);
INSERT INTO `user_User_user_UserPreferences` VALUES(766, 757);
INSERT INTO `user_User_user_UserPreferences` VALUES(766, 765);
INSERT INTO `user_User_user_UserPreferences` VALUES(781, 772);
INSERT INTO `user_User_user_UserPreferences` VALUES(781, 780);
INSERT INTO `user_User_user_UserPreferences` VALUES(796, 787);
INSERT INTO `user_User_user_UserPreferences` VALUES(796, 795);
INSERT INTO `user_User_user_UserPreferences` VALUES(811, 802);
INSERT INTO `user_User_user_UserPreferences` VALUES(811, 810);
INSERT INTO `user_User_user_UserPreferences` VALUES(826, 817);
INSERT INTO `user_User_user_UserPreferences` VALUES(826, 825);
INSERT INTO `user_User_user_UserPreferences` VALUES(841, 832);
INSERT INTO `user_User_user_UserPreferences` VALUES(841, 840);
INSERT INTO `user_User_user_UserPreferences` VALUES(856, 847);
INSERT INTO `user_User_user_UserPreferences` VALUES(856, 855);
INSERT INTO `user_User_user_UserPreferences` VALUES(871, 862);
INSERT INTO `user_User_user_UserPreferences` VALUES(871, 870);
INSERT INTO `user_User_user_UserPreferences` VALUES(886, 877);
INSERT INTO `user_User_user_UserPreferences` VALUES(886, 885);
INSERT INTO `user_User_user_UserPreferences` VALUES(901, 892);
INSERT INTO `user_User_user_UserPreferences` VALUES(901, 900);

-- --------------------------------------------------------

--
-- Table structure for table `workflowPrerequisite`
--

CREATE TABLE `workflowPrerequisite` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `competence_id` bigint(20) DEFAULT NULL,
  `competenceLevel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEFBCE8155D191D49` (`competenceLevel_id`),
  KEY `FKEF86282E5F3CFD32efbce815` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflowPrerequisite`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_DetailedProgressStatus`
--

CREATE TABLE `workflow_DetailedProgressStatus` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `progressLevel` double DEFAULT NULL,
  `progressScale_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK55C501EFBBE1D2B8` (`progressScale_id`),
  KEY `FKEF86282E5F3CFD329d49751f55c501ef` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_DetailedProgressStatus`
--

INSERT INTO `workflow_DetailedProgressStatus` VALUES(199, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/e5c85f2e-22d4-4174-8940-fe8f8a132067', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(201, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/f4bdbe68-b542-4005-af1e-01bfa2277559', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(202, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/148338ba-c3d1-46f3-8f8a-513a7fffb81b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(204, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/af0f90ef-6ce4-40c9-a154-db40fb44a89d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(222, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/a38e55a5-9fbd-4593-91f9-c609e62e56a1', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(224, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5e2e73a3-5068-4713-a601-c04ef4b2235b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(226, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/e066bcc1-2097-48b6-8533-0526e0d23276', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(229, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/2ef478cf-b4bb-4d8c-bfe5-7c3ae5c2d0bc', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(230, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/f1762f4b-bb93-4a95-b6a6-e5536524138d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(232, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/e59825ef-bcd9-42b8-bb05-c4866cfa88b2', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(257, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/1eee10d7-c635-4255-b0f0-7aa84dd34652', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(259, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/fbe7f62c-8161-4e6b-9bf4-5c0ea2831c84', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(261, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5ec10fac-fd65-4817-895b-4f4c00d2ddc4', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(264, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/9ead5537-c632-4005-b94c-5db39df6afde', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(265, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/b5711def-805e-45c7-9d2f-4f63232bcdc5', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(267, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/ced75085-018b-4b62-a192-ce1d33c5b68d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(276, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/a4d94717-8b85-48ae-b9b9-24640d2dd11a', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(278, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/c43324c0-7192-4170-9f55-1723f51a833b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(280, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/1f474ee4-01df-4f42-839a-d913bd069353', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(283, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/7a0211da-ee72-4790-8ecd-348117697c5b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(284, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/cf8faf71-3a9e-4242-8643-c1d84f6384bf', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(286, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/0001076c-e7ef-4551-967d-1a642da0a984', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(301, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/6edd7087-6646-44a1-96e7-489499a91bec', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(303, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5f25bde1-dab9-431d-9be3-d8ff12d768a3', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(305, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/608427f3-9c8f-4cb8-8d2b-0f66b9ee9c44', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(308, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/58d649de-77b4-4c17-8c0e-44ecc82a2524', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(309, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/d1797e6c-0cab-4b6b-98a4-e2e3267a7d05', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(311, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/4d0c328a-1037-4376-9fc2-5ff46f336282', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(320, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/a68a9fd1-436b-4bd6-baa7-712a0081a58d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(322, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/b6b1d969-7d2f-40de-a6d3-7ee83dc076ee', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(324, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/fe1a6640-d733-4176-8db7-2315c07139ac', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(327, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/144defca-9878-4fe3-b662-12a335e474cf', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(328, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/0aa8677a-b28c-4b68-8a9b-fe5df020cd05', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(330, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5176bdd6-a4a2-4379-873b-3ae527662b70', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(421, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/f25b37a0-39dd-4dd6-aae1-1ec29dcb9b35', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(423, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/86f3424a-e85d-4fe1-bdb8-161a4d1abb7b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(424, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/66026033-0c9a-4471-9537-fd305afde406', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(426, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/cac0b87c-00ef-4c62-9412-3238d3db9cd9', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(967, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/13dd0ba8-ccf4-4ad6-be6c-f672d0fc55ff', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(969, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/59580e0e-2a97-451d-8d28-88ebfe575f98', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(971, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/d026bcc0-89ab-4904-a688-19ce592cf6dd', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(974, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/915731f5-9677-441c-b063-4fd8ecc9891a', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(975, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/3f24a123-9ac1-4da6-ae84-300ca021c83a', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(977, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/6fc46211-1117-4ba1-8999-62c1fa3188c9', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(995, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/1041297e-014b-40c3-a714-6c9b9b88c8f6', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(997, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/c5204c13-ca6f-42f7-a932-4951d1e2adb7', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(999, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/123e30ab-65b9-4489-9214-7be51b63eed0', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1002, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5905fb29-7c2e-40ee-92a0-5177e8f3962b', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1003, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/5926d8a5-8996-49f4-bcf6-d71fed4f86d0', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1005, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/401526c4-07a8-4a21-ba83-c591802e3b8d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1022, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/672d848e-36ea-4843-a6dd-16b90b847ec2', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1024, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/f1a76f1a-5a3d-4d20-9ee9-95cf58e8bafd', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1026, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/fa1e9389-75b0-4542-83f2-1eb1f2b65b58', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1029, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/66a18de2-8a58-4728-8e00-4ecf5c189b6d', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1030, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/4fd384f4-6d65-468a-9a90-3369fd1ef69c', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1032, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/feac806d-4247-4137-8f6a-95810ecc6245', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1048, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/a9fa73dd-bcdf-4741-a5d2-eca7cb54128e', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1050, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/6fd732e8-df8b-41f6-b983-110048562045', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1052, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/4cdace48-b0ac-4916-9500-4ffc9f3fec36', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1055, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/fc4e4b0b-1231-409c-8b96-5d1b1d91b077', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1056, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/cc9957b4-4cc5-41eb-b8f9-978ac0e8f23e', NULL, NULL, NULL, NULL, NULL, 0, NULL);
INSERT INTO `workflow_DetailedProgressStatus` VALUES(1058, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#DetailedProgressStatus/9160a70d-1969-476d-a5ec-66d82e107b50', NULL, NULL, NULL, NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_Duration`
--

CREATE TABLE `workflow_Duration` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `durationMetric` varchar(255) DEFAULT NULL,
  `durationValue` double NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32af955234` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Duration`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_Feedback`
--

CREATE TABLE `workflow_Feedback` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD321ae6f025` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Feedback`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_KnowledgeAsset`
--

CREATE TABLE `workflow_KnowledgeAsset` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `activity_id` bigint(20) DEFAULT NULL,
  `referenceToContent_id` bigint(20) DEFAULT NULL,
  `referenceToPerson_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32996f3db2` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_KnowledgeAsset`
--

INSERT INTO `workflow_KnowledgeAsset` VALUES(182, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/f9a7fa7e-3ae5-4aa1-a95b-ea2c90e3eda8', NULL, NULL, NULL, NULL, 181, 184, 180, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(215, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software engineering for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/23269e40-076b-473b-a8bd-f76cab7f0a20', NULL, NULL, NULL, NULL, 214, 217, 213, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(250, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software high-level design0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/f8a106af-93cb-4b68-955b-a06d256bc133', NULL, NULL, NULL, NULL, 249, 252, 248, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(349, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: A short Tutorial on Semantic Web0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/dc9779b4-3d20-40ba-b2c3-024953716e85', NULL, NULL, NULL, NULL, 348, NULL, 347, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(354, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Semantic Web - Introduction and Overview0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/37f1d9e0-9ca6-44ae-87e3-4c3b4ac4c5eb', NULL, NULL, NULL, NULL, 353, 356, 352, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(361, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: An Introduction to OWL0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/2a578790-7d99-409d-a904-347af95bba32', NULL, NULL, NULL, NULL, 360, NULL, 359, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(365, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'W3C OWL Primer0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/a9156502-701f-4253-b10c-d46dfffb54b1', NULL, NULL, NULL, NULL, 364, 367, 363, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(370, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OWL Reasoning Examples and Hands-On Session0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/16a49540-0beb-4479-83dc-4573738484b3', NULL, NULL, NULL, NULL, NULL, 372, 369, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(378, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: An Introduction to Linked Data0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/6b20e7d9-691e-4023-8bd3-db6f8604be03', NULL, NULL, NULL, NULL, 377, 385, 376, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(383, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Slides: Hello Open Data World0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/59ccacb2-9550-46a9-bec6-26b1c952c70c', NULL, NULL, NULL, NULL, 382, 385, 381, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(391, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: Learning from the Masters: Understanding Ontologies found on the Web 0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/b114d037-6c57-4798-a30c-0666af69729e', NULL, NULL, NULL, NULL, NULL, 393, 390, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(399, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Linked Data in Plain English0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/a381fd17-0639-4c87-bbd9-d2b19cdd7598', NULL, NULL, NULL, NULL, 398, 401, 397, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(405, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: OWL0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/aaa5abb1-e0c0-4f87-b219-d1ce862c5c63', NULL, NULL, NULL, NULL, 404, 407, 403, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(411, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Video: Ontology Engineering Methodologies0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/8de415f1-a8cc-47a3-9b40-9b75ccd704ab', NULL, NULL, NULL, NULL, 410, 413, 409, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(416, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OWL-related discussions on semanticoveflow.com 0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/d11f0657-ab35-422b-a5d0-68cedc44a1b8', NULL, NULL, NULL, NULL, NULL, 418, 415, NULL);
INSERT INTO `workflow_KnowledgeAsset` VALUES(448, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Protege OWL tutorial0', 'http://intelleo.org/triplestore/bc_x#KnowledgeAsset/75eb9260-5e3a-48e8-9dd0-3423dd567d0f', NULL, NULL, NULL, NULL, 447, 451, 446, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_LearningObjective`
--

CREATE TABLE `workflow_LearningObjective` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `targetCompetence_id` bigint(20) DEFAULT NULL,
  `targetCompetenceLevel_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKE63B371B37BEAC9A` (`targetCompetenceLevel_id`),
  KEY `FKEF86282E5F3CFD32e63b371b` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_LearningObjective`
--

INSERT INTO `workflow_LearningObjective` VALUES(194, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#LearningObjective/d65c190b-e0bc-4de8-bf8b-c5b375d37ad3', NULL, NULL, NULL, NULL, 193, 190, NULL);
INSERT INTO `workflow_LearningObjective` VALUES(246, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#LearningObjective/c86e56c1-97fc-4811-a83f-c2a125600b0c', NULL, NULL, NULL, NULL, 245, 242, NULL);
INSERT INTO `workflow_LearningObjective` VALUES(344, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#LearningObjective/b2a15967-6aac-4113-b12f-2198cbebc075', NULL, NULL, NULL, NULL, 343, 340, NULL);
INSERT INTO `workflow_LearningObjective` VALUES(444, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://intelleo.org/triplestore/bc_x#LearningObjective/54d82a18-ca9a-4c54-8dcf-e8e03407a76e', NULL, NULL, NULL, NULL, 443, 440, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_LearningTask`
--

CREATE TABLE `workflow_LearningTask` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `dateFinished` datetime DEFAULT NULL,
  `dateStarted` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `leader_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `responsiblePerson_id` bigint(20) DEFAULT NULL,
  `definedBy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK44028A2569D10D2812f1263` (`leader_id`),
  KEY `FK44028A25AF9CB4D0812f1263` (`responsiblePerson_id`),
  KEY `FK44028A25D7DE8A84812f1263` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD3244028a25812f1263` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_LearningTask`
--

INSERT INTO `workflow_LearningTask` VALUES(188, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to Model Things0', 'http://intelleo.org/triplestore/bc_x#LearningTask/dc6f9d44-da1c-4c72-9534-1ec9c8816c94', NULL, 23, NULL, NULL, 187, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(198, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to Model software0', 'http://intelleo.org/triplestore/bc_x#LearningTask/355c67ef-e758-4606-830b-7d68904c9007', NULL, 111, NULL, NULL, 197, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(221, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to Model software system0', 'http://intelleo.org/triplestore/bc_x#LearningTask/ebeb2d5d-ba2b-45ea-83d1-1853b2fc632e', NULL, 96, NULL, NULL, 220, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(256, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to interpret software requirements0', 'http://intelleo.org/triplestore/bc_x#LearningTask/c09375ee-9279-4090-a48b-9475862dd73a', NULL, 51, NULL, NULL, 255, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(300, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to model user requirements0', 'http://intelleo.org/triplestore/bc_x#LearningTask/23c4a8fa-b220-4247-8f3f-02194d80a86f', NULL, 23, NULL, NULL, 299, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(374, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'OWL for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#LearningTask/dbf2c51b-9909-426d-9786-a054da219612', NULL, 141, NULL, 25, 373, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(395, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Learning OWL in Linked Data Way0', 'http://intelleo.org/triplestore/bc_x#LearningTask/0ca983d0-dc91-442d-8f06-e44ec2898ff7', NULL, 111, NULL, 26, 394, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(420, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'My Path Towards OWL Mastery0', 'http://intelleo.org/triplestore/bc_x#LearningTask/b21c472d-125a-49a5-bf3d-28ead58a8f27', NULL, 126, NULL, 26, 419, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
INSERT INTO `workflow_LearningTask` VALUES(458, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Best Practice: Stanford Guide to Protege and OWL0', 'http://intelleo.org/triplestore/bc_x#LearningTask/cff5a719-d97a-47ac-9576-00faf864ced9', NULL, 81, NULL, NULL, 457, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_ProgressScale`
--

CREATE TABLE `workflow_ProgressScale` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `maxValue` double DEFAULT NULL,
  `minValue` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD3236978a7d` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_ProgressScale`
--

INSERT INTO `workflow_ProgressScale` VALUES(992, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'http://www.intelleo.eu/ontologies/workflow/ns/ProgressScale0To100', NULL, NULL, NULL, NULL, NULL, 100, 0);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_ProgressStatus`
--

CREATE TABLE `workflow_ProgressStatus` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD329d49751f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_ProgressStatus`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_ReusedActivity`
--

CREATE TABLE `workflow_ReusedActivity` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `datetimeend` datetime DEFAULT NULL,
  `dateTimeStart` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `occurring_id` bigint(20) DEFAULT NULL,
  `basedOn_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKA126572FD7DE8A8410a09c3f` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD32a126572f10a09c3f` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_ReusedActivity`
--

INSERT INTO `workflow_ReusedActivity` VALUES(203, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/aa19e9f4-236a-47c2-b410-339b1ad7c59c', NULL, 126, NULL, NULL, 208, NULL, NULL, 202, NULL, NULL, 196);
INSERT INTO `workflow_ReusedActivity` VALUES(227, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Software engineering0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/0c45feed-502f-43d0-a0ce-ff3360695862', NULL, 81, NULL, NULL, 236, NULL, NULL, 226, NULL, NULL, 217);
INSERT INTO `workflow_ReusedActivity` VALUES(231, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop your own application for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/80c6044b-e8b4-43d7-ad94-6c3e78203448', NULL, 81, NULL, NULL, 238, NULL, NULL, 230, NULL, NULL, 219);
INSERT INTO `workflow_ReusedActivity` VALUES(262, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Software engineering0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/3ee33ead-faff-48a5-aa85-3e3777d56ef0', NULL, 141, NULL, NULL, 271, NULL, NULL, 261, NULL, NULL, 217);
INSERT INTO `workflow_ReusedActivity` VALUES(266, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop your own application for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/3a417d86-9b88-4ed4-a892-6d3b506e994e', NULL, 141, NULL, NULL, 273, NULL, NULL, 265, NULL, NULL, 219);
INSERT INTO `workflow_ReusedActivity` VALUES(281, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Software engineering0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/6edec3aa-a41e-4fc7-ac05-be77a778564b', NULL, 81, NULL, NULL, 290, NULL, NULL, 280, NULL, NULL, 217);
INSERT INTO `workflow_ReusedActivity` VALUES(285, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop your own application for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/55295651-a43e-4175-bcc7-f79d6ec7d694', NULL, 81, NULL, NULL, 292, NULL, NULL, 284, NULL, NULL, 219);
INSERT INTO `workflow_ReusedActivity` VALUES(306, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/872ac66b-0462-4a92-bc32-9105b9606c9a', NULL, 126, NULL, NULL, 315, NULL, NULL, 305, NULL, NULL, 252);
INSERT INTO `workflow_ReusedActivity` VALUES(310, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop design documentation: case study0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/12f493d7-0f96-4622-9526-739cfaac3f59', NULL, 126, NULL, NULL, 317, NULL, NULL, 309, NULL, NULL, 254);
INSERT INTO `workflow_ReusedActivity` VALUES(325, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/a62d196f-fd55-4ce8-ab17-f75eec7a707e', NULL, 23, NULL, NULL, 334, NULL, NULL, 324, NULL, NULL, 252);
INSERT INTO `workflow_ReusedActivity` VALUES(329, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Develop design documentation: case study0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/5e981ba8-0cf4-4abd-b688-441a94aaeb3e', NULL, 23, NULL, NULL, 336, NULL, NULL, 328, NULL, NULL, 254);
INSERT INTO `workflow_ReusedActivity` VALUES(425, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read about the software design strategies0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/8ea399f9-e553-4973-8ed7-81eb6d541520', NULL, 111, NULL, NULL, 430, NULL, NULL, 424, NULL, NULL, 196);
INSERT INTO `workflow_ReusedActivity` VALUES(972, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Conceptual Modeling0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/5d7a835e-dbb4-49fd-91be-dbab6c9b1e9b', NULL, 23, NULL, NULL, 981, NULL, NULL, 971, NULL, NULL, 184);
INSERT INTO `workflow_ReusedActivity` VALUES(976, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create your own domain model for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/21c3db97-6d83-411b-9d38-985cebf409b2', NULL, 23, NULL, NULL, 983, NULL, NULL, 975, NULL, NULL, 186);
INSERT INTO `workflow_ReusedActivity` VALUES(1000, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Conceptual Modeling0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/9b862a71-40a1-4b3d-8d4e-ed2786c157bb', NULL, 96, NULL, NULL, 1009, NULL, NULL, 999, NULL, NULL, 184);
INSERT INTO `workflow_ReusedActivity` VALUES(1004, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create your own domain model for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/53890af6-4294-440f-96ec-8f0b16d2c411', NULL, 96, NULL, NULL, 1011, NULL, NULL, 1003, NULL, NULL, 186);
INSERT INTO `workflow_ReusedActivity` VALUES(1027, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Conceptual Modeling0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/935e17d3-2a90-4517-a3a2-417b54117409', NULL, 111, NULL, NULL, 1036, NULL, NULL, 1026, NULL, NULL, 184);
INSERT INTO `workflow_ReusedActivity` VALUES(1031, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create your own domain model for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/cb0e4a5f-73f5-410c-ae70-87be8e1800dc', NULL, 111, NULL, NULL, 1038, NULL, NULL, 1030, NULL, NULL, 186);
INSERT INTO `workflow_ReusedActivity` VALUES(1053, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Read the introductory content on Conceptual Modeling0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/a7a7b534-2d82-479e-b85f-59fc864e3cf1', NULL, 126, NULL, NULL, 1062, NULL, NULL, 1052, NULL, NULL, 184);
INSERT INTO `workflow_ReusedActivity` VALUES(1057, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Create your own domain model for a domain of choice0', 'http://intelleo.org/triplestore/bc_x#ReusedActivity/6cb7c42b-0c46-4cc7-990c-9976b9cf3e81', NULL, 126, NULL, NULL, 1064, NULL, NULL, 1056, NULL, NULL, 186);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_ReusedAsset`
--

CREATE TABLE `workflow_ReusedAsset` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `activity_id` bigint(20) DEFAULT NULL,
  `referenceToContent_id` bigint(20) DEFAULT NULL,
  `referenceToPerson_id` bigint(20) DEFAULT NULL,
  `basedOn_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FKEF86282E5F3CFD32996f3db297ac4fc0` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_ReusedAsset`
--

INSERT INTO `workflow_ReusedAsset` VALUES(225, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software engineering for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/6247b403-7f15-48ab-8d17-fabae9a8fb29', NULL, 81, NULL, NULL, 237, 217, 213, NULL, 215);
INSERT INTO `workflow_ReusedAsset` VALUES(260, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software engineering for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/2f49126f-50e9-442b-84b0-d36a7ea83ced', NULL, 141, NULL, NULL, 272, 217, 213, NULL, 215);
INSERT INTO `workflow_ReusedAsset` VALUES(279, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software engineering for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/b2d62f73-6182-4d1e-94f2-fa31ae8fadeb', NULL, 81, NULL, NULL, 291, 217, 213, NULL, 215);
INSERT INTO `workflow_ReusedAsset` VALUES(304, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software high-level design0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/ab8354fa-f118-4470-beab-422769f9f484', NULL, 126, NULL, NULL, 316, 252, 248, NULL, 250);
INSERT INTO `workflow_ReusedAsset` VALUES(323, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Software high-level design0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/d42d380c-5d3f-4f3c-8bec-385c146ae2ee', NULL, 23, NULL, NULL, 335, 252, 248, NULL, 250);
INSERT INTO `workflow_ReusedAsset` VALUES(970, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/a2b443ce-a566-41ef-8654-f850d73c1365', NULL, 23, NULL, NULL, 982, 184, 180, NULL, 182);
INSERT INTO `workflow_ReusedAsset` VALUES(998, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/d474cc65-bd1c-410a-912c-ecaedf43b488', NULL, 96, NULL, NULL, 1010, 184, 180, NULL, 182);
INSERT INTO `workflow_ReusedAsset` VALUES(1025, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/246fa740-3a54-4cb5-97c0-33a3c9ec30c9', NULL, 111, NULL, NULL, 1037, 184, 180, NULL, 182);
INSERT INTO `workflow_ReusedAsset` VALUES(1051, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Conceptual Modeling for Absolute Beginners0', 'http://intelleo.org/triplestore/bc_x#ReusedAsset/df63380f-0d6a-4faf-b2b8-4bece951cf94', NULL, 126, NULL, NULL, 1063, 184, 180, NULL, 182);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_ReusedLearningTask`
--

CREATE TABLE `workflow_ReusedLearningTask` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `dateFinished` datetime DEFAULT NULL,
  `dateStarted` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `leader_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `responsiblePerson_id` bigint(20) DEFAULT NULL,
  `definedBy_id` bigint(20) DEFAULT NULL,
  `basedOn_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK44028A2569D10D2812f1263a3adeef3` (`leader_id`),
  KEY `FK44028A25AF9CB4D0812f1263a3adeef3` (`responsiblePerson_id`),
  KEY `FK44028A25D7DE8A84812f1263a3adeef3` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD3244028a25812f1263a3adeef3` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_ReusedLearningTask`
--

INSERT INTO `workflow_ReusedLearningTask` VALUES(206, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Defining user requirements0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/58f8e5bb-75e6-4f2f-96c0-cb697cc2e37a', NULL, 126, NULL, NULL, 207, NULL, NULL, NULL, 199, NULL, NULL, NULL, NULL, NULL, 198);
INSERT INTO `workflow_ReusedLearningTask` VALUES(234, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Developing industrial software0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/d9d40765-a89e-418d-9e85-980d9ac78d0c', NULL, 81, NULL, NULL, 235, NULL, NULL, NULL, 222, NULL, NULL, NULL, NULL, NULL, 221);
INSERT INTO `workflow_ReusedLearningTask` VALUES(269, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Developing domain specific applications0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/ccbd0f9a-eb5f-4cd9-a6bc-e1b6e4dae9e9', NULL, 141, NULL, NULL, 270, NULL, NULL, NULL, 257, NULL, NULL, NULL, NULL, NULL, 221);
INSERT INTO `workflow_ReusedLearningTask` VALUES(288, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Specifying software requirements0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/e174d8b9-5736-475f-b18e-4bee50addfd9', NULL, 81, NULL, NULL, 289, NULL, NULL, NULL, 276, NULL, NULL, NULL, NULL, NULL, 221);
INSERT INTO `workflow_ReusedLearningTask` VALUES(313, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Most common design strategies0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/c9ee3515-329c-4cfc-8115-e38265a34fa4', NULL, 126, NULL, NULL, 314, NULL, NULL, NULL, 301, NULL, NULL, NULL, NULL, NULL, 256);
INSERT INTO `workflow_ReusedLearningTask` VALUES(332, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Defining user requirements0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/2c506a7e-9cb6-4919-87a6-bf55b5a3aead', NULL, 23, NULL, NULL, 333, NULL, NULL, NULL, 320, NULL, NULL, NULL, NULL, NULL, 256);
INSERT INTO `workflow_ReusedLearningTask` VALUES(428, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Semantic Web in education0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/cffaf85c-5651-4c06-9e52-2d7e2864d9ae', NULL, 111, NULL, NULL, 429, NULL, NULL, NULL, 421, NULL, NULL, NULL, NULL, NULL, 198);
INSERT INTO `workflow_ReusedLearningTask` VALUES(979, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Modeling in OWL0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/86a60eb3-bed4-4f28-ae39-64026ad918ed', NULL, 23, NULL, NULL, 980, NULL, NULL, NULL, 967, NULL, NULL, NULL, NULL, NULL, 188);
INSERT INTO `workflow_ReusedLearningTask` VALUES(1007, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Modeling Things basics0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/0648e970-f31b-461a-bd04-698f423071ca', NULL, 96, NULL, NULL, 1008, NULL, NULL, NULL, 995, NULL, NULL, NULL, NULL, NULL, 188);
INSERT INTO `workflow_ReusedLearningTask` VALUES(1034, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Modeling in SW world0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/87d55a8a-7b6b-43ce-9b36-7f521684ad53', NULL, 111, NULL, NULL, 1035, NULL, NULL, NULL, 1022, NULL, NULL, NULL, NULL, NULL, 188);
INSERT INTO `workflow_ReusedLearningTask` VALUES(1060, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'How to model Things - 10 simple steps0', 'http://intelleo.org/triplestore/bc_x#ReusedLearningTask/f6955d54-253d-4a0f-b10e-006043ccf601', NULL, 126, NULL, NULL, 1061, NULL, NULL, NULL, 1048, NULL, NULL, NULL, NULL, NULL, 188);

-- --------------------------------------------------------

--
-- Table structure for table `workflow_SelfDesignedLearningTask`
--

CREATE TABLE `workflow_SelfDesignedLearningTask` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `dateFinished` datetime DEFAULT NULL,
  `dateStarted` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `leader_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `responsiblePerson_id` bigint(20) DEFAULT NULL,
  `definedBy_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK44028A2569D10D2812f12631da2cf4c` (`leader_id`),
  KEY `FK44028A25AF9CB4D0812f12631da2cf4c` (`responsiblePerson_id`),
  KEY `FK44028A25D7DE8A84812f12631da2cf4c` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD3244028a25812f12631da2cf4c` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_SelfDesignedLearningTask`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_Task`
--

CREATE TABLE `workflow_Task` (
  `id` bigint(20) NOT NULL,
  `alternative` varchar(255) DEFAULT NULL,
  `created` datetime DEFAULT NULL,
  `issued` datetime DEFAULT NULL,
  `dc_description` longtext,
  `extent` datetime DEFAULT NULL,
  `identifier` varchar(255) DEFAULT NULL,
  `language` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uri` varchar(255) DEFAULT NULL,
  `holder_id` bigint(20) DEFAULT NULL,
  `maker_id` bigint(20) DEFAULT NULL,
  `siocCreator_id` bigint(20) DEFAULT NULL,
  `originatesFrom` bigint(20) DEFAULT NULL,
  `visibility_id` bigint(20) DEFAULT NULL,
  `dateFinished` datetime DEFAULT NULL,
  `dateStarted` datetime DEFAULT NULL,
  `deadline` datetime DEFAULT NULL,
  `currentStatus_id` bigint(20) DEFAULT NULL,
  `expectedDuration_id` bigint(20) DEFAULT NULL,
  `leader_id` bigint(20) DEFAULT NULL,
  `project_id` bigint(20) DEFAULT NULL,
  `responsiblePerson_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `FK44028A2569D10D2` (`leader_id`),
  KEY `FK44028A25AF9CB4D0` (`responsiblePerson_id`),
  KEY `FK44028A25D7DE8A84` (`expectedDuration_id`),
  KEY `FKEF86282E5F3CFD3244028a25` (`originatesFrom`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Task`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_Task_Resource`
--

CREATE TABLE `workflow_Task_Resource` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `results_id` bigint(20) NOT NULL,
  UNIQUE KEY `results_id` (`results_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Task_Resource`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_Task_workflowPrerequisite`
--

CREATE TABLE `workflow_Task_workflowPrerequisite` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `prerequisites_id` bigint(20) NOT NULL,
  UNIQUE KEY `prerequisites_id` (`prerequisites_id`),
  KEY `FKD5ABB1EF3EBDFCD5` (`prerequisites_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Task_workflowPrerequisite`
--


-- --------------------------------------------------------

--
-- Table structure for table `workflow_Task_workflow_Task`
--

CREATE TABLE `workflow_Task_workflow_Task` (
  `workflow_Task_id` bigint(20) NOT NULL,
  `followingTasks_id` bigint(20) NOT NULL,
  UNIQUE KEY `followingTasks_id` (`followingTasks_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `workflow_Task_workflow_Task`
--

